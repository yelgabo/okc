import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import types

ROOT = Path('/mnt/c/Users/gretc/Documents/GitHub/okc')
sys.path.insert(0, str(ROOT / 'tools'))
from prod_size_compile_g import bindings, sections
from proj_g_native_gamma_compile import norm_ptx

CACHE = Path('/root/.cache/okc-cuda130-88')
KIT = CACHE / 'nvidia/cu13'
OUT = ROOT / 'docs/steering/evidence/2026-11-01-gamma13-main-screen'
OUT.mkdir(parents=True, exist_ok=True)
PINS = {
    'baseline': 'ba9e327cd7b96595ace4d0c1d0d78fe27c128f23ed0debcda97c7169fc3164ab',
    'off': 'e17901d562b35f127c49110d222205fab254d078ae37e941a687774973a44c18',
    'on': 'd6756bb50a0362af9c9cd03d44a88c80fa593628254ffb2a931a643fccafdcad',
}
FILES = {
    'baseline': ROOT / 'muse_decode_layer/cand/g1b4_stage_release.py',
    'off': ROOT / '.build/g-minimal-rootreview/gamma/off.py',
    'on': ROOT / '.build/g-minimal-rootreview/gamma/on.py',
}
FLAGS = ['-DOKC_NS=3', '-DOKC_NSF=3', '-DOKC_FNST=4', '-DOKC_PRMTSC=1', '-DOKC_DQ7=1',
         '-DOKC_NW=16', '-DOKC_FAST1=0', '-DOKC_EPI4=0', '-DOKC_WGS=1', '-DOKC_SC6W=1']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              source_pins=PINS, flags=FLAGS, gpu=False, driver=False, host_link=False,
              scope='MAIN only, both bool entries, fixed three arms; device-prefix secondary NVRTC13 screen, NOT exact target NVCC equivalence',
              status='running', arms={}, host_compilers={name: shutil.which(name) for name in ('gcc', 'g++', 'clang', 'clang++', 'c++')})

def save():
    (OUT / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')

tools = {}
for name, path in {
    'nvcc': KIT / 'bin/nvcc', 'ptxas': KIT / 'bin/ptxas',
    'cicc': KIT / 'nvvm/bin/cicc', 'nvrtc': KIT / 'lib/libnvrtc.so.13',
    'nvrtc_builtins': KIT / 'lib/libnvrtc-builtins.so.13.0',
    'nvdisasm': CACHE / 'cuda_nvdisasm-linux-x86_64-13.0.85-archive/bin/nvdisasm',
}.items():
    tools[name] = dict(path=str(path), resolved=str(path.resolve()), sha256=sha(path))
    if name in ('nvcc', 'ptxas', 'nvdisasm'):
        proc = subprocess.run([str(path), '--version'], capture_output=True, text=True)
        tools[name]['version'] = proc.stdout + proc.stderr
result['tools'] = tools
library = ctypes.CDLL(str(KIT / 'lib/libnvrtc.so.13'))
major = ctypes.c_int()
minor = ctypes.c_int()
assert library.nvrtcVersion(ctypes.byref(major), ctypes.byref(minor)) == 0
result['nvrtc_version'] = [major.value, minor.value]
result['nvcc_target_blocker'] = 'NVCC13.0.88 executable present, but no supported host preprocessing compiler found; no installation attempted.'
save()

driver_path = ROOT / 'tools/local_cuda128_compile.py'
driver = driver_path.read_text()
old = "'-DOKC_NW=16', '-DOKC_FAST1=0', '-DOKC_EPI4=0', '-DOKC_WGS=1',\n               '-DOKC_NS=3', '-DOKC_NSF=3', '-DOKC_PRMTSC=1', '-DOKC_SC6W=' + str(args.sc6), *args.define"
assert driver.count(old) == 1
driver = driver.replace(old, '*args.define')
replacements = {
    "packages/nvidia/cuda_nvrtc/lib/libnvrtc.so.12": 'nvidia/cu13/lib/libnvrtc.so.13',
    'packages/nvidia/cuda_runtime/include': 'nvidia/cu13/include',
    'packages/nvidia/cuda_nvcc/include': 'nvidia/cu13/include',
    'cccl/nvidia/cuda_cccl/include': 'cuda_cccl-linux-x86_64-13.0.85-archive/include',
    'packages/nvidia/cuda_nvcc/bin/ptxas': 'nvidia/cu13/bin/ptxas',
}
for old_path, new_path in replacements.items():
    assert old_path in driver
    driver = driver.replace(old_path, new_path)
(OUT / 'adapted-driver.py').write_text(driver)
result['driver_original_sha256'] = sha(driver_path)
result['adapted_driver_sha256'] = sha(OUT / 'adapted-driver.py')
namespace = {'__name__': '_fixed_main_gamma13'}
exec(compile(driver, '<fixed-main-gamma13-device-adapter>', 'exec'), namespace)

try:
    for arm, path in FILES.items():
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == PINS[arm], (arm, 'source pin')
        env = bindings(raw.decode())
        folder = OUT / arm
        folder.mkdir(exist_ok=True)
        source = folder / 'input.cu'
        source.write_bytes(env['MOE_CUDA_SRC'].encode())
        if arm == 'baseline':
            prefix = source.read_text().split('#include <torch/extension.h>')[0]
            probe = ROOT / '.build/research-gamma13/nvcc-probe.cu'
            probe.write_text(prefix)
            command = [str(KIT / 'bin/nvcc'), '--ptx', '-O3', '-std=c++17',
                       '-gencode=arch=compute_90a,code=compute_90a', '-lineinfo',
                       *FLAGS, str(probe), '-o', str(probe.with_suffix('.ptx'))]
            proc = subprocess.run(command, capture_output=True, text=True)
            result['nvcc_probe'] = dict(command=command, returncode=proc.returncode, log=proc.stdout + proc.stderr)
            (OUT / 'nvcc-probe.log').write_text(proc.stdout + proc.stderr)
            assert proc.returncode != 0, 'Unexpected successful NVCC probe; stop rather than silently switch recipes'
            save()
        flags = FLAGS + (['-DOKC_FORK_GAMMA_EFFECTIVE=1'] if arm == 'on' else [])
        args = types.SimpleNamespace(source=source, out=folder, cache=CACHE, sc6=1,
                                     define=flags, forward_declare_wgs=True)
        namespace['compile_source'](args)
        disassembly = subprocess.run([tools['nvdisasm']['path'], str(folder / 'device.cubin')],
                                     capture_output=True, text=True, check=True)
        (folder / 'device.sass').write_text(disassembly.stdout)
        manifest = json.loads((folder / 'manifest.json').read_text())
        ops = sections(folder / 'device.sass')
        normalized = norm_ptx((folder / 'device.ptx').read_text())
        (folder / 'normalized.ptx').write_text(normalized)
        result['arms'][arm] = dict(manifest=manifest, sass=ops,
                                  normalized_ptx_sha256=sha(folder / 'normalized.ptx'))
        assert len(manifest['resources']) == 2
        if arm == 'off':
            base = result['arms']['baseline']
            result['off_equivalence'] = dict(
                ptx=base['normalized_ptx_sha256'] == result['arms'][arm]['normalized_ptx_sha256'],
                sass=base['sass'] == ops,
                resources=base['manifest']['resources'] == manifest['resources'],
                bounds=base['manifest']['ptx_launch_bounds'] == manifest['ptx_launch_bounds'])
            save()
            assert all(result['off_equivalence'].values()), 'OFF_EQUIVALENCE_BLOCKER'
        if arm == 'on':
            base = result['arms']['baseline']['manifest']
            controls = base['resources']
            treatments = manifest['resources']
            assert controls.keys() == treatments.keys()
            result['on_resources_no_worse'] = (
                all(treatments[symbol][key] <= controls[symbol][key]
                    for symbol in controls for key in ('registers', 'stack_bytes', 'spill_store_bytes', 'spill_load_bytes'))
                and all(treatments[symbol]['barriers'] == controls[symbol]['barriers'] for symbol in controls)
                and base['ptx_launch_bounds'] == manifest['ptx_launch_bounds'])
            save()
            assert result['on_resources_no_worse'], 'ON_RESOURCE_BLOCKER'
        save()
        print('ARM_COMPLETE', arm, flush=True)
    result['status'] = 'secondary_screen_pass_no_target_equivalence_or_gain_claim'
except Exception as error:
    result['status'] = 'stopped'
    result['error'] = repr(error)
    raise
finally:
    result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
