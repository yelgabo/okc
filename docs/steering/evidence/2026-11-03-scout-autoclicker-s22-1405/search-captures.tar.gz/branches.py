from api import api,state,out,ThreadPoolExecutor,json,quote
items=list(state.get('watched_branch_heads',{}).items())
def fetch(row):
 key,old=row;repo,branch=key.split(':',1)
 path='/repos/'+repo+('/pulls/'+branch.split('/')[1] if branch.startswith('pull/') else '/commits/'+quote(branch,safe=''))
 r=api(path);d=r.get('data',{});new=(d.get('head') or {}).get('sha') if branch.startswith('pull/') else d.get('sha')
 return dict(key=key,old=old,head=new,changed=bool(new and old!=new),error=r.get('error'),path=path)
with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,items))
(out/'watched-branches.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
