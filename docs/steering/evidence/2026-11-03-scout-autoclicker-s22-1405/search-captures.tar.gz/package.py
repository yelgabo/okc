from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, tarfile, shutil

out = Path('.build/scout-2026-11-03-1405')
evidence = Path('docs/steering/evidence/2026-11-03-scout-autoclicker-s22-1405')
evidence.mkdir(parents=True, exist_ok=True)
analysis = json.loads((out / 'analysis.json').read_text())
code = json.loads((out / 'code.json').read_text())
coverage = json.loads((out / 'query-coverage.json').read_text())
requests = json.loads((out / 'requests.json').read_text())
manifest = json.loads((out / 'autoclicker-source-manifest.json').read_text())
summary = dict(triggered_at='2026-11-03T14:05:46.276Z', packaged_at=datetime.now(timezone.utc).isoformat(), instructions_ref='95cdfe7c385ba66f679d593a78b0457c3bfb1707', decision='NOTIFY', finding='Newly published readable H200 S22 layer and experiment records from AutoclickerI; historical October 27 author result, no independent reproduction.', source_pin='85aed1fb1365877b615542dd44980646816d6b26', source_publication_commit='da928989be2e76eae6d613de73dc7e20b30dc4fc', source_publication_date='2026-11-03T12:45:17Z', source_files=len(manifest), static_check=json.loads((out / 'static-source-check.json').read_text()), code_unique=analysis['code_unique'], new_code_blobs=len(analysis['new_code_files']), new_code_provenance={'Mithun-033/Muse-Spark-Open-Kernel-Challenge':234,'3xC1ibR/workstation':2}, code_queries=code['searches'], noncode_queries=coverage, first_page_limited_queries=sum(r['truncated_by_page_limit'] for r in coverage), search_limits='Changing search totals and scoped exclusions are retained per query. Previously known example-heavy code repositories and own repository excluded. Page coverage is not an atomic snapshot or proof of absence.', transient_errors=[{k:r.get(k) for k in ['path','retrieved_at','error']} for r in requests if r.get('error')], final_search_errors=[r for r in coverage if r.get('error')], watched_heads=json.loads((out / 'watched-branches.json').read_text()), changed_default_heads=analysis['changed_watched_heads'], guild_pages=17, guild_unique_body_fragments=64, guild_new_body_fragments=0, indexed_web_queries=20, source_credit_counts=[15,16,21], social_access=json.loads((out / 'social-access.json').read_text()), source_execution=False, gpu_execution=False, limits=['Static reconstruction validates published byte relationships only, not CUDA correctness or progress/ordering.', 'Uploaded final receipt and phase lab data remain author evidence. Server content_hash representation was not independently bound to the upload.', 'Phase results retain false freeze/TASK/promote flags and a needs-confirmation marker; do not relabel the BF16 lab host as a passing decoder-layer check.', 'Public/cached sources only. No authenticated Slack/Discord, restricted Guild bodies or encrypted messages read.'])
assert not summary['final_search_errors']
assert all(not p.get('error') for q in code['searches'] for p in q['pages'])
(evidence / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name in ['autoclicker-source-manifest.json','static-source-check.json','static-source-check.py','query-coverage.json','web-coverage.json','social-access.json','guild-body-diff.json','review-comparison.json','watched-branches.json']:
    shutil.copyfile(out / name, evidence / name)
with tarfile.open(evidence / 'autoclicker-source.tar.gz','w:gz',compresslevel=9) as archive:
    for row in manifest:
        data = Path(row['local']).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['blob']
        archive.add(row['local'], arcname=row['path'])
with tarfile.open(evidence / 'search-captures.tar.gz','w:gz',compresslevel=9) as archive:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ['.py','.json'] and path.name not in ['state-before.json','requests.json']:
            archive.add(path,arcname=path.name)
rows = []
for path in sorted(evidence.iterdir()):
    if path.name == 'manifest.json':
        continue
    data = path.read_bytes()
    rows.append(dict(path=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()))
(evidence / 'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(files=len(rows),evidence_bytes=sum(r['bytes'] for r in rows),code_unique=analysis['code_unique']),indent=2))
