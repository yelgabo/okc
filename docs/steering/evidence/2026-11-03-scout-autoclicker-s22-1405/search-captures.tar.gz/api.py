from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode,quote
import base64,json,subprocess,yaml,time,datetime,threading
out=Path('.build/scout-2026-11-03-1405');state=json.loads(Path('/Users/gretchengabo/.codex/muse-competition-watch/state.json').read_text());lock=threading.Lock();events=[]
def api(path):
 projection = '. as $r | if type == "object" and has("items") then {total_count, incomplete_results, items:[.items[] | {id,sha,path,html_url,full_name,private,default_branch,pushed_at,updated_at,title,body:(.body // "" | .[:1600]),repository:(.repository | {full_name,private}),commit:(.commit | {message,committer}),pull_request}]} elif type == "object" and has("full_name") then {full_name,private,default_branch,pushed_at,html_url,fork,description,parent:(.parent|{full_name})} elif type == "object" and has("sha") and has("commit") then {sha,commit:(.commit|{message,committer}),parents,files:[.files[]? | {filename,status,sha,additions,deletions,patch,raw_url,blob_url}]} else . end | @base64'
 p=subprocess.run(['/opt/homebrew/bin/gh-axi','api',path,'--jq',projection],capture_output=True,text=True,timeout=45)
 row={'path':path,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode}
 try:
  raw=yaml.safe_load(p.stdout)
  if p.returncode:raise ValueError(p.stderr or p.stdout)
  body=raw['api_response'];assert not body.get('truncated'), 'wrapper response truncated';data=json.loads(base64.b64decode(body['body']));row['data']=data
 except Exception as e:
  if 'truncated' in str(e):
   fallback=subprocess.run(['gh','api',path],capture_output=True,text=True,timeout=45);row['fallback']='raw gh api because gh-axi truncated its response';row['exit']=fallback.returncode
   if fallback.returncode:row['error']=fallback.stderr[:1500]
   else:
    try:row['data']=json.loads(fallback.stdout)
    except Exception as parse_error:row['error']=str(parse_error)[:1500]
  else:row['error']=str(e)[:1500]
 with lock:events.append(row)
 return row
