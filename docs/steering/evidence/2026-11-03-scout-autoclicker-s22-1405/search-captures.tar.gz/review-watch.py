from api import api,out,ThreadPoolExecutor,json,Path
paths=['/repos/vllm-project/vllm/pulls/64077','/repos/vllm-project/vllm/issues/64077/comments?per_page=100','/repos/vllm-project/vllm/pulls/64077/reviews?per_page=100','/repos/vllm-project/vllm/pulls/64077/comments?per_page=100']
with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(api,paths))
(out/'review-watch.json').write_text(json.dumps(rows,indent=2))
old=Path('.build/scout-2026-11-03-0724');pr=json.loads((old/'specialized-pr.json').read_text())['data'];now=rows[0].get('data',{});print('PR body same',now.get('body')==pr['body'],'head same',now.get('head',{}).get('sha')==pr['head']['sha'],'state',now.get('state'),'updated',now.get('updated_at'))
prev={r['path']:r.get('data') for r in json.loads((old/'specialized-reviews.json').read_text())}
for r in rows[1:]:
 oldrows={x['id']:x for x in prev.get(r['path'],[])};changed=[x for x in r.get('data',[]) if x.get('body')!=oldrows.get(x['id'],{}).get('body')];print(r['path'],'count',len(r.get('data',[])),'new_or_changed',[(x['id'],x.get('html_url'),(x.get('body') or '')[:1500]) for x in changed],'error',r.get('error'))
