from api import api,out,json,urlencode,time
rows=[]
for term in ['keell0renz','alygg77','vjeux/okc-2026']:
 rate=api('/rate_limit').get('data',{}).get('resources',{}).get('code_search',{})
 if rate.get('remaining',0)==0:
  delay=max(1,rate.get('reset',time.time()+55)-time.time()+1)
  time.sleep(min(delay,55))
  rate=api('/rate_limit').get('data',{}).get('resources',{}).get('code_search',{})
 if rate.get('remaining',0)==0:
  rows.append(dict(term=term,error='code search budget unavailable after bounded wait'));continue
 q='"'+term+'" -repo:yelgabo/okc -repo:rohanarun/Auto-research-agent -repo:ruwwww/agent-skills'
 result=api('/search/code?'+urlencode(dict(q=q,per_page=100,page=1)))
 rows.append(dict(term=term,query=q,page=1,**result));time.sleep(2.2)
(out/'credits.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 d=r.get('data',{});print(r['term'],d.get('total_count'),r.get('error'),sorted({x.get('repository',{}).get('full_name','') for x in d.get('items',[])}))
