from api import api,out,ThreadPoolExecutor,json
paths=['/repos/sgl-project/sglang/pulls/'+str(n) for n in [47636,47561,47517,47174]]
paths+=['/repos/sgl-project/sglang/pulls/47636/'+s+'?per_page=100' for s in ['files','comments','reviews','commits']]
paths+=['/repos/sgl-project/sglang/issues/47636/comments?per_page=100']
with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(api,paths))
(out/'sglang-current.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 d=r.get('data'); print(r['path'],len(d) if isinstance(d,list) else {k:d.get(k) for k in ['title','updated_at','merged','state']} if isinstance(d,dict) else None,r.get('error'))
