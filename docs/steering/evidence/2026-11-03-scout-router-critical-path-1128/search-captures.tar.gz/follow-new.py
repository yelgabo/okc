from api import api,out,ThreadPoolExecutor,json,quote
pins=json.loads((out/'pins.json').read_text());heads={r['repository']:r['head'] for r in pins if r.get('head')}
paths=[
'/repos/sgl-project/sglang/pulls/48124',
'/repos/sgl-project/sglang/pulls/48124/files?per_page=100',
'/repos/Mithun-033/Muse-Spark-Open-Kernel-Challenge/git/trees/'+heads['Mithun-033/Muse-Spark-Open-Kernel-Challenge']+'?recursive=1',
'/repos/4gatepylon/LearningML/git/trees/'+heads['4gatepylon/LearningML']+'?recursive=1',
'/repos/arunjyotisarmarsece24-jpg/neuro-spark-accel/compare/0d53e77659d46cba961a24b60228e5282a87c199...'+heads['arunjyotisarmarsece24-jpg/neuro-spark-accel']]
with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(api,paths))
(out/'follow-new.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 d=r.get('data',{});print(r['path'],r.get('error'),len(d.get('tree',[])) if isinstance(d,dict) else len(d))
