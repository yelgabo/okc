from pathlib import Path
import json,hashlib
out=Path('.build/scout-2026-11-03-1128');rows=json.loads((out/'sglang-current.json').read_text());source=rows[0]['data'];root=Path('.build/scout-2026-11-03-0923/router-source')
main='python/sglang/kernels/ops/gemm/muse_spark_router_gemm_cutedsl.py';model='python/sglang/srt/models/muse_spark.py'
for path,needle in [(main,'_SERVE_TABLES ='),(main,'def router_tf32_eligible'),(model,'router_tf32_eligible')]:
 lines=(root/path).read_text().splitlines();hits=[i for i,v in enumerate(lines) if needle in v];print(path,needle,[(i+1,lines[i][:100]) for i in hits])
print('related PR bodies',[(r['data'].get('number'),r['data'].get('updated_at')) for r in rows[:4]])
