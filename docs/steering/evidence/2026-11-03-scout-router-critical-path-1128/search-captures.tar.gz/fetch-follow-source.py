from pathlib import Path
import json,hashlib
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
out=Path('.build/scout-2026-11-03-1128');rows=json.loads((out/'follow-new.json').read_text());pins={r['repository']:r['head'] for r in json.loads((out/'pins.json').read_text()) if r.get('head')};tasks=[]
for repo,marker in [('Mithun-033/Muse-Spark-Open-Kernel-Challenge','Mithun'),('4gatepylon/LearningML','LearningML')]:
 tree=next(r['data']['tree'] for r in rows if marker in r['path'])
 for r in tree:
  path=r['path']
  if r['type']!='blob':continue
  if marker=='Mithun':keep=path in ('README.md','submission.py','requirements.txt')
  else:keep=path.endswith('4gatepylon_official_work/README.md') or ('4gatepylon_official_work/' in path and path.endswith('/submission.py'))
  if keep:tasks.append((repo,pins[repo],path,r['sha']))
repo='arunjyotisarmarsece24-jpg/neuro-spark-accel';cmp=next(r['data'] for r in rows if '/compare/' in r['path'])
for row in cmp.get('files',[]):
 if row['filename'] in ('README.md','colab_submission.py'):tasks.append((repo,pins[repo],row['filename'],row['sha']))
def fetch(t):
 repo,pin,path,blob=t
 try:
  url=f'https://raw.githubusercontent.com/{repo}/{pin}/{path}'
  with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as r:b=r.read()
  actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert actual==blob
  local=out/'follow-source'/repo/path;local.parent.mkdir(parents=True,exist_ok=True);local.write_bytes(b)
  return dict(repository=repo,pin=pin,path=path,blob=blob,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),local=str(local),url=f'https://github.com/{repo}/blob/{pin}/{path}')
 except Exception as e:return dict(repository=repo,path=path,error=str(e))
with ThreadPoolExecutor(max_workers=4) as pool:r=list(pool.map(fetch,tasks))
(out/'follow-source-manifest.json').write_text(json.dumps(r,indent=2)+'\n');print([(x['repository'],x['path'],x.get('bytes'),x.get('error')) for x in r])
