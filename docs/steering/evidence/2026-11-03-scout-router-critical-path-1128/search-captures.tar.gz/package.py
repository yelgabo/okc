from pathlib import Path
import json, hashlib, tarfile, shutil
from datetime import datetime, timezone

out = Path('.build/scout-2026-11-03-1128')
evidence = Path('docs/steering/evidence/2026-11-03-scout-router-critical-path-1128')
code = json.loads((out / 'code.json').read_text())
coverage = json.loads((out / 'query-coverage.json').read_text())
analysis = json.loads((out / 'analysis.json').read_text())
requests = json.loads((out / 'requests.json').read_text())
summary = dict(
    sweep='2026-11-03T11:28:18.777Z', packaged_at=datetime.now(timezone.utc).isoformat(),
    repository_instructions_ref='b9736d04', decision='NOTIFY',
    alert='First recorded source review of SGLang PR47636, pinned 07e2f70fa9de868aef4c2c35f0a4da0d6000f6e1. Blackwell/TF32 serving reference; no independent H200 result.',
    code_unique=analysis['code_unique'], new_code_file_blobs=456,
    new_code_repository='4gatepylon/LearningML', index_change_limit='Repository head unchanged; selected official-work files inspected. Search index visibility is not a source change.',
    code_queries=code['searches'], other_queries=coverage,
    github_search_limits='Code excludes known large copied/example repositories rohanarun/Auto-research-agent and lee101/openkernels, plus own repository. Other queries exclude own repository. Exact query strings retained. Search pages are not atomic snapshots.',
    noncode_queries=len(coverage), noncode_first_page_limited=sum(r['truncated_by_page_limit'] for r in coverage),
    transient_api_errors=[{k:r.get(k) for k in ['path','retrieved_at','exit','error']} for r in requests if r.get('error')],
    retry='Attention code page 2 rate limit at 11:30:20 UTC; same path succeeded at 11:31:22 UTC after bounded wait. No final code/noncode search error.',
    source_credit_counts=[15,16,21], watched_nondefault_heads=6,
    sampled_branch_fork_release_endpoints=18, branch_fork_release_changes_since_0923=0,
    guild_pages=17, guild_unique_public_body_fragments=64, guild_new_fragments=0,
    guild_limits='Sampled public pages and normalized body fragments, not whole-forum coverage. Restricted thread 48 body unread.',
    indexed_web_queries=16, originals_x_profiles_403=5,
    social_limits='Public cached mirrors provide leads only. No authenticated Slack, Discord, restricted Guild bodies or encrypted messages accessed. agents.kernarc.com remains inaccessible.',
    watched_head_changes=analysis['changed_watched_heads'],
    competitor_execution=False, gpu_jobs=False, independent_performance_validation=False,
    source_binding_limits='Mithun uploaded job JSON names a local path without a source digest. NeuroSpark new source has no inspected raw receipt binding its 1.505x README claim. Author benchmarks remain author claims.'
)
(evidence / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name in ['query-coverage.json','branches-forks-releases.json','follow-source-manifest.json','guild-body-diff.json']:
    shutil.copyfile(out / name, evidence / name)
manifest = json.loads((evidence / 'router-source-manifest.json').read_text())
with tarfile.open(evidence / 'router-source.tar.gz') as archive:
    for row in manifest['files']:
        member = next(x for x in archive.getmembers() if x.name.endswith(row['path']))
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['blob']
for row in json.loads((out / 'follow-source-manifest.json').read_text()):
    assert not row.get('error')
    data = Path(row['local']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['blob']
with tarfile.open(evidence / 'search-captures.tar.gz', 'w:gz', compresslevel=9) as archive:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.suffix in ['.json','.py'] and path.name not in ['state-before.json', 'requests.json'] and '__pycache__' not in path.parts:
            archive.add(path, arcname=str(path.relative_to(out)))
    previous = Path('.build/scout-2026-11-03-0923/kempner-compare.json')
    archive.add(previous, arcname='prior-0923/kempner-compare.json')
rows = []
for path in sorted(evidence.iterdir()):
    if path.is_file() and path.name != 'manifest.json':
        data = path.read_bytes()
        rows.append(dict(path=path.name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), blob=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()))
(evidence / 'manifest.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(dict(source_files_verified=len(manifest['files']) + len(json.loads((out / 'follow-source-manifest.json').read_text())), evidence_files=len(rows), evidence_bytes=sum(r['bytes'] for r in rows)), indent=2))
