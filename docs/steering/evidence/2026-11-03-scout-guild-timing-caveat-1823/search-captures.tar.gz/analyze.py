from pathlib import Path
import json,hashlib
out=Path('.build/scout-2026-11-03-1823');previous=Path('.build/scout-2026-11-03-1405');state=json.loads((out/'state-before.json').read_text());code=json.loads((out/'code.json').read_text());oldcode=json.loads((previous/'code.json').read_text());oldfiles={(i['repository']['full_name'],i['path'],i['sha']) for i in oldcode['items']};newfiles={(i['repository']['full_name'],i['path'],i['sha']) for i in code['items']};other=json.loads((out/'other.json').read_text());oldother=json.loads((previous/'other.json').read_text());olditems={str(i.get('sha',i.get('id'))):i for r in oldother for i in r.get('data',{}).get('items',[])};new=[];edited=[];coverage=[]
def excerpt(i):return json.dumps({'title':i.get('title'),'body':(i.get('body') or '')[:1600]},sort_keys=True)
for row in other:
 d=row.get('data',{});hits=d.get('items',[]);seen=set(state.get('seen_commit_ids' if row['kind']=='commits' else 'seen_issue_pr_ids',[]));coverage.append(dict(kind=row['kind'],query=row['query'],pages=[1],total=d.get('total_count'),returned=len(hits),incomplete=d.get('incomplete_results'),error=row.get('error'),truncated_by_page_limit=d.get('total_count',0)>100))
 for i in hits:
  if row['kind']=='repositories':continue
  identifier=str(i.get('sha') if row['kind']=='commits' else i.get('id'))
  summary=dict(kind=row['kind'],query=row['query'],id=identifier,url=i.get('html_url'),repository=(i.get('repository') or {}).get('full_name'),title=(i.get('commit',{}).get('message') or i.get('title') or '')[:1800],body=(i.get('body') or '')[:1600])
  if identifier not in seen:new.append(summary)
  elif row['kind']!='commits' and identifier in olditems and excerpt(i)!=excerpt(olditems[identifier]):edited.append(summary)
known={r['repository']:r for r in state['pinned_repositories']};pins=json.loads((out/'pins.json').read_text());changed=[dict(repository=r['repository'],base=known[r['repository']].get('head'),head=r.get('head'),error=r.get('error'),date=r.get('head_committer_date'),subject=r.get('head_subject')) for r in pins if r['repository'] in known and r.get('head')!=known[r['repository']].get('head')];newrepos=[r for r in pins if r['repository'] not in known]
analysis=dict(new_code_files=sorted(newfiles-oldfiles),old_code_unique=len(oldfiles),code_unique=len(newfiles),new_other_hits=new,edited_issue_pr_excerpts=edited,changed_watched_heads=changed,new_search_repositories=newrepos,code_coverage=code['searches'],search_coverage=coverage)
(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n');(out/'query-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
print('new code',analysis['new_code_files']);print('changed watch heads',changed);print('new search repos',[(r['repository'],r.get('head')) for r in newrepos]);print('new hits',[(r['url'],r['title'].split('\n')[0]) for r in new]);print('edited issue/PR excerpts',[(r['url'],r['title']) for r in edited]);print('errors',[(r['query'],r['error']) for r in coverage if r['error']]);print('code pages',[(r['term'],len(r['pages'])) for r in code['searches']])
