from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, tarfile, shutil

out = Path('.build/scout-2026-11-03-1823')
evidence = Path('docs/steering/evidence/2026-11-03-scout-guild-timing-caveat-1823')
evidence.mkdir(parents=True,exist_ok=True)
observations = json.loads((out / 'guild-new-observations.json').read_text())
quality = json.loads((out / 'quality-csv-check.json').read_text())
gist = json.loads((out / 'sglang-47129-gist.json').read_text())['data']
metadata = dict(id=gist['id'],updated_at=gist['updated_at'],revision=gist['history'][0]['version'],files=[dict(path=name,raw_url=r['raw_url'],bytes=r['size'],truncated=r.get('truncated')) for name,r in gist['files'].items()])
(out / 'quality-gist-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
pr = next(r for r in json.loads((out / 'extra-watch.json').read_text()) if r['path']=='/repos/sgl-project/sglang/pulls/47129')
(out / 'quality-pr.json').write_text(json.dumps(pr,indent=2)+'\n')
code = json.loads((out / 'code.json').read_text())
coverage = json.loads((out / 'query-coverage.json').read_text())
analysis = json.loads((out / 'analysis.json').read_text())
requests = json.loads((out / 'requests.json').read_text())
assert not analysis['new_code_files'] and not analysis['changed_watched_heads']
assert all(not r.get('error') for r in coverage)
assert all(not p.get('error') for q in code['searches'] for p in q['pages'])
summary = dict(triggered_at='2026-11-03T18:23:53.065Z',packaged_at=datetime.now(timezone.utc).isoformat(),instructions_ref='a481e63b315cd9dc6b0ce3f9f453a38fe14f2487',decision='NOTIFY',findings=['Guild thread147,17:15UTC: author reports local forecast/judge sign reversal and shares profile sums, without job/source-bound receipts.','SGLang PR47129 body updated17:35:54UTC at unchanged d227e32f head; public B200 OFF/ON paired CSV flag counts checked. OFF is the same PR, not clean main.'],guild_observations=observations,quality_check=quality,code_unique=analysis['code_unique'],new_code_file_blobs=0,code_queries=code['searches'],other_queries=coverage,noncode_first_page_limited=sum(r['truncated_by_page_limit'] for r in coverage),search_limits='Known large copied/example repositories and own repository excluded from code queries. Other queries exclude own repository. Exact strings, changing totals and page coverage retained; misses do not establish absence.',transient_api_errors=[{k:r.get(k) for k in ['path','retrieved_at','error']} for r in requests if r.get('error')],final_search_errors=[],default_watched_heads_unchanged=46,nondefault_heads=json.loads((out / 'watched-branches.json').read_text()),source_credit_counts=[15,16,21],guild_pages=18,guild_public_body_fragments=66,guild_new_body_fragments=2,indexed_web_queries=12,social_access=json.loads((out / 'social-access.json').read_text()),blog_hashes=json.loads((out / 'blogs-http.json').read_text()),foreign_execution=False,gpu_jobs=False,limits=['Guild timings are author statements with no raw receipt/source hash in the posts. Same-account cross-posts are not independent evidence.','CSV flags and coverage were checked, not private raw answers, the scorer or target execution.','No source correctness, memory-ordering, quality-equivalence or H200 performance qualification follows.','Independent review unavailable under the repository no-new-agents rule.'])
(evidence / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['guild-new-observations.json','quality-csv-check.json','quality-source-manifest.json','quality-gist-metadata.json','guild-body-diff.json','query-coverage.json','web-coverage.json','social-access.json','background-follow-summary.json']:
    shutil.copyfile(out / name,evidence / name)
sources = [('new-thread-147.html','guild/147.html'),('all-comment-3.html','guild/120.html'),('new-thread-147.json','guild/147.json'),('quality-pr.json','quality/pr47129.json'),('quality-gist-metadata.json','quality/gist-metadata.json')]
sources += [(str(Path(r['local']).relative_to(out)),'quality/'+r['path']) for r in json.loads((out / 'quality-source-manifest.json').read_text())]
manifest = []
with tarfile.open(evidence / 'primary-sources.tar.gz','w:gz',compresslevel=9) as archive:
    for local,member in sources:
        data = (out / local).read_bytes()
        archive.add(out / local,arcname=member)
        manifest.append(dict(member=member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(evidence / 'primary-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(evidence / 'search-captures.tar.gz','w:gz',compresslevel=9) as archive:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ['.py','.json','.diff'] and path.name not in ['state-before.json','requests.json','sglang-47129-gist.json']:
            archive.add(path,arcname=path.name)
rows = []
for path in sorted(evidence.iterdir()):
    if path.name=='manifest.json':continue
    data=path.read_bytes()
    rows.append(dict(path=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()))
(evidence / 'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(evidence_files=len(rows),evidence_bytes=sum(r['bytes'] for r in rows),primary_members=len(manifest)),indent=2))
