from api import api, state, out, events, ThreadPoolExecutor, quote, urlencode, json, time, Path


def search(kind, query, page=1):
    bucket = 'code_search' if kind == 'code' else 'search'
    for attempt in range(3):
        rate = api('/rate_limit').get('data', {}).get('resources', {}).get(bucket, {})
        if rate.get('remaining', 0) == 0:
            delay = max(1, rate.get('reset', time.time()+60)-time.time()+1)
            time.sleep(min(delay, 55))
            continue
        params = dict(q=query, per_page=100, page=page)
        if kind != 'code':
            params['sort'] = 'committer-date' if kind == 'commits' else 'updated'
        result = api('/search/'+kind+'?'+urlencode(params))
        if result.get('error') and 'limit' in result['error'].lower() and attempt < 2:
            time.sleep(61)
            continue
        time.sleep(2.2)
        return result
    return dict(error='Rate budget unavailable after bounded waits', query=query, page=page)


code = dict(searches=[], items=[])
for term in state['terms']:
    query = term+' -repo:rohanarun/Auto-research-agent -repo:lee101/openkernels -repo:yelgabo/okc'
    pages = []
    for page in range(1, 11):
        result = search('code', query, page)
        data = result.get('data', {})
        hits = data.get('items', [])
        pages.append(dict(page=page,total=data.get('total_count'),returned=len(hits),incomplete=data.get('incomplete_results'),error=result.get('error')))
        code['items'].extend(hits)
        if result.get('error') or page*100 >= data.get('total_count', 0):
            break
    code['searches'].append(dict(term=term,query=query,pages=pages))
    (out/'code.json').write_text(json.dumps(code,indent=2))
    print(term,pages,flush=True)

other=[]
queries=[]
for term in state['terms']:
    queries.extend([(kind,term+(' is:pr' if kind=='pull_requests' else ' is:issue' if kind=='issues' else '')+' -repo:yelgabo/okc') for kind in ('repositories','commits','issues','pull_requests')])
for term in ('"Muse Spark Open Kernel Challenge"','"openkernelchallenge.dev"','"Muse Spark" kernel'):
    queries.extend([(kind,term+(' is:pr' if kind=='pull_requests' else ' is:issue' if kind=='issues' else '')+' -repo:yelgabo/okc') for kind in ('repositories','commits','issues','pull_requests')])
for kind,query in queries:
    result=search('issues' if kind=='pull_requests' else kind,query)
    other.append(dict(kind=kind,query=query,**result))
    (out/'other.json').write_text(json.dumps(other,indent=2))
    print(kind,query,result.get('data',{}).get('total_count'),result.get('error'),flush=True)

repositories=set(state['watch_repositories'])
repositories.update(i['repository']['full_name'] for i in code['items'] if i.get('repository',{}).get('full_name') and not i['repository'].get('private'))
repositories.update(i['full_name'] for row in other if row['kind']=='repositories' for i in row.get('data',{}).get('items',[]) if i.get('full_name') and not i.get('private'))


def pin(repo):
    info=api('/repos/'+repo).get('data',{})
    if not info.get('default_branch') or info.get('private'):
        return dict(repository=repo,error='Missing public repository metadata')
    result=api('/repos/'+repo+'/commits/'+quote(info['default_branch'],safe=''))
    commit=result.get('data',{})
    return dict(repository=repo,url=info.get('html_url'),default_branch=info['default_branch'],
                head=commit.get('sha'),pushed_at=info.get('pushed_at'),fork=info.get('fork'),
                parent=(info.get('parent') or {}).get('full_name'),
                head_committer_date=commit.get('commit',{}).get('committer',{}).get('date'),
                head_subject=commit.get('commit',{}).get('message','').split('\n')[0],error=result.get('error'))


with ThreadPoolExecutor(max_workers=3) as pool:
    pins=list(pool.map(pin,sorted(repositories)))
(out/'pins.json').write_text(json.dumps(pins,indent=2))
(out/'requests.json').write_text(json.dumps(events,indent=2))
old={row['repository']:row.get('head') for row in state['pinned_repositories']}
print('changed_or_new',[p for p in pins if p.get('head') and p['head']!=old.get(p['repository'])],flush=True)
