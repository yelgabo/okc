from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
from html.parser import HTMLParser
import re,html
import json,hashlib,datetime
out=Path('.build/scout-2026-11-03-2222');urls=['https://guild.1nterface.ai/?sort=new']+['https://guild.1nterface.ai/r/'+x+'?sort=new' for x in ['decode','bf16','moe','attention','prefill']]
def fetch(url):
 try:
  with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as r:b=r.read();status=r.status
  s=b.decode();links=[{'href':html.unescape(h),'text':html.unescape(re.sub('<[^>]+>', '', t))} for h,t in re.findall(r'<a[^>]+href=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</a>',s,re.S)];row={'url':url,'status':status,'sha256':hashlib.sha256(b).hexdigest(),'text':html.unescape(re.sub('<[^>]+>', '\n', s)),'links':links};(out/('guild-'+str(urls.index(url))+'.html')).write_bytes(b);return row
 except Exception as e:return {'url':url,'error':str(e)}
with ThreadPoolExecutor(max_workers=6) as pool:rows=list(pool.map(fetch,urls))
(out/'guild.json').write_text(json.dumps(rows,indent=2));print(json.dumps([{k:r.get(k) for k in ['url','status','error']} for r in rows],indent=2))
for r in rows:
 if r.get('status')==200:print(r['url'],[(a['href'],a['text']) for a in r['links'] if '/t/' in a['href'] or a['href'].startswith('/r/')][:35])
