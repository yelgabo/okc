from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, tarfile, shutil

out=Path('.build/scout-2026-11-03-2222');evidence=Path('docs/steering/evidence/2026-11-03-scout-h200-harness-2222');evidence.mkdir(parents=True,exist_ok=True)
analysis=json.loads((out/'analysis.json').read_text());code=json.loads((out/'code.json').read_text());coverage=json.loads((out/'query-coverage.json').read_text());sources=json.loads((out/'mdzor-source-manifest.json').read_text());requests=json.loads((out/'requests.json').read_text());current=json.loads((out/'mdzor-current.json').read_text());follow=json.loads((out/'mdzor-follow.json').read_text());head=follow[0]['data']
assert head['sha']=='d13ad99b45faf05934ec35c041522bc825870687'
assert all(not r.get('error') for r in coverage)
assert all(not p.get('error') for q in code['searches'] for p in q['pages'])
for row in sources:
 data=Path(row['local']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']
metadata=dict(repository='mdzor/muse-decode-bench',pin=head['sha'],date=head['commit']['committer']['date'],subject=head['commit']['message'],parents=head.get('parents'),changes=[dict(path=r['filename'],status=r['status'],blob=r['sha'],additions=r['additions'],deletions=r['deletions']) for r in current[0]['data']['files']],branches=follow[1]['data'],forks=follow[2]['data'],releases=follow[3]['data'])
(out/'mdzor-commit-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
leads=json.loads((out/'new-leads.json').read_text());background=[dict(url=r['data'].get('html_url'),title=r['data'].get('title'),head=r['data'].get('head',{}).get('sha'),updated_at=r['data'].get('updated_at'),scope='Different target hardware; source metadata and author claims read. No H200 challenge gain established.') for r in leads if isinstance(r.get('data'),dict) and r['data'].get('title')]
(out/'background-leads.json').write_text(json.dumps(background,indent=2)+'\n')
summary=dict(triggered_at='2026-11-03T22:22:25.068Z',packaged_at=datetime.now(timezone.utc).isoformat(),instructions_ref='fdf1eba297ecf2eaaa32d1efe6288a5a31dedf92',decision='NOTIFY',finding='New public local-H200 harness and asynchronous service source. Target execution, observer cost and judge parity unverified.',source=metadata,source_check=json.loads((out/'mdzor-source-check.json').read_text()),code_unique=analysis['code_unique'],new_code_blobs=len(analysis['new_code_files']),code_queries=code['searches'],other_queries=coverage,noncode_first_page_limited=sum(r['truncated_by_page_limit'] for r in coverage),search_limits='Known large copied/example repositories and own repository excluded from code queries. Other queries exclude own repository. Totals change across pages; a miss does not establish absence.',transient_api_errors=[{k:r.get(k) for k in ['path','retrieved_at','error']} for r in requests if r.get('error')],final_search_errors=[],previous_watched_default_heads_unchanged=47,watch_comparisons=json.loads((out/'watch-comparisons.json').read_text()),source_credit_counts=[15,16,21],guild_pages=18,guild_public_fragments=66,guild_new_fragments=0,indexed_web_queries=12,blog_hashes=json.loads((out/'blogs-http.json').read_text()),source_execution=False,service_requests=False,gpu_jobs=False,limits=['Current source pointers/hashes and bundled receipt committed; full captured source remains in the local scout archive.','Receipt names a local submission path with no code-hash binding to current service. It does not establish local/judge calibration.','Source read only; no numerical, compiled, hardware or timing qualification. Independent review unavailable under repository no-new-agents rule.','Cached social sources remain secondary; no authenticated Slack/Discord, restricted Guild bodies or encrypted messages accessed.'])
(evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['mdzor-source-manifest.json','mdzor-source-check.json','mdzor-commit-metadata.json','background-leads.json','query-coverage.json','guild-body-diff.json','watch-comparisons.json','web-coverage.json','social-access.json']:
 shutil.copyfile(out/name,evidence/name)
with tarfile.open(evidence/'benchmark-records.tar.gz','w:gz',compresslevel=9) as archive:
 for name in ['mdzor-source-manifest.json','mdzor-source-check.json','mdzor-commit-metadata.json']:
  archive.add(out/name,arcname=name)
 receipt=out/'mdzor-source/problem/profiles/submission.d778b118bd014795.json';archive.add(receipt,arcname='submission.d778b118bd014795.json')
with tarfile.open(evidence/'search-captures.tar.gz','w:gz',compresslevel=9) as archive:
 for path in sorted(out.iterdir()):
  if path.is_file() and path.suffix in ['.py','.json'] and path.name not in ['state-before.json','requests.json','new-leads.json','mdzor-follow.json','mdzor-current.json']:
   archive.add(path,arcname=path.name)
rows=[]
for path in sorted(evidence.iterdir()):
 if path.name=='manifest.json':continue
 data=path.read_bytes();rows.append(dict(path=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()))
(evidence/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(evidence_files=len(rows),evidence_bytes=sum(r['bytes'] for r in rows)),indent=2))
