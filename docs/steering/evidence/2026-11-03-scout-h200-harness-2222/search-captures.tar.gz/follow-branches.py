from api import api,out,ThreadPoolExecutor,json,Path,state
repos=['keell0renz/muse-open-kernel-challenge','alygg77/okc-muse-spark-kernels','NathenFernandes/muse-bf16-proj','ruwwww/open-kernel-challenge','vjeux/okc-2026','utterwqlnut/muse_bf16_proj']
repos=list(dict.fromkeys(repos+state.get('extended_branch_release_watch_repositories',[])))
paths=['/repos/'+r+'/'+x+'?per_page=100' for r in repos for x in ['branches','forks','releases']]
with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(api,paths))
(out/'branches-forks-releases.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 d=r.get('data',[])
 if not isinstance(d,list):print(r['path'],r.get('error'));continue
 print(r['path'],len(d),[{k:x.get(k) for k in ['name','full_name','created_at','pushed_at','tag_name','published_at']} for x in d][:12])
