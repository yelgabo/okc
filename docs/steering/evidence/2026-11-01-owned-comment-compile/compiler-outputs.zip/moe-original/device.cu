#include <cuda_runtime.h>



#include <cuda_bf16.h>
#include <stdint.h>

namespace {
namespace moe1 {

constexpr int kH = 4096;
constexpr int kI = 4096;
constexpr int kTopK = 8;
constexpr int kLocalMax = 32;
constexpr int kEmax = 4096;
constexpr int kJmax = kLocalMax + kEmax / 8;
constexpr int kUnitBytes = 36864;
constexpr int kUA = 512;
constexpr int kUB = 256;
constexpr int kNRB = 4;
// Named barriers: 1 syncs the compute warps after a unit's reads of its ring slot; 2 + b
// says partial buffer b is full (compute warps arrive, the helper waits); 6 + b says it is
// free again (the helper arrives, the compute warps wait).
constexpr int kBarUnit = 1;
constexpr int kBarFull = 2;
constexpr int kBarFree = 6;
// A spin that lasts this many cycles marks the launch failed instead of hanging the run.
constexpr long long kSpinLimit = 1ll << 31;

struct Params {
    const __nv_bfloat16* x;
    const int* topk_ids;
    const float* topk_w;
    const unsigned char* w13;
    const unsigned char* w2;
    const float* gs13;
    const float* gs2;
    const float* nw;
    __nv_bfloat16* inter;
    float* ybuf;
    float* ss;
    int* ctr;
    int* done_a;
    __nv_bfloat16* out;
    const unsigned char* w13f;
    const unsigned char* w2f;
    unsigned char* xa;
    unsigned char* xb;
    float* fix;
    int* fixcnt;
    int* xready;
    int* done_as;
    int M;
    int lo;
    int nloc;
    float eps;
    // Fat path stage costs by (phase, n-tile count); cost[0][1] == 0 means the compiled table.
    int cost[2][9];
    // The layer's local_start is an input tensor, read here instead of the host value.
    const int* lo_p;
    int pdl;
};

__device__ __forceinline__ void prefetch_l2_hint(const void* src, unsigned bytes) {
    asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(src), "r"(bytes)
                 : "memory");
}



__device__ __forceinline__ unsigned smem_u32(const void* p) {
    return static_cast<unsigned>(__cvta_generic_to_shared(p));
}

__device__ __forceinline__ void mbar_init(uint64_t* bar, unsigned count) {
    asm volatile("mbarrier.init.shared::cta.b64 [%0], %1;" :: "r"(smem_u32(bar)), "r"(count));
}

__device__ __forceinline__ void mbar_expect_tx(uint64_t* bar, unsigned bytes) {
    asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;"
                 :: "r"(smem_u32(bar)), "r"(bytes) : "memory");
}

__device__ __forceinline__ bool mbar_try(uint64_t* bar, unsigned parity) {
    unsigned ok;
    asm volatile("{\n.reg .pred p;\n"
                 "mbarrier.try_wait.parity.shared::cta.b64 p, [%1], %2;\n"
                 "selp.u32 %0, 1, 0, p;\n}\n"
                 : "=r"(ok) : "r"(smem_u32(bar)), "r"(parity) : "memory");
    return ok != 0;
}

__device__ __forceinline__ void bulk_load(void* dst, const void* src, unsigned bytes,
                                          uint64_t* bar, uint64_t policy) {
    asm volatile("cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes.L2::cache_hint"
                 " [%0], [%1], %2, [%3], %4;"
                 :: "r"(smem_u32(dst)), "l"(src), "r"(bytes), "r"(smem_u32(bar)), "l"(policy)
                 : "memory");
}

__device__ __forceinline__ uint64_t policy_evict_first() {
    uint64_t p;
    asm volatile("createpolicy.fractional.L2::evict_first.b64 %0, 1.0;" : "=l"(p));
    return p;
}

__device__ __forceinline__ void named_sync(int id, int count) {
    asm volatile("bar.sync %0, %1;" :: "r"(id), "r"(count) : "memory");
}

__device__ __forceinline__ void named_arrive(int id, int count) {
    asm volatile("bar.arrive %0, %1;" :: "r"(id), "r"(count) : "memory");
}

__device__ __forceinline__ int ld_lo(const int* p) {
    int v;
    asm volatile("ld.global.nc.s32 %0, [%1];" : "=r"(v) : "l"(p));
    return v;
}

__device__ __forceinline__ int ld_acquire(const int* p) {
    int v;
    asm volatile("ld.acquire.gpu.global.s32 %0, [%1];" : "=r"(v) : "l"(p) : "memory");
    return v;
}

__device__ __forceinline__ void prefetch_l2(const void* p) {
    asm volatile("prefetch.global.L2 [%0];" :: "l"(p));
}

__device__ __forceinline__ void fence_proxy_async() {
    asm volatile("fence.proxy.async.shared::cta;" ::: "memory");
}

// x tiles in global memory (xa from the gather, xb from phase A's epilogue) are written with
// generic stores and read by other CTAs through cp.async.bulk, which is the async proxy (PTX
// ISA 8.6, 9.7.10.28.2). Proxy-preserved base causality (8.9.5) does not carry a generic write
// to an async-proxy read without a proxy fence on the path, so every writer fences its own
// stores before the release, and the issuing thread fences again after its acquire: the
// bidirectional fence acts within one thread (9.7.15.4), and the second one keeps the chain
// valid under the reading where only the issuer's own later async operations are ordered.
// docs/runs-moe.md, "Proxy ordering of the x tiles", has the whole chain.
__device__ __forceinline__ void fence_proxy_async_global() {
    asm volatile("fence.proxy.async.global;" ::: "memory");
}

__device__ __forceinline__ void mma_bf16(float (&c)[4], const unsigned (&a)[4], unsigned b0,
                                         unsigned b1) {
    asm("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "
        "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
        : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3])
        : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}

__device__ __forceinline__ unsigned bmul2(unsigned a, unsigned s) {
    const __nv_bfloat162 r = __hmul2(*reinterpret_cast<__nv_bfloat162*>(&a),
                                     *reinterpret_cast<__nv_bfloat162*>(&s));
    return *reinterpret_cast<const unsigned*>(&r);
}

// One A fragment (16 rows x 16 k) from one repacked word. The repack permutes each word's
// 32 bits so that register j's two E2M1 codes land on bf16 bits {15, 8, 7, 6} (sign,
// exponent, mantissa) after at most one shift or rotate; the code then reads as its value
// times 2^-126. sg and sg8 hold the row's block scale (positive normal E4M3, checked in
// prepare) as bf16 scale * 2^119 in both halves, so the product is value * scale * 2^-7,
// exact in bf16; the epilogue multiplies by the global scale * 2^7.
__device__ __forceinline__ void dequant(unsigned w, unsigned sg, unsigned sg8, unsigned (&a)[4]) {
    constexpr unsigned kM = 0x81C081C0u;
    const unsigned r0 = w & kM;
    const unsigned r1 = (w << 6) & kM;
    const unsigned r2 = __funnelshift_r(w, w, 6) & kM;
    const unsigned r3 = ((w >> 4) & 0x00400040u) | ((w << 4) & 0x81808180u);
    a[0] = bmul2(r0, sg);
    a[1] = bmul2(r1, sg8);
    a[2] = bmul2(r2, sg);
    a[3] = bmul2(r3, sg8);
}

__device__ __forceinline__ unsigned scale_word(unsigned scw, int byte) {
    return __byte_perm(scw, 0u, 0x4040u + 0x0101u * byte) * 16u + 0x77807780u;
}

// scale_word with the multiplier passed in: k16 = 16 that the compiler cannot see keeps the
// multiply an IMAD on the FMA pipe (skinny kMode 5, 7, 8).
__device__ __forceinline__ unsigned scale_word_k(unsigned scw, int byte, unsigned k16) {
    return __byte_perm(scw, 0u, 0x4040u + 0x0101u * byte) * k16 + 0x77807780u;
}

__device__ __forceinline__ float bf16r(float x) {
    return __bfloat162float(__float2bfloat16_rn(x));
}

__device__ __forceinline__ unsigned word(const uint4& v, int i) {
    return i == 0 ? v.x : i == 1 ? v.y : i == 2 ? v.z : v.w;
}

__device__ __forceinline__ int warp_scan(int v, int lane) {
#pragma unroll
    for (int d = 1; d < 32; d <<= 1) {
        const int u = __shfl_up_sync(0xffffffffu, v, d);
        if (lane >= d) {
            v += u;
        }
    }
    return v;
}


__device__ __forceinline__ bool spin_failed(long long t0, int* ctr, int code) {
    if (clock64() - t0 < kSpinLimit) {
        return false;
    }
    atomicOr(ctr + 8, code);
    return true;
}


// Pair rows: expert-major, each warp's chunk of entries in order within an expert. pos[i] is
// entry i's pair row or -1; ent[q] (when given) is pair row q's entry.
template <int NWARPS>
__device__ __forceinline__ void position_pass(const signed char* eid_s, short* pos, short* ent,
                                              int (*wc)[kLocalMax], const int* off, int E) {
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int warp = tid >> 5;
    const int ch = ((E + NWARPS * 32 - 1) / (NWARPS * 32)) * 32;
    const int i0 = warp * ch;
    const int i1 = min(E, i0 + ch);
    wc[warp][lane] = 0;
    __syncwarp();
    for (int base = i0; base < i1; base += 32) {
        const int i = base + lane;
        const int eid = i < i1 ? eid_s[i] : -1;
        const unsigned peers = __match_any_sync(0xffffffffu, eid);
        if (eid >= 0 && lane == __ffs(peers) - 1) {
            wc[warp][eid] += __popc(peers);
        }
        __syncwarp();
    }
    __syncthreads();
    if (warp == 0) {
        int run = off[lane];
#pragma unroll
        for (int w = 0; w < NWARPS; ++w) {
            const int cw = wc[w][lane];
            wc[w][lane] = run;
            run += cw;
        }
    }
    __syncthreads();
    for (int base = i0; base < i1; base += 32) {
        const int i = base + lane;
        const int eid = i < i1 ? eid_s[i] : -1;
        const unsigned peers = __match_any_sync(0xffffffffu, eid);
        if (eid >= 0) {
            const int q = wc[warp][eid] + __popc(peers & ((1u << lane) - 1u));
            if (ent != nullptr) {
                ent[q] = static_cast<short>(i);
            }
            pos[i] = static_cast<short>(q);
        } else if (i < i1) {
            pos[i] = -1;
        }
        __syncwarp();
        if (eid >= 0 && lane == __ffs(peers) - 1) {
            wc[warp][eid] += __popc(peers);
        }
        __syncwarp();
    }
    __syncthreads();
}

// position_pass in two halves for fast_setup: the per-warp counts, and the positions once
// wc holds each warp's first pair row per expert. Same warp partition as position_pass.
template <int NWARPS>
__device__ __forceinline__ void position_count(const signed char* eid_s,
                                               int (*wc)[kLocalMax], int E) {
    const int lane = threadIdx.x & 31;
    const int warp = threadIdx.x >> 5;
    const int ch = ((E + NWARPS * 32 - 1) / (NWARPS * 32)) * 32;
    const int i0 = warp * ch;
    const int i1 = min(E, i0 + ch);
    wc[warp][lane] = 0;
    __syncwarp();
    for (int base = i0; base < i1; base += 32) {
        const int i = base + lane;
        const int eid = i < i1 ? eid_s[i] : -1;
        const unsigned peers = __match_any_sync(0xffffffffu, eid);
        if (eid >= 0 && lane == __ffs(peers) - 1) {
            wc[warp][eid] += __popc(peers);
        }
        __syncwarp();
    }
}

template <int NWARPS>
__device__ __forceinline__ void position_fill(const signed char* eid_s, short* pos,
                                              int (*wc)[kLocalMax], int E) {
    const int lane = threadIdx.x & 31;
    const int warp = threadIdx.x >> 5;
    const int ch = ((E + NWARPS * 32 - 1) / (NWARPS * 32)) * 32;
    const int i0 = warp * ch;
    const int i1 = min(E, i0 + ch);
    for (int base = i0; base < i1; base += 32) {
        const int i = base + lane;
        const int eid = i < i1 ? eid_s[i] : -1;
        const unsigned peers = __match_any_sync(0xffffffffu, eid);
        if (eid >= 0) {
            pos[i] = static_cast<short>(wc[warp][eid] + __popc(peers & ((1u << lane) - 1u)));
        } else if (i < i1) {
            pos[i] = -1;
        }
        __syncwarp();
        if (eid >= 0 && lane == __ffs(peers) - 1) {
            wc[warp][eid] += __popc(peers);
        }
        __syncwarp();
    }
}

// out[t] = sum over local slots of topk_w * rsqrt(ss / H + eps) * y, y already times
// (1 + post_norm_w). Items are (token, 4 * THREADS-column segment), 4 columns per thread.
template <int THREADS>
__device__ __forceinline__ void final_pass(const Params& p, const short* pos, const float* ss,
                                           int cta, int G) {
    constexpr int SEGS = kH / (4 * THREADS);
    const int tid = threadIdx.x;
    const float inv = 1.f / kH;
    for (int it = cta; it < p.M * SEGS; it += G) {
        const int t = it / SEGS;
        const int col = (it % SEGS) * (4 * THREADS) + tid * 4;
        float coef[kTopK];
        int qs[kTopK];
#pragma unroll
        for (int s = 0; s < kTopK; ++s) {
            qs[s] = pos[t * kTopK + s];
            float c = 0.f;
            if (qs[s] >= 0) {
                const float sv = __ldcg(ss + qs[s]);
                c = __ldg(p.topk_w + t * kTopK + s) * rsqrtf(sv * inv + p.eps);
            }
            coef[s] = c;
        }
        float4 acc = make_float4(0.f, 0.f, 0.f, 0.f);
#pragma unroll
        for (int s = 0; s < kTopK; ++s) {
            if (qs[s] >= 0) {
                const float4 y = __ldcg(reinterpret_cast<const float4*>(
                    p.ybuf + static_cast<size_t>(qs[s]) * kH + col));
                acc.x += coef[s] * y.x;
                acc.y += coef[s] * y.y;
                acc.z += coef[s] * y.z;
                acc.w += coef[s] * y.w;
            }
        }
        uint2 o;
        const __nv_bfloat162 lo2 = __floats2bfloat162_rn(acc.x, acc.y);
        const __nv_bfloat162 hi2 = __floats2bfloat162_rn(acc.z, acc.w);
        o.x = *reinterpret_cast<const unsigned*>(&lo2);
        o.y = *reinterpret_cast<const unsigned*>(&hi2);
        *reinterpret_cast<uint2*>(p.out + static_cast<size_t>(t) * kH + col) = o;
    }
}


// final_ss: out[t] as final_pass, with each route's sum of squares taken from its ybuf row here.
// One token per item; thread tid holds columns 8 tid .. 8 tid + 7. Pass 1 sums y^2 per local
// slot (warp shuffles, then the warps' partials through red), pass 2 re-reads the rows. ybuf is
// read only after the grid barrier, as final_pass reads it. red alternates between two halves
// by item parity, so one barrier per item orders the next item's writes after this item's
// reads of the other half.
template <int THREADS>
__device__ __forceinline__ void final_pass_ss(const Params& p, const short* pos, float* red,
                                              int bar_id, int cta, int G) {
    static_assert(THREADS * 8 == kH, "8 columns per thread");
    constexpr int kW = THREADS / 32;
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int warp = tid >> 5;
    const float inv = 1.f / kH;
    int par = 0;
    for (int t = cta; t < p.M; t += G, par ^= 1) {
        float* rb = red + par * (kW + 1) * kTopK;
        int qs[kTopK];
        float ps[kTopK];
#pragma unroll
        for (int s = 0; s < kTopK; ++s) {
            qs[s] = pos[t * kTopK + s];
            ps[s] = 0.f;
            if (qs[s] >= 0) {
                const float4* src = reinterpret_cast<const float4*>(
                    p.ybuf + static_cast<size_t>(qs[s]) * kH) + tid * 2;
                const float4 a = __ldcg(src);
                const float4 b = __ldcg(src + 1);
                ps[s] = a.x * a.x + a.y * a.y + a.z * a.z + a.w * a.w + b.x * b.x + b.y * b.y
                        + b.z * b.z + b.w * b.w;
            }
        }
#pragma unroll
        for (int s = 0; s < kTopK; ++s) {
            if (qs[s] >= 0) {
#pragma unroll
                for (int d = 16; d > 0; d >>= 1) {
                    ps[s] += __shfl_xor_sync(0xffffffffu, ps[s], d);
                }
            }
        }
        if (lane == 0) {
#pragma unroll
            for (int s = 0; s < kTopK; ++s) {
                rb[warp * kTopK + s] = ps[s];
            }
        }
        named_sync(bar_id, THREADS);
        float acc[8];
#pragma unroll
        for (int i = 0; i < 8; ++i) {
            acc[i] = 0.f;
        }
#pragma unroll
        for (int s = 0; s < kTopK; ++s) {
            if (qs[s] >= 0) {
                float sv = 0.f;
#pragma unroll
                for (int w = 0; w < kW; ++w) {
                    sv += rb[w * kTopK + s];
                }
                const float c = __ldg(p.topk_w + t * kTopK + s) * rsqrtf(sv * inv + p.eps);
                const float4* src = reinterpret_cast<const float4*>(
                    p.ybuf + static_cast<size_t>(qs[s]) * kH) + tid * 2;
                const float4 a = __ldcg(src);
                const float4 b = __ldcg(src + 1);
                acc[0] += c * a.x;
                acc[1] += c * a.y;
                acc[2] += c * a.z;
                acc[3] += c * a.w;
                acc[4] += c * b.x;
                acc[5] += c * b.y;
                acc[6] += c * b.z;
                acc[7] += c * b.w;
            }
        }
        uint4 o;
        unsigned* ow = reinterpret_cast<unsigned*>(&o);
#pragma unroll
        for (int i = 0; i < 4; ++i) {
            const __nv_bfloat162 v = __floats2bfloat162_rn(acc[2 * i], acc[2 * i + 1]);
            ow[i] = *reinterpret_cast<const unsigned*>(&v);
        }
        *reinterpret_cast<uint4*>(p.out + static_cast<size_t>(t) * kH + tid * 8) = o;
    }
}

__device__ __forceinline__ long long gtimer() {
    long long t;
    asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t));
    return t;
}










// ---- Fat path (M >= 17): jobs of up to 64 tokens, 256-row units streamed in 16 stages of
// 256 k, four consumer warpgroups (64 rows each) on register-A wgmma with the job's x stage
// in shared memory through a descriptor, one weights producer thread and one x producer
// thread, stream-K over stages with a global fixup for the units cut between CTAs.
constexpr int kNC = 16;
constexpr int kNTM = kNC * 32 + 64;
constexpr int kNWarpsM = kNTM / 32;
constexpr int kNSWMax = 5;
constexpr int kNSX = 3;
// 5 weight slots + 3 x 8 KB x slots, 4 + 3 x 16 KB, or 3 + 3 x 32 KB: the x slot size follows
// the launch's largest job (max n-tile count), the weights ring takes the rest.
constexpr int kRingBytes = kNSWMax * kUnitBytes + kNSX * 8192;
constexpr int kJmaxM = kLocalMax + kEmax / 64;
constexpr int kUAM = 512;
constexpr int kUBM = 256;
constexpr int kBarWg = 3;
constexpr int kBarGather = 7;
constexpr int kBarFin = 8;
constexpr int kBqMax = 64;
constexpr int kBqEmpty = -2;
// Relative cost of one stage by n8-tile count: the wgmma work grows with N while the bytes
// stay the same.
__constant__ int kCostA[9] = {0, 112, 135, 140, 158, 173, 185, 200, 207};
__constant__ int kCostB[9] = {0, 100, 104, 115, 123, 132, 144, 156, 174};
// The same for stages run on mma.sync (modes 8 to 10): at small N the consumers keep up with
// the weights stream, so the cost is closer to flat. First guesses, ranked by the bench.
__constant__ int kCostAm[9] = {0, 90, 100, 115, 130, 150, 170, 190, 210};
__constant__ int kCostBm[9] = {0, 85, 92, 104, 115, 130, 145, 160, 175};

// Modes 6 to 10 run jobs of at most mma_max(MODE) n8 tiles on mma.sync instead of wgmma: an
// RS wgmma group at N = 8 or 16 costs the consumers more than the stage takes to stream
// (bench 36b5b559b0344d0f: main-d2 197 us at bs32 against 139 loads-only and 150 for the
// mma.sync skinny kernel).
__host__ __device__ constexpr int mma_max(int mode) {
    return mode == 6 || mode == 9 || mode == 11 || mode == 12 || mode == 14 || mode == 15
                   || (mode >= 16 && mode <= 29) || (mode >= 31 && mode <= 51)
               ? 2
           : mode == 7 || mode == 10 ? 4
           : mode == 8 ? 8 : 0;
}

// Modes 12 and 13 (modes 6 and 0 otherwise) order the epilogue's and the fixup's global
// writes before their gpu-scope release or acquire with fence.acq_rel.gpu instead of
// __threadfence (fence.sc.gpu). The pattern stays fence, then bar.sync among the warpgroup,
// then one thread's red.release / atom.acq_rel: a fence.acq_rel followed by a strong write is
// a release pattern and a strong read followed by fence.acq_rel an acquire pattern (PTX ISA,
// Memory Consistency Model, "Release and Acquire Patterns"); fence.sc adds only the SC order,
// which no reader here relies on. The SASS is MEMBAR.ALL.GPU instead of MEMBAR.SC.GPU.
__host__ __device__ constexpr bool fence_ar(int mode) {
    return mode == 12 || mode == 13 || mode == 14 || (mode >= 15 && mode <= 29)
           || (mode >= 31 && mode <= 51);
}

// Modes 17 to 20 are mode 16 (two mma.sync chains, unit-aligned phase B) with one change each:
// 17 adds the clock stamps of mode 11 (timing only); 18 runs phase A alone (no phase B, no
// final pass: timing only, the GEMM1 gate's baseline); 19 runs phase A alone with every unit
// owned whole by one CTA (no cut unit, no fixup; timing only, the staged GEMM1 prototype); 20
// is 19's phase A followed by mode 16's phase B and final pass (a full, checked candidate).
// 22 is 20 with the stamps of 17. 23 is 20 with phase B units claimed at run time (dyn_b) and
// both phases walked largest n-tile count first; 24 is 23 with the stamps.
__host__ __device__ constexpr bool dual_chain(int mode) {
    return mode == 14 || (mode >= 16 && mode <= 29) || (mode >= 31 && mode <= 51);
}
__host__ __device__ constexpr bool is_diag(int mode) {
    return mode == 11 || mode == 17 || mode == 22 || mode == 24;
}
// Mode 25 is 23 with thread 0's globaltimer at the phase boundaries only (timing only). Mode
// 24's per-segment clock stamps add 14-18 us, too much to set its phase times beside the
// public kernel's eight thread-0 stamps; these cost a few stores per CTA.
__host__ __device__ constexpr bool is_light(int mode) {
    return mode == 25 || mode == 27 || mode == 29 || mode == 31 || mode == 33 || mode == 38
           || mode == 40 || mode == 41 || mode == 42 || mode == 44 || mode == 48 || mode == 49;
}
// Modes 26 and 27 (27 with the light stamps) are 23 with the setup of the public kernel's
// route(): every warp counts its slice of the routes once (match_any), the routing warp sums
// the per-warp counts instead of counting all E entries alone and the positions reuse them;
// and the x gather issues all of a CTA's row loads (16 B each) before its stores. Mode 25
// put setup at 7 / 11 / 16 us of routing at 32 / 128 / 256 tokens against 2-3 us for the
// public kernel (check d1f587760b1241dc).
__host__ __device__ constexpr bool fast_setup(int mode) {
    return (mode >= 26 && mode <= 29) || (mode >= 31 && mode <= 51);
}
// Modes 28 and 29 (29 with the light stamps) are 26 with a leaner consumer stage. The stage
// loop was 389 instructions against the public kernel's 322 for the same dequant and MMA core
// (profiles/sass_stage_loop_vs_public.2026-10-29.txt); with four consumer warps per scheduler
// at about 1 us per stage, issue slots are a plausible limit (not measured). Per stage: the
// ring size and x slot 0's address come from registers set once per launch instead of three
// shared loads, and the S.ord sort takes one pass instead of eight dependent rounds. The
// weights slot release keeps its fence.proxy.async.shared::cta but moves behind the stage's
// first wgmma group, off the path from the full-barrier wait to the first wgmma, and every
// consumer thread fences and arrives itself (wempty and, on the mma.sync path, xempty count
// kNC * 32), so each thread's generic reads reach the producer's acquire through its own
// program order (docs/runs-moe.md, "Ordering of the ring slot releases"). 26's lane-0
// release after __syncwarp at the moved point makes ptxas serialize the wgmma groups (C7513,
// 400 instructions per stage), so that variant was dropped.
__host__ __device__ constexpr bool lean_stage(int mode) {
    return mode == 28 || mode == 29 || (mode >= 31 && mode <= 51);
}
// Modes 31 and 33 (timing only) are 28 and 32 with the light stamps plus phase A counters per
// consumer warp (S.dg rows 0-15): cycles spent in weights and x waits, cycles from a unit's
// start to its accumulators, epilogue cycles, deferred publish cycles, stages, units and
// n-tiles; and the producers' phase A cycles waiting for a free slot. Since 2026-10-29 a wait
// is timed from before its first try_wait (mbar_wait_cyc); before that, a wait that succeeded
// on its first try counted zero and a failed first try's time was dropped.
// Mode 41 is 37 with these counters plus the same per-warp counters over phase B (pb_diag),
// mode 42 is 37 with the light stamps only (timing only, the overhead baseline for 41).
// Mode 44 is 43 with mode 41's counters.
__host__ __device__ constexpr bool pa_diag(int mode) {
    return mode == 31 || mode == 33 || mode == 38 || mode == 40 || mode == 41 || mode == 44;
}
// pb_diag: phase B counters per consumer warp go to global memory after S.dg's 18 x 8 int64
// per CTA (SmemMain stays the size the production modes have): p.inter as int64 from G * 144,
// 16 x 8 per CTA, columns as pa_record's, with column 7 the cycles waiting for a claimed unit.
__host__ __device__ constexpr bool pb_diag(int mode) {
    return mode == 41 || mode == 44;
}
// Modes 43 and 44 (44 with mode 41's counters) are 37 with the public kernel's stage structure
// on the wgmma path: a warp holds one 4-step code group (one uint4 and its scale word) and the
// next, not the stage's 16 code registers, and issues the next stage's weights and x waits and
// its first code group under the current stage's last wgmma group. Mode 41 put the consumers'
// waits at about 20% of the stage loops, 210-230 cycles each, while the producers found the ring
// full 70% of phase A (check ca43908f02874886), so the wait looks like a serial cost at the
// stage start rather than a stream that falls behind. The weights slot is released one wgmma
// group after the stage's last code load is issued (behind the sixth of eight groups, not the
// first), with mode 28's per-thread fence.proxy.async.shared::cta and arrive (docs/runs-moe.md,
// "Ordering of the ring slot releases"; the moved release under "Code groups with the next
// stage hoisted").
__host__ __device__ constexpr bool grp_codes(int mode) {
    return mode == 43 || mode == 44 || (mode >= 47 && mode <= 51);
}
// Mode 47 is 43 without the hoist: the code groups as 43, the waits and the first group at the
// stage's start as 37. In check 9d94ac75f4724b52, 43 beat 37 by 2.7 us at 256 tokens while
// 44's cycles per wait did not fall (239 against 41's 223) and its epilogue got shorter, which
// points at 43's smaller spill (8 / 100 B against 156 / 416) rather than the hoist.
__host__ __device__ constexpr bool grp_hoist(int mode) {
    return mode == 43 || mode == 44;
}
// Modes 48 and 49 are timing-only twins of 47: 48 with the light stamps, 49 with the light stamps
// and per-warp stage stamps (skew_st). Mode 41's counters put the consumers' waits at 210-240
// cycles at every stage boundary and 43's hoist did not shorten them, so the open question is
// whether the 16 warps of a CTA drift apart and a slot refills only behind the slowest one.
// skew_st: lane 0 of every consumer warp writes clock64 at each wgmma stage's start, after its
// weights wait, after its x wait and after its weights-slot arrive; the producers write their
// issue time per stage. Stage q is the weights ring position (lap * nsw + slot), which the x
// ring position equals. p.inter as int64 from kSkOff, kSkPer words per CTA: 8 header words
// (nsw, clock64 and globaltimer at the consumers' start and at the CTA's end), then per stage
// q < kSkQ 16 x 4 consumer words and 2 producer words. The mma.sync stages (jobs of 1 or 2
// n-tiles) are not stamped; the bench zeroes the region before the stamped launch.
__host__ __device__ constexpr bool skew_st(int mode) {
    return mode == 49;
}
// Mode 50 is 47 with each route's sum of squares formed in the final pass from its finished ybuf
// row (the public kernel's OKC_WGSFINSS) instead of in the phase B epilogue: the epilogue keeps
// its ybuf stores and drops its three shuffle rounds and two FP32 atomics per n-tile. Mode 41
// put the phase B epilogue at 3.76 us per unit at 256 tokens against phase A's 1.71
// (ca43908f02874886), and in d47c78bdc130424b phase B is the largest piece of the same-process
// gap to the public kernel summed over 128 and 256 tokens (+2.9 and +7.3 us). The final pass
// then takes one token per CTA iteration and reads its rows twice, the second time from L2.
__host__ __device__ constexpr bool final_ss(int mode) {
    return mode == 50 || mode == 51;
}
// Mode 51 is 50 with the final-pass sums only from kFinssMinM tokens up, 47's path below. In
// 50's gate (8a7051fa926e43e1) 50 minus 47 was -4.1 to -8.3 us at 128 and 256 tokens but +0.7 at
// 32 on layer routing: one token per final-pass item leaves 100 of 132 CTAs idle at 32 tokens.
// The choice is uniform per launch (p.M), so the epilogue and the final pass agree on it.
constexpr int kFinssMinM = 64;
template <int MODE>
__device__ __forceinline__ bool finss_on(int m) {
    return final_ss(MODE) && (MODE != 51 || m >= kFinssMinM);
}
// Modes 32 to 34 publish a finished phase A unit (proxy fence, fence_gpu, the warpgroup's
// bar.sync, red.release on done_as) at the start of the warpgroup's next phase A unit's second
// stage instead of right after the SwiGLU stores, and at the end of phase A for the last one;
// the public kernel defers the same release (wgs_flush). Mode 28 runs two MEMBAR.ALL.GPU,
// CCTL.IVALL and a bar.sync per unit while its stores are still in flight, with every
// warpgroup of the CTA idle (docs/runs-moe.md, "Phase A at 256 tokens").
__host__ __device__ constexpr bool defer_a(int mode) {
    return mode >= 32 && mode <= 35;
}
// Mode 35 is 32 with the sums-of-squares pointer and the owned unit count read from shared
// memory at each use (ld.volatile.shared, as the public kernel's ss_cur): hoisted out of the
// unit loops they stay live across the stage loops at the 96-register cap and spill.
__host__ __device__ constexpr bool vol_regs(int mode) {
    return mode == 35;
}
// Mode 34 is 32 without the per-thread fence_gpu before the bar.sync: the bar.sync and the
// releasing thread's red.release order every writer's stores before the release by
// themselves (the chain in docs/runs-moe.md, "Proxy ordering of the x tiles", steps 2-3).
// Each writer keeps its fence.proxy.async.global.
__host__ __device__ constexpr bool bar_release_a(int mode) {
    return mode == 34 || mode == 37 || (mode >= 39 && mode <= 51);
}
// Modes 36 to 38 are 28 with SiLU's reciprocal as one MUFU.RCP (rcp.approx.ftz, as the public
// kernel's __fdividef): __frcp_rn compiles to MUFU.RCP plus a range check that branches to a
// subroutine, inside a convergence region per element, 16 per thread per unit at 8 n-tiles.
// Mode 31's counters put mode 28's phase A epilogue at 3.0 us per unit at 256 tokens with the
// consumers never waiting for weights or x (check c7db20e053254b52). [Corrected 2026-10-29: that
// counter skipped the first try_wait; timed in full the consumers wait about 20% of the stage
// loops, check ca43908f02874886.] 37 is 36 without the per-thread fence_gpu (as 34), 38 is 36
// with the phase A counters (timing only).
__host__ __device__ constexpr bool fast_silu(int mode) {
    return mode >= 36 && mode <= 51;
}
// Modes 39 and 40 (40 with the counters) are 37 with the SwiGLU outputs stored in pairs: in
// the xb layout a warp owns two adjacent bf16 of each 16-byte token row, held by lanes g and
// g ^ 1, so one shuffle lets the even lane store token tok's pair and the odd lane token tok +
// 1's as one 4-byte store each, half the store instructions and sector writes of 2-byte stores.
// With 37's fences gone, mode 33's counters put the stores and SwiGLU at 1.6 us per unit at
// 256 tokens (check c7db20e053254b52).
__host__ __device__ constexpr bool pair_st(int mode) {
    return mode == 39 || mode == 40;
}
__host__ __device__ constexpr bool a_only(int mode) {
    return mode == 18 || mode == 19 || mode == 45;
}
__host__ __device__ constexpr bool own_a(int mode) {
    return mode == 19 || mode == 20 || (mode >= 22 && mode <= 29) || (mode >= 31 && mode <= 45)
           || (mode >= 47 && mode <= 51);
}
// Modes 23 and 24: a CTA's weights producer claims phase B units one at a time from a global
// counter, in S.ord order, when its ring has a free slot. Owned phase A leaves CTAs with up to
// one unit more than others and mode 20's static phase B ranges ignore that, so the CTA that
// frees first takes the next unit; S.ord puts the jobs whose phase A rounds come first (the
// snake deal walks S.ord) at the front, so claimed units find their inputs ready.
__host__ __device__ constexpr bool dyn_b(int mode) {
    return (mode >= 23 && mode <= 29) || (mode >= 31 && mode <= 44)
           || (mode >= 46 && mode <= 51);
}
// Mode 21 is the second launch of the staged pair (19, then 21): phase B and the final pass
// alone, on the xb a previous launch wrote. That launch completed before this one started
// (stream order, or griddepcontrol.wait under PDL: PTX ISA 9.7.15.14, 8.9.4), so phase B
// takes no done_as wait and no x gather; the issuing thread keeps its proxy fence.
// Modes 45 and 46 are the staged pair rebuilt on mode 37's components (lean stage, setup,
// SiLU, publish), its revisit trigger in docs/ruled-out.md: 45 is 19's phase A alone on owned
// units, 46 is 21's phase B and final pass alone with 37's claimed phase B units. 19 and 21
// lost to the fused 16 and 20 by 24-30 us (checks 9332e2a49aff4ff2, e221858b020c4dee), before
// 23, 26, 28 and 37 made the fused kernel's phase B, setup and stage loop cheaper.
__host__ __device__ constexpr bool b_only(int mode) {
    return mode == 21 || mode == 46;
}

template <bool AR>
__device__ __forceinline__ void fence_gpu() {
    if constexpr (AR) {
        asm volatile("fence.acq_rel.gpu;" ::: "memory");
    } else {
        __threadfence();
    }
}

// Modes 11 and 17 (modes 6 and 16 with clock stamps; timing only, never a policy choice):
// each consumer warp sums its cycles waiting for weights, waiting for x, computing and in the
// epilogue or fixup over its segments of both paths (wgmma segments since 2026-10-29); the
// producers sum their waits; thread 0 records globaltimer and clock64 at the kernel's phase
// boundaries and when its phase A segments end. S.dg goes to p.inter (unused on the fat path)
// at the end, 18 x 8 int64 per CTA; _diag_report has the layout.

template <int MODE>
__device__ __forceinline__ int stage_cost(int ph, int ntt) {
    constexpr bool kFlat = MODE >= 8 && MODE <= 10;
    if (kFlat && ntt <= mma_max(MODE)) {
        return ph ? kCostBm[ntt] : kCostAm[ntt];
    }
    return ph ? kCostB[ntt] : kCostA[ntt];
}

constexpr int kSkQ = 256;
constexpr int kSkRow = kNC * 4 + 2;
constexpr int kSkPer = 8 + kSkQ * kSkRow;
constexpr long long kSkOff = 1ll << 20;

__device__ __forceinline__ long long* sk_cta(const Params& p) {
    return reinterpret_cast<long long*>(p.inter) + kSkOff
           + static_cast<long long>(blockIdx.x) * kSkPer;
}

// A predicated store rather than a lane-0 branch: a divergent block between the wgmma groups of
// a stage makes ptxas serialize them (C7513, docs/ruled-out.md).
template <int MODE>
__device__ __forceinline__ void sk_stamp(const Params& p, int q, int k, bool on) {
    if constexpr (skew_st(MODE)) {
        const long long c = clock64();
        long long* a = sk_cta(p) + 8 + static_cast<long long>(q) * kSkRow + k;
        asm volatile("{\n .reg .pred sp;\n setp.ne.s32 sp, %2, 0;\n @sp st.global.b64 [%0], %1;\n}"
                     :: "l"(a), "l"(c), "r"(static_cast<int>(on && q < kSkQ)));
    }
}

struct __align__(128) SmemMain {
    unsigned char rings[kRingBytes];
    uint64_t wfull[kNSWMax];
    uint64_t wempty[kNSWMax];
    uint64_t xfull[kNSX];
    uint64_t xempty[kNSX];
    int cnt[kLocalMax];
    int off[kLocalMax];
    int job0[kLocalMax];
    int wc[kNWarpsM][kLocalMax];
    int job_e[kJmaxM];
    int job_q[kJmaxM];
    int job_n[kJmaxM];
    int job_ntt[kJmaxM];
    int job_xo[kJmaxM];
    int pa[kJmaxM + 1];
    int pb[kJmaxM + 1];
    short pos[kEmax];
    signed char eid[kEmax];
    int njobs;
    int nsw;
    int xsz;
    int xoff;
    int gsb[2];
    int gse[2];
    int fix_last[4];
    int cost[2][9];
    int align_b;
    // Owned phase A (own_a): jobs by n-tile count, largest first, and this CTA's unit count.
    int ord[kJmaxM];
    int own_n;
    // dyn_b: the i-th claimed phase B unit (index into S.ord order, 16 per job), -1 when the
    // claims are exhausted, kBqEmpty until the weights producer writes it.
    int bq[kBqMax];
    long long dg[18][8];
    float* ssp;
};

// Ring positions shared by the consumers and the producers: slot and lap per ring, the lap
// parity being the mbarrier phase to wait for.
struct Ring {
    int ws;
    int wlap;
    int xs;
    int xlap;
    // lean_stage only, set once per launch: weights ring slots, x slot 0's shared address
    // and the x slot size in bytes.
    int nsw;
    unsigned xb;
    unsigned xsz;
};

__device__ __forceinline__ void ring_next_w(Ring& r, int nsw) {
    if (++r.ws == nsw) {
        r.ws = 0;
        ++r.wlap;
    }
}

__device__ __forceinline__ void ring_next_x(Ring& r) {
    if (++r.xs == kNSX) {
        r.xs = 0;
        ++r.xlap;
    }
}

__device__ __forceinline__ void mbar_arrive(uint64_t* bar) {
    asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0];" :: "r"(smem_u32(bar)) : "memory");
}

__device__ __forceinline__ void mbar_arrive_n(uint64_t* bar, unsigned n) {
    asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0], %1;" :: "r"(smem_u32(bar)), "r"(n)
                 : "memory");
}

// lean_stage modes: every consumer thread releases the weights slot (and, on the mma.sync
// path, the x slot) itself, so the empty barriers count kNC * 32 arrivals; a release that
// stays warp-level (the wgmma path's x slot) arrives once for the whole warp.
template <int MODE>
__device__ __forceinline__ void x_release_warp(uint64_t* bar, int lane) {
    if (lane == 0) {
        if constexpr (lean_stage(MODE)) {
            mbar_arrive_n(bar, 32);
        } else {
            mbar_arrive(bar);
        }
    }
}

__device__ __forceinline__ void mbar_wait_to(uint64_t* bar, unsigned parity, int* ctr, int code) {
    if (mbar_try(bar, parity)) {
        return;
    }
    const long long t0 = clock64();
    while (!mbar_try(bar, parity)) {
        if (spin_failed(t0, ctr, code)) {
            break;
        }
    }
}

// mbar_wait_to returning the cycles of the whole wait (pa_diag). The clock starts before the
// first try: try_wait is potentially blocking (PTX ISA 9.4, mbarrier.test_wait /
// mbarrier.try_wait), so a first try that returns true may have suspended the thread until the
// phase completed, and one that returns false may have suspended it for a time limit first.
__device__ __forceinline__ unsigned mbar_wait_cyc(uint64_t* bar, unsigned parity, int* ctr,
                                                  int code) {
    const long long t0 = clock64();
    while (!mbar_try(bar, parity)) {
        if (spin_failed(t0, ctr, code)) {
            break;
        }
    }
    return static_cast<unsigned>(clock64() - t0);
}

template <int MODE, int PH>
__device__ __forceinline__ unsigned mbar_wait_m(uint64_t* bar, unsigned parity, int* ctr,
                                                int code) {
    if constexpr (pa_diag(MODE) && (PH == 0 || pb_diag(MODE))) {
        return mbar_wait_cyc(bar, parity, ctr, code);
    } else {
        mbar_wait_to(bar, parity, ctr, code);
        return 0u;
    }
}

__device__ __forceinline__ void spin_ge(const int* p, int target, int* ctr, int code) {
    if (ld_acquire(p) >= target) {
        return;
    }
    const long long t0 = clock64();
    while (ld_acquire(p) < target) {
        __nanosleep(64);
        if (spin_failed(t0, ctr, code)) {
            break;
        }
    }
}

// The claimed-unit queue S.bq: one writer (the weights producer), readers in the same CTA.
__device__ __forceinline__ void st_release_cta(int* p, int v) {
    asm volatile("st.release.cta.shared::cta.s32 [%0], %1;" :: "r"(smem_u32(p)), "r"(v)
                 : "memory");
}

__device__ __forceinline__ int ld_acquire_cta(const int* p) {
    int v;
    asm volatile("ld.acquire.cta.shared::cta.s32 %0, [%1];" : "=r"(v) : "r"(smem_u32(p))
                 : "memory");
    return v;
}

__device__ __forceinline__ int bq_get(const SmemMain& S, int i, int* ctr) {
    int m = ld_acquire_cta(&S.bq[i]);
    if (m != kBqEmpty) {
        return m;
    }
    const long long t0 = clock64();
    while ((m = ld_acquire_cta(&S.bq[i])) == kBqEmpty) {
        __nanosleep(32);
        if (spin_failed(t0, ctr, 256)) {
            return -1;
        }
    }
    return m;
}

__device__ __forceinline__ void bulk_load_plain(void* dst, const void* src, unsigned bytes,
                                                uint64_t* bar) {
    asm volatile("cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes"
                 " [%0], [%1], %2, [%3];"
                 :: "r"(smem_u32(dst)), "l"(src), "r"(bytes), "r"(smem_u32(bar)) : "memory");
}

// No-swizzle K-major descriptor: lbo between core matrices along k, sbo along n.
__device__ __forceinline__ uint64_t make_desc(const void* ptr, int lbo, int sbo) {
    const uint64_t addr = smem_u32(ptr);
    return ((addr & 0x3ffffu) >> 4) | (static_cast<uint64_t>(lbo >> 4) << 16)
           | (static_cast<uint64_t>(sbo >> 4) << 32);
}

__device__ __forceinline__ void wg_fence() {
    asm volatile("wgmma.fence.sync.aligned;" ::: "memory");
}

__device__ __forceinline__ void wg_commit() {
    asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory");
}

template <int N>
__device__ __forceinline__ void wg_wait() {
    asm volatile("wgmma.wait_group.sync.aligned %0;" :: "n"(N) : "memory");
}

__device__ __forceinline__ void red_add_v4(float4* p, float4 v) {
    asm volatile("red.global.add.v4.f32 [%0], {%1, %2, %3, %4};"
                 :: "l"(p), "f"(v.x), "f"(v.y), "f"(v.z), "f"(v.w) : "memory");
}

__device__ __forceinline__ int atom_add_acqrel(int* p, int v) {
    int old;
    asm volatile("atom.acq_rel.gpu.global.add.s32 %0, [%1], %2;" : "=r"(old) : "l"(p), "r"(v)
                 : "memory");
    return old;
}

__device__ __forceinline__ void red_release_add(int* p, int v) {
    asm volatile("red.release.gpu.global.add.s32 [%0], %1;" :: "l"(p), "r"(v) : "memory");
}

__device__ __forceinline__ void wgmma_n8(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n8k16.f32.bf16.bf16 {%0, %1, %2, %3}, "
                 "{%4, %5, %6, %7}, %8, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n16(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n16k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7}, "
                 "{%8, %9, %10, %11}, %12, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n24(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n24k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11}, "
                 "{%12, %13, %14, %15}, %16, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n32(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n32k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15}, "
                 "{%16, %17, %18, %19}, %20, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11]), "+f"(d[12]), "+f"(d[13]), "+f"(d[14]), "+f"(d[15])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n40(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n40k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15, %16, %17, %18, %19}, "
                 "{%20, %21, %22, %23}, %24, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11]), "+f"(d[12]), "+f"(d[13]), "+f"(d[14]), "+f"(d[15]), "+f"(d[16]), "+f"(d[17]), "+f"(d[18]), "+f"(d[19])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n48(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n48k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15, %16, %17, %18, %19, %20, %21, %22, %23}, "
                 "{%24, %25, %26, %27}, %28, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11]), "+f"(d[12]), "+f"(d[13]), "+f"(d[14]), "+f"(d[15]), "+f"(d[16]), "+f"(d[17]), "+f"(d[18]), "+f"(d[19]), "+f"(d[20]), "+f"(d[21]), "+f"(d[22]), "+f"(d[23])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n56(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n56k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15, %16, %17, %18, %19, %20, %21, %22, %23, %24, %25, %26, %27}, "
                 "{%28, %29, %30, %31}, %32, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11]), "+f"(d[12]), "+f"(d[13]), "+f"(d[14]), "+f"(d[15]), "+f"(d[16]), "+f"(d[17]), "+f"(d[18]), "+f"(d[19]), "+f"(d[20]), "+f"(d[21]), "+f"(d[22]), "+f"(d[23]), "+f"(d[24]), "+f"(d[25]), "+f"(d[26]), "+f"(d[27])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

__device__ __forceinline__ void wgmma_n64(float (&d)[32], const unsigned (&a)[4],
                                           uint64_t desc) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n64k16.f32.bf16.bf16 {%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15, %16, %17, %18, %19, %20, %21, %22, %23, %24, %25, %26, %27, %28, %29, %30, %31}, "
                 "{%32, %33, %34, %35}, %36, p, 1, 1, 0;\n}\n"
                 : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11]), "+f"(d[12]), "+f"(d[13]), "+f"(d[14]), "+f"(d[15]), "+f"(d[16]), "+f"(d[17]), "+f"(d[18]), "+f"(d[19]), "+f"(d[20]), "+f"(d[21]), "+f"(d[22]), "+f"(d[23]), "+f"(d[24]), "+f"(d[25]), "+f"(d[26]), "+f"(d[27]), "+f"(d[28]), "+f"(d[29]), "+f"(d[30]), "+f"(d[31])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(desc));
}

template <int NTT>
__device__ __forceinline__ void wgmma(float (&d)[32], const unsigned (&a)[4], uint64_t desc) {
    if constexpr (NTT == 1) { wgmma_n8(d, a, desc); }
    if constexpr (NTT == 2) { wgmma_n16(d, a, desc); }
    if constexpr (NTT == 3) { wgmma_n24(d, a, desc); }
    if constexpr (NTT == 4) { wgmma_n32(d, a, desc); }
    if constexpr (NTT == 5) { wgmma_n40(d, a, desc); }
    if constexpr (NTT == 6) { wgmma_n48(d, a, desc); }
    if constexpr (NTT == 7) { wgmma_n56(d, a, desc); }
    if constexpr (NTT == 8) { wgmma_n64(d, a, desc); }
}

// Pins the live accumulators so the compiler neither copies them across an async wgmma nor
// moves them to local memory.
template <int NTT>
__device__ __forceinline__ void acc_fence(float (&d)[32]) {
#pragma unroll
    for (int i = 0; i < 4 * NTT; ++i) {
        asm volatile("" : "+f"(d[i]) :: "memory");
    }
}

// A wgmma keeps reading its A registers until it retires, which the compiler cannot see; a
// group's fragments are pinned after the wait that retires it, so the next group's dequant
// lands in other registers instead of behind a full pipeline drain.
__device__ __forceinline__ void a_pin(unsigned (&a)[2][4]) {
#pragma unroll
    for (int i = 0; i < 2; ++i) {
#pragma unroll
        for (int k = 0; k < 4; ++k) {
            asm volatile("" : "+r"(a[i][k]) :: "memory");
        }
    }
}

// Global stage index where CTA k's range of phase ph begins: the cost prefix over jobs
// (pa / pb) split evenly over the grid.
__device__ __forceinline__ int stage_at(const SmemMain& S, int ph, int k, int G) {
    const int nj = S.njobs;
    const int spj = ph ? kUBM : kUAM;
    if (k >= G) {
        return nj * spj;
    }
    if (k <= 0 || nj == 0) {
        return 0;
    }
    const int* pre = ph ? S.pb : S.pa;
    const unsigned total = static_cast<unsigned>(pre[nj]);
    const unsigned target = total * static_cast<unsigned>(k) / static_cast<unsigned>(G);
    int j = 0;
    while (j + 1 < nj && static_cast<unsigned>(pre[j + 1]) <= target) {
        ++j;
    }
    const int cost = S.cost[ph][S.job_ntt[j]];
    const int s = j * spj + static_cast<int>((target - static_cast<unsigned>(pre[j]))
                                             / static_cast<unsigned>(cost));
    // Modes 15 and 16: phase B boundaries on the nearest unit (16 stages) so no phase B segment is cut;
    // the cost model put a cut phase B segment at about 10 us (docs/runs-moe.md, "Cost model").
    return ph && S.align_b ? (s + 8) & ~15 : s;
}

__device__ __forceinline__ int seg_count(int b, int e) {
    return b >= e ? 0 : ((e - 1) >> 4) - (b >> 4) + 1;
}

// The i-th segment of stage range [b, e) in execution order: the owned trailing partial unit
// first, so its share of a cut unit lands early, then the rest in order.
__device__ __forceinline__ void seg_get(int b, int e, int i, int& gb, int& ge) {
    const int ub = b >> 4;
    const int ue = (e - 1) >> 4;
    if (ub == ue) {
        gb = b;
        ge = e;
        return;
    }
    int k = i;
    if ((e & 15) != 0) {
        if (k == 0) {
            gb = ue << 4;
            ge = e;
            return;
        }
        --k;
    }
    if (k == 0) {
        gb = b;
        ge = (ub + 1) << 4;
        return;
    }
    gb = (ub + k) << 4;
    ge = gb + 16;
}

struct SegInfo {
    int j;
    int u;
    int st_b;
    int st_e;
    int slot;
    bool partial;
    // Owned phase A: the unit's round in own_unit (the CTA's r-th unit), else -1.
    int r;
};

// Owned phase A (own_a): the units of all jobs sorted by n-tile count, largest first (S.ord,
// 32 units per job), dealt to the CTAs in snake order, so round r gives CTA c the unit
// r G + c (r even) or r G + G - 1 - c (r odd). Every unit runs whole on one CTA.
__device__ __forceinline__ int own_unit(int r, int cta, int G) {
    return r * G + ((r & 1) ? G - 1 - cta : cta);
}

template <int MODE>
__device__ __forceinline__ int seg_n(const SmemMain& S, int ph) {
    if (own_a(MODE) && ph == 0) {
        return S.own_n;
    }
    return seg_count(S.gsb[ph], S.gse[ph]);
}

template <int MODE>
__device__ __forceinline__ void seg_at(const SmemMain& S, int ph, int i, int cta, int G, int& gb,
                                       int& ge) {
    if (own_a(MODE) && ph == 0) {
        const int k = own_unit(i, cta, G);
        gb = S.ord[k >> 5] * kUAM + (k & 31) * 16;
        ge = gb + 16;
        return;
    }
    seg_get(S.gsb[ph], S.gse[ph], i, gb, ge);
}

// A cut unit's fixup slot is the index of the CTA holding its first stage.
__device__ __forceinline__ SegInfo seg_info(const SmemMain& S, int ph, int gb, int ge, int cta,
                                            int G) {
    SegInfo si;
    si.j = ph ? (gb >> 8) : (gb >> 9);
    si.u = (gb & (ph ? 255 : 511)) >> 4;
    si.st_b = gb & 15;
    si.st_e = ((ge - 1) & 15) + 1;
    si.partial = si.st_b != 0 || si.st_e != 16;
    si.slot = cta;
    si.r = -1;
    if (si.st_b != 0) {
        const int gs0 = gb & ~15;
        int k = cta;
        while (k > 0 && stage_at(S, ph, k, G) > gs0) {
            --k;
        }
        si.slot = k;
    }
    return si;
}

template <bool FAST>
__device__ __forceinline__ float silu_rcp(float x) {
    if constexpr (FAST) {
        float r;
        asm("rcp.approx.ftz.f32 %0, %1;" : "=f"(r) : "f"(x));
        return r;
    } else {
        return __frcp_rn(x);
    }
}

// The release of a finished phase A unit on done_as[target]: every writer's proxy fence (and
// fence_gpu unless bar_release_a), the warpgroup's bar.sync, one red.release.
template <int MODE>
__device__ __forceinline__ void publish_a(const Params& p, int target, int wg, int tid_wg) {
    fence_proxy_async_global();
    if constexpr (!bar_release_a(MODE)) {
        fence_gpu<fence_ar(MODE)>();
    }
    named_sync(kBarWg + wg, 128);
    if (tid_wg == 0) {
        red_release_add(p.done_as + target, 1);
    }
}

// SwiGLU of a finished phase A unit straight into phase B's x layout (stage u / 2 of the job,
// 16-byte row per token and 8-feature chunk), then one release per warpgroup on the stage's
// readiness counter (PUB), or the counter's index returned for a later publish_a.
template <int NTT, int MODE, bool PUB>
__device__ __forceinline__ int epilogue_a(const Params& p, SmemMain& S,
                                          const float (&acc)[32], int j, int u, int wg,
                                          int w, int tid_wg) {
    const int lane = tid_wg & 31;
    const int g = lane >> 2;
    const int t4 = lane & 3;
    const int ntok = S.job_n[j];
    const float gsa = __ldg(p.gs13 + S.job_e[j]) * 128.f;
    const int rb = 16 * u + 4 * wg + w;
    const int st = u >> 1;
    // Feature kk of the stage sits at mma-k position 16 (4 c + s) + (j < 2 ? 2 t4k + j :
    // 8 + 2 t4k + j - 2) with kk = 64 c + 16 t4k + 4 s + j (the fat layout's k order).
    const int kk = 8 * (rb & 31) + g;
    const int step = 4 * (kk >> 6) + ((kk >> 2) & 3);
    const int chunk8 = 2 * step + ((kk & 3) >> 1);
    const int elem = 2 * ((kk >> 4) & 3) + (kk & 1);
    unsigned char* base = p.xb + static_cast<size_t>(S.job_xo[j]) * 65536
                          + static_cast<size_t>(st) * NTT * 4096 + chunk8 * 128
                          + (2 * t4) * 16 + elem * 2;
#pragma unroll
    for (int nt = 0; nt < NTT; ++nt) {
        const int tok = 8 * nt + 2 * t4;
        const float g0 = bf16r(acc[4 * nt] * gsa);
        const float g1 = bf16r(acc[4 * nt + 1] * gsa);
        const float u0 = bf16r(acc[4 * nt + 2] * gsa);
        const float u1 = bf16r(acc[4 * nt + 3] * gsa);
        const float h0 = g0 * silu_rcp<fast_silu(MODE)>(1.f + __expf(-g0)) * u0;
        const float h1 = g1 * silu_rcp<fast_silu(MODE)>(1.f + __expf(-g1)) * u1;
        if constexpr (pair_st(MODE)) {
            const bool odd = (g & 1) != 0;
            const float recv = __shfl_xor_sync(0xffffffffu, odd ? h0 : h1, 4);
            if ((odd ? tok + 1 : tok) < ntok) {
                // The odd lane's element is the pair's high half, one row (16 bytes) down.
                *reinterpret_cast<__nv_bfloat162*>(base + nt * 4096 + (odd ? 14 : 0)) =
                    __floats2bfloat162_rn(odd ? recv : h0, odd ? h1 : recv);
            }
            continue;
        }
        __nv_bfloat16* d = reinterpret_cast<__nv_bfloat16*>(base + nt * 4096);
        if (tok < ntok) {
            d[0] = __float2bfloat16_rn(h0);
        }
        if (tok + 1 < ntok) {
            d[8] = __float2bfloat16_rn(h1);
        }
    }
    if constexpr (PUB) {
        publish_a<MODE>(p, j * 16 + st, wg, tid_wg);
    }
    return j * 16 + st;
}

__device__ __forceinline__ int ld_volatile_s32(const int* p) {
    int v;
    asm volatile("ld.volatile.shared.s32 %0, [%1];" : "=r"(v) : "r"(smem_u32(p)) : "memory");
    return v;
}

__device__ __forceinline__ float* ld_volatile_ptr(float* const* p) {
    unsigned long long v;
    asm volatile("ld.volatile.shared.u64 %0, [%1];" : "=l"(v) : "r"(smem_u32(p)) : "memory");
    return reinterpret_cast<float*>(v);
}

template <int NTT, bool VOL = false, bool NOSS = false, bool NOSS_BY_M = false>
__device__ __forceinline__ void epilogue_b(const Params& p, SmemMain& S, float* ss_arg,
                                           const float (&acc)[32], int j, int u, int wg,
                                           int w, int tid_wg) {
    float* ss = VOL ? ld_volatile_ptr(&S.ssp) : ss_arg;
    const int lane = tid_wg & 31;
    const int g = lane >> 2;
    const int t4 = lane & 3;
    const int ntok = S.job_n[j];
    const int q0 = S.job_q[j];
    const float gsb = __ldg(p.gs2 + S.job_e[j]) * 128.f;
    const int rb = 16 * u + 4 * wg + w;
    const int col0 = rb * 16 + g;
    const int col1 = col0 + 8;
    const float w0 = __ldg(p.nw + col0);
    const float w1 = __ldg(p.nw + col1);
#pragma unroll
    for (int nt = 0; nt < NTT; ++nt) {
        const int tok = 8 * nt + 2 * t4;
        const float y00 = bf16r(acc[4 * nt] * gsb) * w0;
        const float y01 = bf16r(acc[4 * nt + 1] * gsb) * w0;
        const float y10 = bf16r(acc[4 * nt + 2] * gsb) * w1;
        const float y11 = bf16r(acc[4 * nt + 3] * gsb) * w1;
        float* dst = p.ybuf + static_cast<size_t>(q0 + tok) * kH;
        if (tok < ntok) {
            dst[col0] = y00;
            dst[col1] = y10;
        }
        if (tok + 1 < ntok) {
            dst[kH + col0] = y01;
            dst[kH + col1] = y11;
        }
        if constexpr (NOSS) {
            if (!NOSS_BY_M || p.M >= kFinssMinM) {
                continue;
            }
        }
        float s0 = y00 * y00 + y10 * y10;
        float s1 = y01 * y01 + y11 * y11;
#pragma unroll
        for (int d = 4; d < 32; d <<= 1) {
            s0 += __shfl_xor_sync(0xffffffffu, s0, d);
            s1 += __shfl_xor_sync(0xffffffffu, s1, d);
        }
        if (g == 0) {
            if (tok < ntok) {
                atomicAdd(ss + q0 + tok, s0);
            }
            if (tok + 1 < ntok) {
                atomicAdd(ss + q0 + tok + 1, s1);
            }
        }
    }
}

// Every share of a cut unit adds its partial into the owner's slot and counts its stages; the
// share that completes the count reads the sum back into fin, clears the slot and finishes
// the unit. acc itself is never written by anything but wgmma (ptxas C7515).
template <int NTT, bool AR>
__device__ __forceinline__ bool fixup(const Params& p, SmemMain& S, const float (&acc)[32],
                                      float (&fin)[32], int ph, int slot, int nst, int wg,
                                      int tid_wg, int G) {
    float4* fp = reinterpret_cast<float4*>(p.fix)
                 + (static_cast<size_t>((ph * G + slot) * 4 + wg) * 128 + tid_wg) * 8;
#pragma unroll
    for (int i = 0; i < NTT; ++i) {
        red_add_v4(fp + i, make_float4(acc[4 * i], acc[4 * i + 1], acc[4 * i + 2],
                                       acc[4 * i + 3]));
    }
    fence_gpu<AR>();
    named_sync(kBarWg + wg, 128);
    int* cp = p.fixcnt + (ph * G + slot) * 4 + wg;
    if (tid_wg == 0) {
        const int old = atom_add_acqrel(cp, nst);
        S.fix_last[wg] = old + nst == 16 ? 1 : 0;
    }
    named_sync(kBarWg + wg, 128);
    if (S.fix_last[wg] == 0) {
        return false;
    }
    fence_gpu<AR>();
#pragma unroll
    for (int i = 0; i < NTT; ++i) {
        const float4 v = __ldcg(fp + i);
        fin[4 * i] = v.x;
        fin[4 * i + 1] = v.y;
        fin[4 * i + 2] = v.z;
        fin[4 * i + 3] = v.w;
        fp[i] = make_float4(0.f, 0.f, 0.f, 0.f);
    }
    if (tid_wg == 0) {
        *cp = 0;
    }
    return true;
}

// defer_a: the done_as index of the CTA's owned phase A unit of round r. The rounds run in
// order (S.ord's n-tile counts never rise with r, and consumer_phase walks the counts largest
// first), so round r - 1 is the unit before round r, and owned units are always 16 stages.
__device__ __forceinline__ int own_target(const SmemMain& S, int r, int cta, int G) {
    const int k = own_unit(r, cta, G);
    return S.ord[k >> 5] * 16 + ((k & 31) >> 1);
}

// A whole phase A unit's epilogue: published at once, or (defer_a) left for the next unit's
// second stage or the end of phase A.
template <int NTT, int MODE>
__device__ __forceinline__ void epilogue_a_unit(const Params& p, SmemMain& S,
                                                const float (&acc)[32], const SegInfo& si,
                                                int wg, int w, int tid_wg) {
    static_assert(!defer_a(MODE) || (own_a(MODE) && dyn_b(MODE)), "defer_a needs owned units");
    epilogue_a<NTT, MODE, !defer_a(MODE)>(p, S, acc, si.j, si.u, wg, w, tid_wg);
}

// pa_diag: one phase A unit's counters into the warp's S.dg row. Segment cycles include the
// waits (columns 0 and 1) and exclude the deferred publish (column 7).
template <int MODE, int PH, int NTT>
__device__ __forceinline__ void pa_record(SmemMain& S, int warp, int lane, unsigned dw,
                                          unsigned dx, long long pseg, long long pdep,
                                          long long ppub, int nst) {
    if constexpr (pa_diag(MODE) && PH == 0) {
        if (lane == 0) {
            long long* d = S.dg[warp];
            d[0] += dw;
            d[1] += dx;
            d[2] += pdep - pseg - ppub;
            d[3] += clock64() - pdep;
            d[4] += nst;
            d[5] += 1;
            d[6] += NTT;
            d[7] += ppub;
        }
    }
}

__device__ __forceinline__ long long* pb_row(const Params& p, int warp) {
    return reinterpret_cast<long long*>(p.inter) + gridDim.x * 18 * 8
           + (blockIdx.x * 16 + warp) * 8;
}

// pb_diag: one phase B unit's counters into the warp's global row (pb_row).
template <int MODE, int PH, int NTT>
__device__ __forceinline__ void pb_record(const Params& p, int warp, int lane, unsigned dw,
                                          unsigned dx, long long pseg, long long pdep, int nst) {
    if constexpr (pb_diag(MODE) && PH == 1) {
        if (lane == 0) {
            long long* d = pb_row(p, warp);
            d[0] += dw;
            d[1] += dx;
            d[2] += pdep - pseg;
            d[3] += clock64() - pdep;
            d[4] += nst;
            d[5] += 1;
            d[6] += NTT;
        }
    }
}

// One segment (stages st_b..st_e of one unit) on a consumer warpgroup: per stage the warp's
// 16 words and 32 scale bytes come out of the weights ring into registers, then 16 k16 steps
// of dequant and wgmma in groups of two, one group kept in flight.
template <int NTT, int PH, int MODE>
__device__ __forceinline__ void run_segment(const Params& p, SmemMain& S, float* ss,
                                            const SegInfo& si, float (&acc)[32], Ring& rg,
                                            int& xrel, int G) {
    constexpr int ph = PH;
    constexpr int DEPTH = MODE == 5 ? 3 : 2;
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int warp = tid >> 5;
    const int wg = warp >> 2;
    const int w = warp & 3;
    const int tid_wg = tid & 127;
    const int g = lane >> 2;
    // 32-bit clock deltas keep the stamps' register cost low on the wgmma path.
    constexpr bool kDiag = is_diag(MODE);
    constexpr bool kPa = pa_diag(MODE) && (PH == 0 || pb_diag(MODE));
    unsigned dw = 0;
    unsigned dx = 0;
    const unsigned dbeg = kDiag ? static_cast<unsigned>(clock()) : 0u;
    const long long pseg = kPa ? clock64() : 0;
    long long ppub = 0;
    unsigned af[DEPTH][2][4];
#pragma unroll
    for (int i = 0; i < 4 * NTT; ++i) {
        acc[i] = 0.f;
    }
    acc_fence<NTT>(acc);
    constexpr bool kLean = lean_stage(MODE);
    // kLean: x slot 0's descriptor once per segment; a stage adds its slot's offset in 16-byte
    // units (shared addresses stay below 2^18, so the 14-bit address field cannot carry).
    const unsigned xb0 = kLean ? __shfl_sync(0xffffffffu, rg.xb, 0) : 0u;
    const uint64_t dx0 = ((xb0 & 0x3ffffu) >> 4) | (static_cast<uint64_t>(128 >> 4) << 16)
                         | (static_cast<uint64_t>(4096 >> 4) << 32);
    if constexpr (grp_codes(MODE)) {
        static_assert(kLean && DEPTH == 2 && !defer_a(MODE), "grp_codes extends mode 37");
        // Code group c (steps 4c to 4c + 3) sits in cb[c & 1]; scw[0] holds the scale bytes of
        // groups 0 and 1, scw[1] those of groups 2 and 3.
        const unsigned char* wbase = S.rings + (wg * 4 + w) * 2048 + lane * 16;
        const unsigned char* sbase = S.rings + 32768 + (wg * 4 + w) * 256 + lane * 8;
        uint4 cb[2];
        unsigned scw[2];
        int ws = rg.ws;
        int xs = rg.xs;
        const uint4* cp = reinterpret_cast<const uint4*>(wbase + ws * kUnitBytes);
        const unsigned* sp = reinterpret_cast<const unsigned*>(sbase + ws * kUnitBytes);
        int sq = skew_st(MODE) ? rg.wlap * rg.nsw + ws : 0;
        if (si.st_b < si.st_e) {
            sk_stamp<MODE>(p, sq, warp * 4, lane == 0);
            dw += mbar_wait_m<MODE, PH>(&S.wfull[ws], rg.wlap & 1, p.ctr, 2);
            sk_stamp<MODE>(p, sq, warp * 4 + 1, lane == 0);
            cb[0] = cp[0];
            scw[0] = sp[0];
            ring_next_w(rg, rg.nsw);
            dx += mbar_wait_m<MODE, PH>(&S.xfull[xs], rg.xlap & 1, p.ctr, 8);
            sk_stamp<MODE>(p, sq, warp * 4 + 2, lane == 0);
        }
#pragma unroll 1
        for (int st = si.st_b; st < si.st_e; ++st) {
            if (!grp_hoist(MODE) && st > si.st_b) {
                ws = rg.ws;
                if constexpr (skew_st(MODE)) {
                    sq = rg.wlap * rg.nsw + ws;
                }
                sk_stamp<MODE>(p, sq, warp * 4, lane == 0);
                dw += mbar_wait_m<MODE, PH>(&S.wfull[ws], rg.wlap & 1, p.ctr, 2);
                sk_stamp<MODE>(p, sq, warp * 4 + 1, lane == 0);
                cp = reinterpret_cast<const uint4*>(wbase + ws * kUnitBytes);
                sp = reinterpret_cast<const unsigned*>(sbase + ws * kUnitBytes);
                cb[0] = cp[0];
                scw[0] = sp[0];
                ring_next_w(rg, rg.nsw);
                dx += mbar_wait_m<MODE, PH>(&S.xfull[xs], rg.xlap & 1, p.ctr, 8);
                sk_stamp<MODE>(p, sq, warp * 4 + 2, lane == 0);
            }
            const uint64_t d0 = dx0 + (__shfl_sync(0xffffffffu,
                                                   static_cast<unsigned>(xs) * rg.xsz, 0) >> 4);
#pragma unroll
            for (int s = 0; s < 16; s += 2) {
                const int c = s >> 2;
                const int b = (s >> 1) % DEPTH;
                if ((s & 3) == 0 && c < 3) {
                    cb[(c + 1) & 1] = cp[(c + 1) * 32];
                    if (c == 1) {
                        scw[1] = sp[1];
                    }
                }
                {
                    const unsigned sg = scale_word(scw[c >> 1], (2 * c) & 3);
                    const unsigned sg8 = scale_word(scw[c >> 1], (2 * c + 1) & 3);
                    dequant(word(cb[c & 1], s & 3), sg, sg8, af[b][0]);
                    dequant(word(cb[c & 1], (s + 1) & 3), sg, sg8, af[b][1]);
                }
                wg_fence();
                wgmma<NTT>(acc, af[b][0], d0 + s * 16);
                wgmma<NTT>(acc, af[b][1], d0 + (s + 1) * 16);
                wg_commit();
                wg_wait<DEPTH - 1>();
                a_pin(af[(b + 1) % DEPTH]);
                if (s == 0 && xrel >= 0) {
                    x_release_warp<MODE>(&S.xempty[xrel], lane);
                    xrel = -1;
                }
                if (s == 10) {
                    // Every generic read of this slot (groups 0 to 3, both scale words) is in
                    // this thread's program order before the fence. The last one was issued
                    // a whole group earlier (s == 8) so that the fence's MEMBAR does not find
                    // it still in flight.
                    fence_proxy_async();
                    mbar_arrive(&S.wempty[ws]);
                    sk_stamp<MODE>(p, sq, warp * 4 + 3, lane == 0);
                }
                if (grp_hoist(MODE) && s == 14 && st + 1 < si.st_e) {
                    ws = rg.ws;
                    dw += mbar_wait_m<MODE, PH>(&S.wfull[ws], rg.wlap & 1, p.ctr, 2);
                    cp = reinterpret_cast<const uint4*>(wbase + ws * kUnitBytes);
                    sp = reinterpret_cast<const unsigned*>(sbase + ws * kUnitBytes);
                    cb[0] = cp[0];
                    scw[0] = sp[0];
                    ring_next_w(rg, rg.nsw);
                    ring_next_x(rg);
                    dx += mbar_wait_m<MODE, PH>(&S.xfull[rg.xs], rg.xlap & 1, p.ctr, 8);
                }
            }
            xrel = xs;
            if (!grp_hoist(MODE) || st + 1 == si.st_e) {
                ring_next_x(rg);
            }
            xs = rg.xs;
        }
    } else {
#pragma unroll 1
        for (int st = si.st_b; st < si.st_e; ++st) {
            if constexpr (defer_a(MODE) && PH == 0) {
                // One stage into the next unit, the previous unit's SwiGLU stores have drained.
                if (st == si.st_b + 1 && si.r > 0) {
                    const long long c = kPa ? clock64() : 0;
                    publish_a<MODE>(p, own_target(S, si.r - 1, blockIdx.x, gridDim.x), wg, tid_wg);
                    if constexpr (kPa) {
                        ppub += clock64() - c;
                    }
                }
            }
            const int ws = rg.ws;
            unsigned dc = kDiag ? static_cast<unsigned>(clock()) : 0u;
            dw += mbar_wait_m<MODE, PH>(&S.wfull[ws], rg.wlap & 1, p.ctr, 2);
            if constexpr (kDiag) {
                dw += static_cast<unsigned>(clock()) - dc;
            }
            const unsigned char* wslot = S.rings + ws * kUnitBytes;
            const uint4* cp = reinterpret_cast<const uint4*>(wslot + (wg * 4 + w) * 2048) + lane;
            uint4 cw[4];
#pragma unroll
            for (int i = 0; i < 4; ++i) {
                cw[i] = cp[i * 32];
            }
            const uint2 sc = *reinterpret_cast<const uint2*>(wslot + 32768 + (wg * 4 + w) * 256
                                                             + lane * 8);
            if constexpr (!kLean) {
                __syncwarp();
                if (lane == 0) {
                    fence_proxy_async();
                    mbar_arrive(&S.wempty[ws]);
                }
            }
            ring_next_w(rg, kLean ? rg.nsw : S.nsw);
            const int xs = rg.xs;
            if constexpr (kDiag) {
                dc = static_cast<unsigned>(clock());
            }
            dx += mbar_wait_m<MODE, PH>(&S.xfull[xs], rg.xlap & 1, p.ctr, 8);
            if constexpr (kDiag) {
                dx += static_cast<unsigned>(clock()) - dc;
            }
            // The slot base goes through a shuffle so ptxas knows it is warp-uniform and keeps
            // the descriptors in uniform registers (one UIADD3 per step instead of a 64-bit add
            // and two R2UR moves on every wgmma's critical path).
            const unsigned xbase = kLean ? 0u
                                         : __shfl_sync(0xffffffffu,
                                                       smem_u32(S.rings + S.xoff + xs * S.xsz), 0);
            // The slot offset still takes a shuffle: the ring position is carried around a loop
            // whose trip count ptxas cannot prove warp-uniform, and without it every wgmma's
            // descriptor goes through R2UR (448 instructions per stage instead of 389).
            const uint64_t d0 = kLean ? dx0 + (__shfl_sync(0xffffffffu,
                                                           static_cast<unsigned>(xs) * rg.xsz, 0)
                                               >> 4)
                                      : ((xbase & 0x3ffffu) >> 4)
                                            | (static_cast<uint64_t>(128 >> 4) << 16)
                                            | (static_cast<uint64_t>(4096 >> 4) << 32);
            if (MODE == 1) {
                // Timing only: the stage's bytes arrive and one word of each is read.
                acc[0] += __uint_as_float((cw[0].x ^ sc.x) & 0x3f800000u);
                if (xrel >= 0) {
                    if (lane == 0) {
                        mbar_arrive(&S.xempty[xrel]);
                    }
                }
                xrel = xs;
                ring_next_x(rg);
                continue;
            }
#pragma unroll
            for (int s = 0; s < 16; s += 2) {
                const int b = (s >> 1) % DEPTH;
                {
                    const int c = s >> 2;
                    const unsigned scw = c < 2 ? sc.x : sc.y;
                    const unsigned sg = scale_word(scw, (2 * c) & 3);
                    const unsigned sg8 = scale_word(scw, (2 * c + 1) & 3);
                    if (MODE == 3) {
                        // Timing only: the raw words stand in for the fragments.
#pragma unroll
                        for (int i = 0; i < 4; ++i) {
                            af[b][0][i] = word(cw[c], i) ^ sg;
                            af[b][1][i] = word(cw[c], i) ^ sg8;
                        }
                    } else {
                        dequant(word(cw[c], s & 3), sg, sg8, af[b][0]);
                        dequant(word(cw[c], (s + 1) & 3), sg, sg8, af[b][1]);
                    }
                }
                if (MODE == 2) {
                    // Timing only: the fragments are consumed by one add instead of a wgmma.
                    acc[0] += __uint_as_float((af[b][0][0] ^ af[b][1][3]) & 0x3f800000u);
                    if (s == 2 * (DEPTH - 1) - 2 && xrel >= 0) {
                        if (lane == 0) {
                            mbar_arrive(&S.xempty[xrel]);
                        }
                        xrel = -1;
                    }
                    continue;
                }
                wg_fence();
                wgmma<NTT>(acc, af[b][0], d0 + s * 16);
                wgmma<NTT>(acc, af[b][1], d0 + (s + 1) * 16);
                wg_commit();
                wg_wait<DEPTH - 1>();
                a_pin(af[(b + 1) % DEPTH]);
                // The previous stage's last group has retired once DEPTH - 1 groups of this
                // stage are committed.
                if (s == 2 * (DEPTH - 1) - 2 && xrel >= 0) {
                    x_release_warp<MODE>(&S.xempty[xrel], lane);
                    xrel = -1;
                }
                if (kLean && s == 0) {
                    // The weights slot's generic reads (cw, sc) were issued before this point;
                    // the fence orders them before the producer's next bulk write into the slot.
                    fence_proxy_async();
                    mbar_arrive(&S.wempty[ws]);
                }
            }
            xrel = xs;
            ring_next_x(rg);
        }
    }
    wg_wait<0>();
#pragma unroll
    for (int b = 0; b < DEPTH; ++b) {
        a_pin(af[b]);
    }
    acc_fence<NTT>(acc);
    if (xrel >= 0) {
        x_release_warp<MODE>(&S.xempty[xrel], lane);
        xrel = -1;
    }
    if (MODE == 1) {
        return;
    }
    const unsigned dep = kDiag ? static_cast<unsigned>(clock()) : 0u;
    const long long pdep = kPa ? clock64() : 0;
    if (si.partial) {
        float fin[32];
        if (fixup<NTT, fence_ar(MODE)>(p, S, acc, fin, ph, si.slot, si.st_e - si.st_b, wg, tid_wg, G)) {
            if (ph == 0) {
                epilogue_a<NTT, MODE, true>(p, S, fin, si.j, si.u, wg, w, tid_wg);
            } else {
                epilogue_b<NTT, false, final_ss(MODE), MODE == 51>(p, S, ss, fin, si.j, si.u,
                                                                   wg, w, tid_wg);
            }
        }
    } else if (ph == 0) {
        epilogue_a_unit<NTT, MODE>(p, S, acc, si, wg, w, tid_wg);
    } else {
        epilogue_b<NTT, vol_regs(MODE), final_ss(MODE), MODE == 51>(p, S, ss, acc, si.j, si.u,
                                                                    wg, w, tid_wg);
    }
    pa_record<MODE, PH, NTT>(S, warp, lane, dw, dx, pseg, pdep, ppub, si.st_e - si.st_b);
    pb_record<MODE, PH, NTT>(p, warp, lane, dw, dx, pseg, pdep, si.st_e - si.st_b);
    if constexpr (kDiag) {
        if (lane == 0) {
            long long* d = S.dg[warp];
            d[0] += dw;
            d[1] += dx;
            d[2] += dep - dbeg - dw - dx;
            d[3] += static_cast<unsigned>(clock()) - dep;
            d[4] += si.st_e - si.st_b;
            d[5] += 1;
        }
    }
}

__device__ __forceinline__ void ldsm_x4(unsigned (&r)[4], unsigned addr) {
    asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0,%1,%2,%3}, [%4];"
                 : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(addr) : "memory");
}

// run_segment on mma.sync m16n8k16 for small N. A warp's wgmma m64 A fragment is the
// mma.sync A fragment of its 16 rows, and the m64nN accumulator per warp is NTT m16n8
// accumulators in the same order, so the ring layouts, the dequant, the fixup and the
// epilogues are shared with the wgmma path. B comes from the x slot by ldmatrix: one x4 covers
// two k16 steps of one n8 tile (step s's two 8-k core matrices at 256 s and 256 s + 128).
// Each warp runs on its own; no warpgroup-wide wgmma sync.
template <int NTT, int PH, int MODE>
__device__ __forceinline__ void run_segment_mma(const Params& p, SmemMain& S, float* ss,
                                                const SegInfo& si, Ring& rg, int G) {
    constexpr int ph = PH;
    constexpr bool kDiag = is_diag(MODE);
    constexpr bool kPa = pa_diag(MODE) && (PH == 0 || pb_diag(MODE));
    const long long pseg = kPa ? clock64() : 0;
    long long ppub = 0;
    unsigned dw = 0;
    unsigned dx = 0;
    long long tw = 0;
    long long tx = 0;
    long long tc = 0;
    long long c0 = 0;
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int warp = tid >> 5;
    const int wg = warp >> 2;
    const int w = warp & 3;
    const int tid_wg = tid & 127;
    // Mode 14 splits each n8 tile's 16-step mma.sync chain into two accumulators (even and odd
    // k16 steps), halving the dependent chain per stage; the stamps put a stage's compute at
    // 1.02 us against about 0.66 us of issue for its four warps per scheduler.
    constexpr bool kDual = dual_chain(MODE);
    float acc[32];
    float acc2[kDual ? 4 * NTT : 1];
#pragma unroll
    for (int i = 0; i < 32; ++i) {
        acc[i] = 0.f;
    }
#pragma unroll
    for (int i = 0; i < (kDual ? 4 * NTT : 1); ++i) {
        acc2[i] = 0.f;
    }
    const unsigned lrow = static_cast<unsigned>((lane >> 3) * 128 + (lane & 7) * 16);
    constexpr bool kLean = lean_stage(MODE);
    const unsigned xb0 = kLean ? rg.xb + lrow : 0u;
#pragma unroll 1
    for (int st = si.st_b; st < si.st_e; ++st) {
        if constexpr (defer_a(MODE) && PH == 0) {
            if (st == si.st_b + 1 && si.r > 0) {
                const long long c = kPa ? clock64() : 0;
                publish_a<MODE>(p, own_target(S, si.r - 1, blockIdx.x, gridDim.x), wg, tid_wg);
                if constexpr (kPa) {
                    ppub += clock64() - c;
                }
            }
        }
        const int ws = rg.ws;
        if constexpr (kDiag) {
            c0 = clock64();
        }
        dw += mbar_wait_m<MODE, PH>(&S.wfull[ws], rg.wlap & 1, p.ctr, 2);
        if constexpr (kDiag) {
            const long long c1 = clock64();
            tw += c1 - c0;
            c0 = c1;
        }
        const unsigned char* wslot = S.rings + ws * kUnitBytes;
        const uint4* cp = reinterpret_cast<const uint4*>(wslot + (wg * 4 + w) * 2048) + lane;
        uint4 cw[4];
#pragma unroll
        for (int i = 0; i < 4; ++i) {
            cw[i] = cp[i * 32];
        }
        const uint2 sc = *reinterpret_cast<const uint2*>(wslot + 32768 + (wg * 4 + w) * 256
                                                         + lane * 8);
        if constexpr (!kLean) {
            __syncwarp();
            if (lane == 0) {
                fence_proxy_async();
                mbar_arrive(&S.wempty[ws]);
            }
        }
        ring_next_w(rg, kLean ? rg.nsw : S.nsw);
        const int xs = rg.xs;
        if constexpr (kDiag) {
            const long long c1 = clock64();
            tc += c1 - c0;
            c0 = c1;
        }
        dx += mbar_wait_m<MODE, PH>(&S.xfull[xs], rg.xlap & 1, p.ctr, 8);
        if constexpr (kDiag) {
            const long long c1 = clock64();
            tx += c1 - c0;
            c0 = c1;
        }
        const unsigned xbase = kLean ? xb0 + static_cast<unsigned>(xs) * rg.xsz
                                     : __shfl_sync(0xffffffffu,
                                                   smem_u32(S.rings + S.xoff + xs * S.xsz), 0)
                                           + lrow;
#pragma unroll
        for (int s = 0; s < 16; s += 2) {
            const int c = s >> 2;
            const unsigned scw = c < 2 ? sc.x : sc.y;
            const unsigned sg = scale_word(scw, (2 * c) & 3);
            const unsigned sg8 = scale_word(scw, (2 * c + 1) & 3);
            unsigned a0[4];
            unsigned a1[4];
            dequant(word(cw[c], s & 3), sg, sg8, a0);
            dequant(word(cw[c], (s + 1) & 3), sg, sg8, a1);
#pragma unroll
            for (int nt = 0; nt < NTT; ++nt) {
                unsigned b[4];
                ldsm_x4(b, xbase + nt * 4096 + s * 256);
                float (&c4)[4] = *reinterpret_cast<float (*)[4]>(acc + 4 * nt);
                mma_bf16(c4, a0, b[0], b[1]);
                if constexpr (kDual) {
                    float (&d4)[4] = *reinterpret_cast<float (*)[4]>(acc2 + 4 * nt);
                    mma_bf16(d4, a1, b[2], b[3]);
                } else {
                    mma_bf16(c4, a1, b[2], b[3]);
                }
            }
            if (kLean && s == 0) {
                // As on the wgmma path: the weights slot's reads were issued before this point.
                fence_proxy_async();
                mbar_arrive(&S.wempty[ws]);
            }
        }
        // The x slot is refilled by the async proxy after these generic-proxy reads.
        if constexpr (kLean) {
            fence_proxy_async();
            mbar_arrive(&S.xempty[xs]);
        } else {
            __syncwarp();
            if (lane == 0) {
                fence_proxy_async();
                mbar_arrive(&S.xempty[xs]);
            }
        }
        ring_next_x(rg);
        if constexpr (kDiag) {
            // Reading acc makes the stamp wait for this stage's mma chain.
            const long long c1 = clock64() + (acc[0] == 1e30f ? 1 : 0);
            tc += c1 - c0;
        }
    }
    if constexpr (kDual) {
#pragma unroll
        for (int i = 0; i < 4 * NTT; ++i) {
            acc[i] += acc2[i];
        }
    }
    if constexpr (kDiag) {
        c0 = clock64();
    }
    const long long pdep = kPa ? clock64() + (acc[0] == 1e30f ? 1 : 0) : 0;
    if (si.partial) {
        float fin[32];
        if (fixup<NTT, fence_ar(MODE)>(p, S, acc, fin, ph, si.slot, si.st_e - si.st_b, wg, tid_wg, G)) {
            if (ph == 0) {
                epilogue_a<NTT, MODE, true>(p, S, fin, si.j, si.u, wg, w, tid_wg);
            } else {
                epilogue_b<NTT, false, final_ss(MODE), MODE == 51>(p, S, ss, fin, si.j, si.u,
                                                                   wg, w, tid_wg);
            }
        }
    } else if (ph == 0) {
        epilogue_a_unit<NTT, MODE>(p, S, acc, si, wg, w, tid_wg);
    } else {
        epilogue_b<NTT, vol_regs(MODE), final_ss(MODE), MODE == 51>(p, S, ss, acc, si.j, si.u,
                                                                    wg, w, tid_wg);
    }
    pa_record<MODE, PH, NTT>(S, warp, lane, dw, dx, pseg, pdep, ppub, si.st_e - si.st_b);
    pb_record<MODE, PH, NTT>(p, warp, lane, dw, dx, pseg, pdep, si.st_e - si.st_b);
    if constexpr (kDiag) {
        if (lane == 0) {
            long long* d = S.dg[warp];
            d[0] += tw;
            d[1] += tx;
            d[2] += tc;
            d[3] += clock64() - c0;
            d[4] += si.st_e - si.st_b;
            d[5] += 1;
        }
    }
}

// Segments run grouped by (phase, n-tile count), each group its own loop: with several
// wgmma shapes inside one enclosing loop ptxas serializes every wgmma (C7512, see the
// micro tests in docs/runs-moe.md); the producers walk the same order.
template <int NTT, int PH, int MODE>
__device__ __forceinline__ void run_group(const Params& p, SmemMain& S, float* ss,
                                          float (&acc)[32], Ring& rg, int& xrel, int cta,
                                          int G) {
    const int ns = seg_n<MODE>(S, PH);
#pragma unroll 1
    for (int i = 0; i < (vol_regs(MODE) && own_a(MODE) && PH == 0 ? ld_volatile_s32(&S.own_n)
                                                                 : ns); ++i) {
        int gb;
        int ge;
        seg_at<MODE>(S, PH, i, cta, G, gb, ge);
        if (S.job_ntt[PH ? (gb >> 8) : (gb >> 9)] != NTT) {
            continue;
        }
        SegInfo si = seg_info(S, PH, gb, ge, cta, G);
        if (own_a(MODE) && PH == 0) {
            si.r = i;
        }
        if (is_diag(MODE) && threadIdx.x == 0) {
            S.dg[PH * 8 + NTT - 1][6] += si.st_e - si.st_b;
            S.dg[PH * 8 + NTT - 1][7] += 1;
            S.dg[16][1 + PH] += si.partial ? 1 : 0;
        }
        // Warp 0's cycles inside segments: the cost model's work target.
        const long long cs = is_diag(MODE) ? clock64() : 0;
        if constexpr (NTT <= mma_max(MODE)) {
            run_segment_mma<NTT, PH, MODE>(p, S, ss, si, rg, G);
        } else {
            run_segment<NTT, PH, MODE>(p, S, ss, si, acc, rg, xrel, G);
        }
        if (is_diag(MODE) && threadIdx.x == 0) {
            S.dg[17][5 + PH] += clock64() - cs;
        }
    }
}

template <int PH, int MODE>
__device__ __forceinline__ void consumer_phase(const Params& p, SmemMain& S, float* ss,
                                               float (&acc)[32], Ring& rg, int& xrel, int cta,
                                               int G) {
    if constexpr (dyn_b(MODE)) {
        run_group<8, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<7, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<6, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<5, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<4, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<3, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<2, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<1, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
    } else {
        run_group<1, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<2, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<3, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<4, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<5, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<6, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<7, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
        run_group<8, PH, MODE>(p, S, ss, acc, rg, xrel, cta, G);
    }
}

// dyn_b phase B: the claimed units in claim order. Claims rise through S.ord, whose n-tile
// counts never rise, so one loop per count, largest first, takes them all in order.
template <int NTT, int MODE>
__device__ __forceinline__ void run_group_dyn(const Params& p, SmemMain& S, float* ss,
                                              float (&acc)[32], Ring& rg, int& xrel, int& qi,
                                              int cta, int G) {
#pragma unroll 1
    while (qi < kBqMax) {
        const long long cq = pb_diag(MODE) ? clock64() : 0;
        const int m = bq_get(S, qi, p.ctr);
        if (pb_diag(MODE) && (threadIdx.x & 31) == 0) {
            pb_row(p, threadIdx.x >> 5)[7] += clock64() - cq;
        }
        if (m < 0) {
            return;
        }
        const int j = S.ord[m >> 4];
        if (S.job_ntt[j] != NTT) {
            return;
        }
        SegInfo si;
        si.j = j;
        si.u = m & 15;
        si.st_b = 0;
        si.st_e = 16;
        si.slot = cta;
        si.partial = false;
        si.r = -1;
        if (is_diag(MODE) && threadIdx.x == 0) {
            S.dg[8 + NTT - 1][6] += 16;
            S.dg[8 + NTT - 1][7] += 1;
        }
        const long long cs = is_diag(MODE) ? clock64() : 0;
        if constexpr (NTT <= mma_max(MODE)) {
            run_segment_mma<NTT, 1, MODE>(p, S, ss, si, rg, G);
        } else {
            run_segment<NTT, 1, MODE>(p, S, ss, si, acc, rg, xrel, G);
        }
        if (is_diag(MODE) && threadIdx.x == 0) {
            S.dg[17][6] += clock64() - cs;
        }
        ++qi;
    }
}

template <int MODE>
__device__ __forceinline__ void consumer_dyn_b(const Params& p, SmemMain& S, float* ss,
                                               float (&acc)[32], Ring& rg, int& xrel, int cta,
                                               int G) {
    int qi = 0;
    run_group_dyn<8, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<7, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<6, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<5, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<4, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<3, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<2, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
    run_group_dyn<1, MODE>(p, S, ss, acc, rg, xrel, qi, cta, G);
}

template <int MODE>
__device__ __forceinline__ void consumers(const Params& p, SmemMain& S, float* ss, int cta,
                                          int G) {
    Ring rg = {0, 0, 0, 0, 0, 0u, 0u};
    if constexpr (lean_stage(MODE)) {
        rg.nsw = S.nsw;
        rg.xb = smem_u32(S.rings + S.xoff);
        rg.xsz = static_cast<unsigned>(S.xsz);
    }
    int xrel = -1;
    float acc[32];
    if (pb_diag(MODE) && (threadIdx.x & 31) == 0) {
        // Lane 0 zeroes the row it alone adds to later, so program order covers the reuse.
        for (int c = 0; c < 8; ++c) {
            pb_row(p, threadIdx.x >> 5)[c] = 0;
        }
    }
    const long long pc0 = pa_diag(MODE) ? clock64() : 0;
    consumer_phase<0, MODE>(p, S, ss, acc, rg, xrel, cta, G);
    if constexpr (defer_a(MODE)) {
        // Before any phase B wait: another CTA's phase B stage may need this unit.
        if (S.own_n > 0) {
            const long long c = pa_diag(MODE) ? clock64() : 0;
            publish_a<MODE>(p, own_target(S, S.own_n - 1, cta, G), threadIdx.x >> 7,
                            threadIdx.x & 127);
            if (pa_diag(MODE) && (threadIdx.x & 31) == 0) {
                S.dg[threadIdx.x >> 5][7] += clock64() - c;
            }
        }
    }
    if (pa_diag(MODE) && threadIdx.x == 0) {
        S.dg[17][7] = clock64() - pc0;
    }
    if (is_diag(MODE) && threadIdx.x == 0) {
        S.dg[17][7] = gtimer();
    }
    if (is_light(MODE) && threadIdx.x == 0) {
        S.dg[16][3] = gtimer();
    }
    if constexpr (dyn_b(MODE)) {
        consumer_dyn_b<MODE>(p, S, ss, acc, rg, xrel, cta, G);
    } else if constexpr (!a_only(MODE)) {
        // a_only: phase B has no segments; leaving its loops out keeps them off the register
        // allocation of the phase A loops (mode 45 spilled 268 / 656 B with them).
        consumer_phase<1, MODE>(p, S, ss, acc, rg, xrel, cta, G);
    }
}

template <int MODE>
__device__ __forceinline__ void wproducer(const Params& p, SmemMain& S, int cta, int G,
                                          uint64_t pol) {
    long long twe = 0;
    long long pwe = 0;
    Ring rg = {0, 0, 0, 0};
    for (int ph = 0; ph < (dyn_b(MODE) || a_only(MODE) ? 1 : 2); ++ph) {
        const int ns = seg_n<MODE>(S, ph);
        for (int n = 1; n <= 8; ++n) {
        const int ntt = dyn_b(MODE) ? 9 - n : n;
        for (int i = 0; i < ns; ++i) {
            int gb;
            int ge;
            seg_at<MODE>(S, ph, i, cta, G, gb, ge);
            const int j = ph ? (gb >> 8) : (gb >> 9);
            if (S.job_ntt[j] != ntt) {
                continue;
            }
            const int u = (gb & (ph ? 255 : 511)) >> 4;
            const int e = S.job_e[j];
            const unsigned char* base =
                ph ? p.w2f + static_cast<size_t>(e * 16 + u) * 16 * kUnitBytes
                   : p.w13f + static_cast<size_t>(e * 32 + u) * 16 * kUnitBytes;
            const int st_e = ((ge - 1) & 15) + 1;
            for (int st = gb & 15; st < st_e; ++st) {
                const int ws = rg.ws;
                if (rg.wlap > 0) {
                    const long long c0 = is_diag(MODE) ? clock64() : 0;
                    pwe += mbar_wait_m<MODE, 0>(&S.wempty[ws], (rg.wlap - 1) & 1, p.ctr, 16);
                    if (is_diag(MODE)) {
                        twe += clock64() - c0;
                    }
                }
                sk_stamp<MODE>(p, rg.wlap * S.nsw + ws, kNC * 4, true);
                mbar_expect_tx(&S.wfull[ws], kUnitBytes);
                bulk_load(S.rings + ws * kUnitBytes, base + static_cast<size_t>(st) * kUnitBytes,
                          kUnitBytes, &S.wfull[ws], pol);
                ring_next_w(rg, S.nsw);
            }
        }
        }
    }
    if constexpr (pa_diag(MODE)) {
        S.dg[16][7] = pwe;
    }
    if constexpr (dyn_b(MODE)) {
        // Claim only once a slot is free, so the claim lands as late as the ring allows: the
        // CTA that drains first takes the next unit. The counter is a plain atomic (exactly
        // one claimant per value); the units' inputs still come through done_as. CTA 0 zeroes
        // it after the grid barrier, which every claim precedes.
        int* claim = p.ctr + 10;
        const int units = S.njobs * 16;
        for (int i = 0; i < kBqMax; ++i) {
            if (rg.wlap > 0) {
                const long long c0 = is_diag(MODE) ? clock64() : 0;
                mbar_wait_to(&S.wempty[rg.ws], (rg.wlap - 1) & 1, p.ctr, 16);
                if (is_diag(MODE)) {
                    twe += clock64() - c0;
                }
            }
            int m = i < kBqMax - 1 ? atomicAdd(claim, 1) : units;
            if (m >= units) {
                m = -1;
            }
            st_release_cta(&S.bq[i], m);
            if (m < 0) {
                break;
            }
            const int j = S.ord[m >> 4];
            const unsigned char* base =
                p.w2f + static_cast<size_t>(S.job_e[j] * 16 + (m & 15)) * 16 * kUnitBytes;
            for (int st = 0; st < 16; ++st) {
                const int ws = rg.ws;
                if (st > 0 && rg.wlap > 0) {
                    const long long c0 = is_diag(MODE) ? clock64() : 0;
                    mbar_wait_to(&S.wempty[ws], (rg.wlap - 1) & 1, p.ctr, 16);
                    if (is_diag(MODE)) {
                        twe += clock64() - c0;
                    }
                }
                sk_stamp<MODE>(p, rg.wlap * S.nsw + ws, kNC * 4, true);
                mbar_expect_tx(&S.wfull[ws], kUnitBytes);
                bulk_load(S.rings + ws * kUnitBytes, base + static_cast<size_t>(st) * kUnitBytes,
                          kUnitBytes, &S.wfull[ws], pol);
                ring_next_w(rg, S.nsw);
            }
        }
    }
    if (is_diag(MODE)) {
        S.dg[16][0] = twe;
    }
}

// Phase A stages come from the gathered x rows once the job's rows are all in; phase B
// stages from the SwiGLU output once the stage's 8 warpgroup units have released it.
template <int MODE>
__device__ __forceinline__ void xproducer(const Params& p, SmemMain& S, int cta, int G) {
    Ring rg = {0, 0, 0, 0};
    long long txe = 0;
    long long tda = 0;
    long long txr = 0;
    long long pxe = 0;
    for (int ph = 0; ph < (dyn_b(MODE) || a_only(MODE) ? 1 : 2); ++ph) {
        const int ns = seg_n<MODE>(S, ph);
        for (int n = 1; n <= 8; ++n) {
        const int ntt = dyn_b(MODE) ? 9 - n : n;
        for (int i = 0; i < ns; ++i) {
            int gb;
            int ge;
            seg_at<MODE>(S, ph, i, cta, G, gb, ge);
            const int j = ph ? (gb >> 8) : (gb >> 9);
            if (S.job_ntt[j] != ntt) {
                continue;
            }
            constexpr bool kDiag = is_diag(MODE);
            const unsigned bytes = ntt * 4096;
            const unsigned char* base = (ph ? p.xb : p.xa)
                                        + static_cast<size_t>(S.job_xo[j]) * 65536;
            long long c0 = kDiag ? clock64() : 0;
            if (ph == 0 && MODE != 1 && MODE != 4) {
                const long long c = pa_diag(MODE) ? clock64() : 0;
                spin_ge(p.xready + j, S.job_n[j], p.ctr, 32);
                if (pa_diag(MODE)) {
                    pxe += clock64() - c;
                }
                fence_proxy_async_global();
            }
            if (kDiag) {
                txr += clock64() - c0;
            }
            const int st_e = ((ge - 1) & 15) + 1;
            for (int st = gb & 15; st < st_e; ++st) {
                const int xs = rg.xs;
                if (kDiag) {
                    c0 = clock64();
                }
                if (rg.xlap > 0) {
                    pxe += mbar_wait_m<MODE, 0>(&S.xempty[xs], (rg.xlap - 1) & 1, p.ctr, 64);
                }
                if (kDiag) {
                    const long long c1 = clock64();
                    txe += c1 - c0;
                    c0 = c1;
                }
                if (ph == 1 && MODE != 1 && MODE != 4) {
                    if (!b_only(MODE)) {
                        spin_ge(p.done_as + j * 16 + st, 8, p.ctr, 128);
                    }
                    fence_proxy_async_global();
                }
                if (kDiag) {
                    tda += clock64() - c0;
                }
                sk_stamp<MODE>(p, rg.xlap * kNSX + xs, kNC * 4 + 1, true);
                mbar_expect_tx(&S.xfull[xs], bytes);
                bulk_load_plain(S.rings + S.xoff + xs * S.xsz,
                                base + static_cast<size_t>(st) * bytes, bytes, &S.xfull[xs]);
                ring_next_x(rg);
            }
        }
        }
    }
    if constexpr (pa_diag(MODE)) {
        S.dg[17][6] = pxe;
    }
    if constexpr (dyn_b(MODE)) {
        for (int i = 0; i < kBqMax; ++i) {
            const int m = bq_get(S, i, p.ctr);
            if (m < 0) {
                break;
            }
            const int j = S.ord[m >> 4];
            const unsigned bytes = S.job_ntt[j] * 4096;
            const unsigned char* base = p.xb + static_cast<size_t>(S.job_xo[j]) * 65536;
            for (int st = 0; st < 16; ++st) {
                const int xs = rg.xs;
                long long c0 = is_diag(MODE) ? clock64() : 0;
                if (rg.xlap > 0) {
                    mbar_wait_to(&S.xempty[xs], (rg.xlap - 1) & 1, p.ctr, 64);
                }
                if (is_diag(MODE)) {
                    const long long c1 = clock64();
                    txe += c1 - c0;
                    c0 = c1;
                }
                if (!b_only(MODE)) {
                    spin_ge(p.done_as + j * 16 + st, 8, p.ctr, 128);
                }
                fence_proxy_async_global();
                if (is_diag(MODE)) {
                    tda += clock64() - c0;
                }
                sk_stamp<MODE>(p, rg.xlap * kNSX + xs, kNC * 4 + 1, true);
                mbar_expect_tx(&S.xfull[xs], bytes);
                bulk_load_plain(S.rings + S.xoff + xs * S.xsz,
                                base + static_cast<size_t>(st) * bytes, bytes, &S.xfull[xs]);
                ring_next_x(rg);
            }
        }
    }
    if (is_diag(MODE)) {
        S.dg[17][0] = txe;
        S.dg[17][1] = tda;
        S.dg[17][2] = txr;
    }
}

template <int MODE>
__global__ void __launch_bounds__(kNTM, 1) moe_main_kernel(const Params p) {
    extern __shared__ __align__(128) unsigned char smem_raw[];
    SmemMain& S = *reinterpret_cast<SmemMain*>(smem_raw);
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int warp = tid >> 5;
    const int G = gridDim.x;
    const int cta = blockIdx.x;
    const int E = p.M * kTopK;
    if (p.pdl) {
        if (warp == kNWarpsM - 2 && lane == 0) {
            constexpr unsigned kRelP = lean_stage(MODE) ? kNC * 32 : kNC;
#pragma unroll
            for (int s = 0; s < kNSWMax; ++s) {
                mbar_init(&S.wfull[s], 1);
                mbar_init(&S.wempty[s], kRelP);
            }
#pragma unroll
            for (int s = 0; s < kNSX; ++s) {
                mbar_init(&S.xfull[s], 1);
                mbar_init(&S.xempty[s], kRelP);
            }
            asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
        }
        if (tid == 0) {
            for (int i = cta; i < p.nloc * 16; i += G) {
                prefetch_l2_hint(p.w13f + (static_cast<size_t>(i % p.nloc) * 32 * 16
                                           + i / p.nloc) * kUnitBytes, kUnitBytes);
            }
        }
    }
    asm volatile("griddepcontrol.wait;" ::: "memory");
    constexpr bool kDiag = is_diag(MODE);
    constexpr bool kLight = is_light(MODE);
    long long dt[5] = {0, 0, 0, 0, 0};
    long long dc0 = 0;
    if (pa_diag(MODE) && tid < 16 * 8) {
        (&S.dg[0][0])[tid] = 0;
    }
    if (kLight && tid == 0) {
        S.dg[16][0] = gtimer();
    }
    if constexpr (kDiag) {
        dt[0] = gtimer();
        dc0 = clock64();
        if (tid < 18 * 8) {
            (&S.dg[0][0])[tid] = 0;
        }
    }
    const int gen = *reinterpret_cast<volatile int*>(p.ctr + 3);
    float* ss = p.ss + (gen & 1) * kEmax;
    if (vol_regs(MODE) && tid == 0) {
        S.ssp = ss;
    }
    const uint64_t pol = policy_evict_first();

    // Every thread's topk_ids loads issued before any store (E / 4 <= 1024 int4 over 576
    // threads): one memory round trip instead of one per 128 entries in the routing warp,
    // stage-stamped at 12 us of prologue at 128 tokens and 18 at 256 (check 2072795029b7479f).
    {
        constexpr int kLd = (kEmax / 4 + kNTM - 1) / kNTM;
        int4 v[kLd];
#pragma unroll
        for (int k = 0; k < kLd; ++k) {
            const int i4 = tid + k * kNTM;
            v[k] = i4 < (E >> 2) ? __ldg(reinterpret_cast<const int4*>(p.topk_ids) + i4)
                                 : make_int4(-1, -1, -1, -1);
        }
#pragma unroll
        for (int k = 0; k < kLd; ++k) {
            const int i4 = tid + k * kNTM;
            if (i4 < (E >> 2)) {
                const int lo = ld_lo(p.lo_p);
                const int ev[4] = {v[k].x - lo, v[k].y - lo, v[k].z - lo, v[k].w - lo};
                char4 c;
                c.x = static_cast<signed char>(ev[0] >= 0 && ev[0] < p.nloc ? ev[0] : -1);
                c.y = static_cast<signed char>(ev[1] >= 0 && ev[1] < p.nloc ? ev[1] : -1);
                c.z = static_cast<signed char>(ev[2] >= 0 && ev[2] < p.nloc ? ev[2] : -1);
                c.w = static_cast<signed char>(ev[3] >= 0 && ev[3] < p.nloc ? ev[3] : -1);
                *reinterpret_cast<char4*>(S.eid + 4 * i4) = c;
            }
        }
    }
    __syncthreads();
    if (kLight && tid == 0) {
        S.dg[17][0] = gtimer();
    }
    if constexpr (fast_setup(MODE)) {
        position_count<kNWarpsM>(S.eid, S.wc, E);
        __syncthreads();
    }

    if (warp == kNWarpsM - 1) {
        if (lane < 9) {
            const bool given = p.cost[0][1] > 0;
            S.cost[0][lane] = given ? p.cost[0][lane] : stage_cost<MODE>(0, lane);
            S.align_b = MODE == 15 || (MODE >= 16 && MODE <= 29) || (MODE >= 31 && MODE <= 51)
                        ? 1 : 0;
            S.cost[1][lane] = given ? p.cost[1][lane] : stage_cost<MODE>(1, lane);
        }
        if constexpr (fast_setup(MODE)) {
            int c = 0;
#pragma unroll
            for (int w = 0; w < kNWarpsM; ++w) {
                c += S.wc[w][lane];
            }
            S.cnt[lane] = c;
        } else {
            S.cnt[lane] = 0;
            __syncwarp();
            for (int base = 0; base < E; base += 128) {
                const int i = base + 4 * lane;
#pragma unroll
                for (int k = 0; k < 4; ++k) {
                    const int eid = i < E ? S.eid[i + k] : -1;
                    const unsigned peers = __match_any_sync(0xffffffffu, eid);
                    if (eid >= 0 && lane == __ffs(peers) - 1) {
                        S.cnt[eid] += __popc(peers);
                    }
                    __syncwarp();
                }
            }
        }
        const int tot = lane < p.nloc ? S.cnt[lane] : 0;
        const int off = warp_scan(tot, lane) - tot;
        S.off[lane] = off;
        if (kLight && lane == 0) {
            S.dg[17][3] = gtimer();
        }
        if constexpr (fast_setup(MODE)) {
            // Each warp's first pair row per expert, as position_pass's warp 0 forms it.
            int run = off;
#pragma unroll
            for (int w = 0; w < kNWarpsM; ++w) {
                const int cw = S.wc[w][lane];
                S.wc[w][lane] = run;
                run += cw;
            }
        }
        const int nj = (tot + 63) >> 6;
        const int jincl = warp_scan(nj, lane);
        const int j0 = jincl - nj;
        S.job0[lane] = j0;
        int xo_sum = 0;
        int ca_sum = 0;
        int cb_sum = 0;
        for (int k = 0; k < nj; ++k) {
            const int ntt = (min(64, tot - 64 * k) + 7) >> 3;
            xo_sum += ntt;
            ca_sum += kUAM * S.cost[0][ntt];
            cb_sum += kUBM * S.cost[1][ntt];
        }
        const int xo_incl = warp_scan(xo_sum, lane);
        const int ca_incl = warp_scan(ca_sum, lane);
        const int cb_incl = warp_scan(cb_sum, lane);
        int xo = xo_incl - xo_sum;
        int ca = ca_incl - ca_sum;
        int cb = cb_incl - cb_sum;
        for (int k = 0; k < nj; ++k) {
            const int j = j0 + k;
            const int n = min(64, tot - 64 * k);
            const int ntt = (n + 7) >> 3;
            S.job_e[j] = lane;
            S.job_q[j] = off + 64 * k;
            S.job_n[j] = n;
            S.job_ntt[j] = ntt;
            S.job_xo[j] = xo;
            S.pa[j] = ca;
            S.pb[j] = cb;
            xo += ntt;
            ca += kUAM * S.cost[0][ntt];
            cb += kUBM * S.cost[1][ntt];
        }
        if (kLight && lane == 0) {
            S.dg[17][4] = gtimer();
        }
        if constexpr (lean_stage(MODE)) {
            // The same order in one pass: an expert's jobs are full (8 n-tiles) except
            // possibly its last, so a job's rank is the 8-tile jobs of lower experts, or
            // all 8-tile jobs plus the partial jobs that are larger or come from a lower
            // expert with the same count. The counting sort below took eight dependent
            // rounds (2.5 us of routing at 128 tokens, 4c285df44eb34bc1).
            const int tl = nj > 0 ? (min(64, tot - 64 * (nj - 1)) + 7) >> 3 : 0;
            const int n8 = tl == 8 ? nj : nj - (nj > 0 ? 1 : 0);
            const int n8_incl = warp_scan(n8, lane);
            const int all8 = __shfl_sync(0xffffffffu, n8_incl, 31);
            for (int k = 0; k < n8; ++k) {
                S.ord[n8_incl - n8 + k] = j0 + k;
            }
            int above = 0;
            unsigned same = 0;
#pragma unroll
            for (int t = 7; t >= 1; --t) {
                const unsigned b = __ballot_sync(0xffffffffu, tl == t);
                above += t > tl ? __popc(b) : 0;
                same = t == tl ? b : same;
            }
            if (tl > 0 && tl < 8) {
                S.ord[all8 + above + __popc(same & ((1u << lane) - 1u))] = j0 + nj - 1;
            }
        } else if constexpr (own_a(MODE)) {
            // Counting sort of the jobs by n-tile count, largest first; within a count, by
            // expert then job, so every CTA derives the same order.
            int base = 0;
            for (int t = 8; t >= 1; --t) {
                int c = 0;
                for (int k = 0; k < nj; ++k) {
                    c += ((min(64, tot - 64 * k) + 7) >> 3) == t ? 1 : 0;
                }
                const int incl = warp_scan(c, lane);
                int r = base + incl - c;
                for (int k = 0; k < nj; ++k) {
                    if (((min(64, tot - 64 * k) + 7) >> 3) == t) {
                        S.ord[r++] = j0 + k;
                    }
                }
                base += __shfl_sync(0xffffffffu, incl, 31);
            }
        }
        if (kLight && lane == 0) {
            S.dg[17][5] = gtimer();
        }
        int mx = tot > 0 ? (min(64, tot) + 7) >> 3 : 0;
#pragma unroll
        for (int d = 16; d > 0; d >>= 1) {
            mx = max(mx, __shfl_xor_sync(0xffffffffu, mx, d));
        }
        if (lane == 31) {
            S.njobs = jincl;
            S.pa[jincl] = ca_incl;
            S.pb[jincl] = cb_incl;
            const int xsz = mx <= 2 ? 8192 : mx <= 4 ? 16384 : 32768;
            S.xsz = xsz;
            S.nsw = (kRingBytes - kNSX * xsz) / kUnitBytes;
            S.xoff = S.nsw * kUnitBytes;
        }
    } else if (warp == kNWarpsM - 2) {
        if (lane == 0 && !p.pdl) {
            constexpr unsigned kRel = lean_stage(MODE) ? kNC * 32 : kNC;
#pragma unroll
            for (int s = 0; s < kNSWMax; ++s) {
                mbar_init(&S.wfull[s], 1);
                mbar_init(&S.wempty[s], kRel);
            }
#pragma unroll
            for (int s = 0; s < kNSX; ++s) {
                mbar_init(&S.xfull[s], 1);
                mbar_init(&S.xempty[s], kRel);
            }
            asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
        }
    } else {
        const int ctid = cta * (kNC * 32) + tid;
        const int cstride = G * (kNC * 32);
        float* ss_next = p.ss + ((gen + 1) & 1) * kEmax;
        for (int i = ctid; i < kEmax; i += cstride) {
            ss_next[i] = 0.f;
        }
        if (ctid == 0) {
            p.ctr[4 + ((gen + 1) & 1)] = 0;
        }
        if (dyn_b(MODE) && tid < kBqMax) {
            S.bq[tid] = kBqEmpty;
        }
    }
    __syncthreads();
    if (kLight && tid == 0) {
        S.dg[17][1] = gtimer();
    }
    if constexpr (fast_setup(MODE)) {
        position_fill<kNWarpsM>(S.eid, S.pos, S.wc, E);
    } else {
        position_pass<kNWarpsM>(S.eid, S.pos, nullptr, S.wc, S.off, E);
    }
    if (kLight && tid == 0) {
        S.dg[17][2] = gtimer();
    }
    if (tid == 0) {
        // Owned phase A and claimed phase B read no stage range (seg_n and seg_at take own_n
        // and S.ord, the claims come through S.bq), so fast_setup leaves out the four
        // stage_at searches, 2.3-3.1 us on thread 0 in mode 27's stamps (39c365c34cd74559).
#pragma unroll
        for (int ph = 0; ph < 2; ++ph) {
            S.gsb[ph] = fast_setup(MODE) ? 0 : stage_at(S, ph, cta, G);
            S.gse[ph] = fast_setup(MODE) ? 0 : stage_at(S, ph, cta + 1, G);
        }
        if (a_only(MODE)) {
            S.gsb[1] = 0;
            S.gse[1] = 0;
        }
        if (b_only(MODE)) {
            S.gsb[0] = 0;
            S.gse[0] = 0;
        }
        if (own_a(MODE)) {
            const int units = S.njobs * (kUAM / 16);
            int n = 0;
            while (own_unit(n, cta, G) < units) {
                ++n;
            }
            S.own_n = n;
        }
    }
    // The weights producer needs only the stage ranges, so it starts streaming here while the
    // other warps gather x; they sync on their own named barrier.
    __syncthreads();
    if (kLight && tid == 0) {
        S.dg[16][1] = gtimer();
    }
    if (warp == kNC) {
        if (lane == 0) {
            wproducer<MODE>(p, S, cta, G, pol);
        }
    } else {
    const int gt = warp < kNC ? tid : tid - 32;
    constexpr int kNG = kNTM - 32;
    if constexpr (!b_only(MODE)) {
        // Phase A's x: every token row of every job into the per-stage wgmma layout, this CTA
        // taking entries cta, cta + G, ...; one release per row.
        if constexpr (fast_setup(MODE)) {
            // kGB entries' 16-byte loads go out before their stores: one row at a time, a row's
            // loads wait behind the previous row's stores (they may alias), one HBM round trip
            // per row. Thread gt < 512 moves 8 bf16 of a row, pairs 4 gt .. 4 gt + 3.
            constexpr int kGB = 8;
            for (int ib = cta; ib < E; ib += kGB * G) {
                uint4 v[kGB];
                unsigned char* dst[kGB];
#pragma unroll
                for (int k = 0; k < kGB; ++k) {
                    const int i = ib + k * G;
                    dst[k] = nullptr;
                    const int q = i < E ? S.pos[i] : -1;
                    if (q >= 0 && gt < 512) {
                        const int e = S.eid[i];
                        const int r = q - S.off[e];
                        const int jj = S.job0[e] + (r >> 6);
                        const int n = r & 63;
                        dst[k] = p.xa + static_cast<size_t>(S.job_xo[jj]) * 65536
                                 + ((4 * gt) >> 7) * S.job_ntt[jj] * 4096 + (n >> 3) * 4096
                                 + (n & 7) * 16;
                        v[k] = __ldg(reinterpret_cast<const uint4*>(
                                         p.x + static_cast<size_t>(i >> 3) * kH) + gt);
                    }
                }
#pragma unroll
                for (int k = 0; k < kGB; ++k) {
                    if (dst[k] != nullptr) {
                        const unsigned w4[4] = {v[k].x, v[k].y, v[k].z, v[k].w};
#pragma unroll
                        for (int h = 0; h < 4; ++h) {
                            const int kk = ((4 * gt + h) & 127) * 2;
                            const int step = 4 * (kk >> 6) + ((kk >> 2) & 3);
                            const int chunk8 = 2 * step + ((kk & 3) >> 1);
                            const int elem = 2 * ((kk >> 4) & 3);
                            *reinterpret_cast<unsigned*>(dst[k] + chunk8 * 128 + elem * 2) = w4[h];
                        }
                    }
                }
            }
        }
        for (int i = cta; i < (fast_setup(MODE) ? 0 : E); i += G) {
            const int q = S.pos[i];
            if (q < 0) {
                continue;
            }
            const int e = S.eid[i];
            const int r = q - S.off[e];
            const int jj = S.job0[e] + (r >> 6);
            const int n = r & 63;
            const int ntt = S.job_ntt[jj];
            const unsigned* src =
                reinterpret_cast<const unsigned*>(p.x + static_cast<size_t>(i >> 3) * kH);
            unsigned char* dst = p.xa + static_cast<size_t>(S.job_xo[jj]) * 65536 + (n >> 3) * 4096
                                 + (n & 7) * 16;
            // Pair q holds K = 2 q, 2 q + 1; its stage is q / 128 and its slab position follows
            // the fat layout's k order (epilogue_a has the same mapping).
            for (int q = gt; q < 2048; q += kNG) {
                const int kk = (q & 127) * 2;
                const int step = 4 * (kk >> 6) + ((kk >> 2) & 3);
                const int chunk8 = 2 * step + ((kk & 3) >> 1);
                const int elem = 2 * ((kk >> 4) & 3);
                *reinterpret_cast<unsigned*>(dst + (q >> 7) * ntt * 4096 + chunk8 * 128
                                             + elem * 2) = __ldg(src + q);
            }
        }
        fence_proxy_async_global();
        __threadfence();
        named_sync(kBarGather, kNG);
        // A release after the barrier: a fence before bar.sync followed by a relaxed atomic is a
        // release pattern only for the atomic thread's own earlier writes (PTX ISA 8.8), not for
        // the rows other threads stored; red.release after bar.sync covers them by cumulativity.
        for (int i = cta + gt * G; i < E; i += kNG * G) {
            if (S.pos[i] >= 0) {
                const int e = S.eid[i];
                red_release_add(p.xready + S.job0[e] + ((S.pos[i] - S.off[e]) >> 6), 1);
            }
        }
    }

    if constexpr (kDiag) {
        dt[1] = gtimer();
    }
    if (kLight && tid == 0) {
        S.dg[16][2] = gtimer();
    }
    if (skew_st(MODE) && tid == 0) {
        long long* h = sk_cta(p);
        h[0] = S.nsw;
        h[1] = clock64();
        h[2] = gtimer();
    }
    if (warp < kNC) {
        consumers<MODE>(p, S, ss, cta, G);
    } else if (lane == 0) {
        xproducer<MODE>(p, S, cta, G);
    }
    }
    __syncthreads();
    if constexpr (kDiag) {
        dt[2] = gtimer();
    }
    if (kLight && tid == 0) {
        S.dg[16][4] = gtimer();
    }

    if (tid == 0) {
        int* bc = p.ctr + 4 + (gen & 1);
        __threadfence();
        const int old = atomicAdd(bc, 1);
        if (old == G - 1) {
            atomicAdd(p.ctr + 3, 1);
        }
        if (ld_acquire(bc) < G) {
            const long long t0 = clock64();
            while (ld_acquire(bc) < G) {
                __nanosleep(64);
                if (spin_failed(t0, p.ctr, 4)) {
                    break;
                }
            }
        }
    }
    __syncthreads();
    if constexpr (kDiag) {
        dt[3] = gtimer();
    }
    if (kLight && tid == 0) {
        S.dg[16][5] = gtimer();
    }
    for (int i = cta * kNTM + tid; i < kJmaxM * 16; i += G * kNTM) {
        p.done_as[i] = 0;
    }
    for (int i = cta * kNTM + tid; i < kJmaxM; i += G * kNTM) {
        p.xready[i] = 0;
    }
    for (int i = cta * kNTM + tid; i < 2 * G * 4; i += G * kNTM) {
        p.fixcnt[i] = 0;
    }
    if (dyn_b(MODE) && cta == 0 && tid == 0) {
        p.ctr[10] = 0;
    }
    if (warp < kNC && !a_only(MODE)) {
        if constexpr (final_ss(MODE)) {
            if (finss_on<MODE>(p.M)) {
                // The rings are idle here: every bulk copy was waited on by a consumer before
                // the __syncthreads ahead of the grid barrier.
                final_pass_ss<kNC * 32>(p, S.pos, reinterpret_cast<float*>(S.rings), kBarFin,
                                        cta, G);
            } else {
                final_pass<kNC * 32>(p, S.pos, ss, cta, G);
            }
        } else {
            final_pass<kNC * 32>(p, S.pos, ss, cta, G);
        }
    }
    if constexpr (kDiag) {
        __syncthreads();
        if (tid == 0) {
            dt[4] = gtimer();
            for (int i = 0; i < 5; ++i) {
                S.dg[16][3 + i] = dt[i];
            }
            S.dg[17][3] = dc0;
            S.dg[17][4] = clock64();
        }
        __syncthreads();
        long long* out = reinterpret_cast<long long*>(p.inter) + cta * 18 * 8;
        if (tid < 18 * 8) {
            out[tid] = (&S.dg[0][0])[tid];
        }
    }
    if constexpr (kLight) {
        __syncthreads();
        if (tid == 0) {
            S.dg[16][6] = gtimer();
            if (skew_st(MODE)) {
                long long* h = sk_cta(p);
                h[3] = clock64();
                h[4] = gtimer();
            }
        }
        __syncthreads();
        if (pa_diag(MODE)) {
            if (tid < 18 * 8) {
                reinterpret_cast<long long*>(p.inter)[cta * 18 * 8 + tid] = (&S.dg[0][0])[tid];
            }
        } else if (tid < 16) {
            reinterpret_cast<long long*>(p.inter)[cta * 16 + tid] = S.dg[16 + tid / 8][tid % 8];
        }
    }
}


} // native inner namespace
} // anonymous namespace
