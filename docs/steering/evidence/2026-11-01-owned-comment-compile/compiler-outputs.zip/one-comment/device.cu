#include <cuda_runtime.h>

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_fp8.h>
#include <stdint.h>

 
 
 
 
 
 
 
 

namespace {
namespace one {

constexpr int D = 64;
constexpr int HQ = 16;
constexpr int HKV = 2;
constexpr int GROUP = HQ / HKV;
constexpr int QKV_STRIDE = (2 * HQ + 2 * HKV) * D;
constexpr int GATE_OFF = (HQ + 2 * HKV) * D;
constexpr int BN = 64;
constexpr int ROWB = HKV * D;
constexpr int TILE_BYTES = BN * ROWB;
constexpr int STAGES = 3;
constexpr int NIDX = 8;
constexpr int VT_STRIDE = 5120;
constexpr float EPS = 1e-5f;
#define NEG_INF (__int_as_float((int)0xff800000u))
 
constexpr float OFF_FLOOR = -1e30f;
constexpr int COOP_POLL_LIMIT = 1 << 24;

 
 
 
#ifndef ONE_DIAG
#define ONE_DIAG 0
#endif
 
 
 
 
#ifndef ONE_DIET
#define ONE_DIET 1
#endif
 
 
 
 
 
#ifndef ONE_FIN8
#define ONE_FIN8 1
#endif
 
 
 
 
#ifndef ONE_KVFAST
#define ONE_KVFAST 0
#endif
 
 
 
 
 
 
 
 
#ifndef ONE_QKOV
#define ONE_QKOV 1
#endif
#ifndef ONE_EREL
#define ONE_EREL 1
#endif
#ifndef ONE_PCHK
#define ONE_PCHK 1
#endif
#ifndef ONE_UNR2
#define ONE_UNR2 1
#endif
 
 
 
 
 
 
 
#ifndef ONE_PFAST
#define ONE_PFAST 1
#endif
// Bench-only attribution builds (docs/runs-attention.md, 10-29), never judged:
// ONE_STAMP=1 records per-CTA times and wait cycles into dbg[STAMP_BASE ..] (flat producer
// builds); ONE_PROBE=1 makes the producer's cached-row copies zero-fill without reading the cache
// (consumer-bound time, wrong output); ONE_PROBE=2 drops the consumers' per-tile
// fence.proxy.async after the full barrier (its cost, ordering not guaranteed); ONE_PROBE=3
// (q_len 1 flat) zero-fills as 1 and the consumers release each stage without computing on it
// (the producer-bound pace).
#ifndef ONE_STAMP
#define ONE_STAMP 0
#endif
#ifndef ONE_PROBE
#define ONE_PROBE 0
#endif
 
 
 
 
 
 
#ifndef ONE_WAVE
#define ONE_WAVE 0
#endif
 
 
 
 
 
 
 
 
#ifndef ONE_DCARRY
#define ONE_DCARRY 1
#endif
 
 
 
 
 
#ifndef ONE_PK16
#define ONE_PK16 1
#endif
 
 
 
 
 
 
#ifndef ONE_VHOIST
#define ONE_VHOIST 1
#endif
 
 
 
 
 
 
 
 
 
#ifndef ONE_XPIPE
#define ONE_XPIPE 0
#endif
 
 
 
 
 
 
#ifndef ONE_TRIG
#define ONE_TRIG 0
#endif
 
 
 
 
 
#ifndef ONE_DETM
#define ONE_DETM 0
#endif
 
 
 
 
 
 
 
 
#ifndef ONE_HMRG
#define ONE_HMRG 1
#endif
 
 
 
 
#ifndef ONE_HMRGF
#define ONE_HMRGF 0
#endif
 
 
 
 
 
 
 
#ifndef ONE_F1
#define ONE_F1 0
#endif
 
 
 
#ifndef ONE_T9
#define ONE_T9 0
#endif
 
 
 
 
 
 
 
 
 
 
 
 
#ifndef ONE_PRQ
#define ONE_PRQ 31
#endif
constexpr int STAMP_BASE = 1024;
constexpr int STAMP_W = 16;

 
 
 
 
 
constexpr int M_COOP = 2;
constexpr int M_ONE = 4;
constexpr int M_SPEC = 8;
 
constexpr int M_FLAT = 16;
 
 
constexpr int SEGK1 = 400;
constexpr int SEGK8 = 600;
 
 
constexpr int M_PROD = 32;
 
 
constexpr int M_SOLO = 64;

 
 
 
 
#ifndef ONE_NS1
#define ONE_NS1 3
#endif

// ONE_PBULK (mode 49): the producer's page entries arrive by one bulk copy per tile into a
// shared ring of PB_SLOTS windows, three tiles ahead, instead of four `ld.global.nc` per thread
// per tile held in registers. The mechanism is the public flat q_len 1 kernel's (vjeux,
// okc-2026, Apache-2.0: `fetch_pages` / `load_pages_t`); this is our own code for our ring.
// Bench 4b60264a276c4805: mode 49's producer alone trails the public producer by 4.7 / 8.0 us
// at decode 16 / 32 full without DRAM traffic.
#ifndef ONE_PBULK
#define ONE_PBULK 0
#endif
 
 
#ifndef ONE_PBDBG
#define ONE_PBDBG 0
#endif

__host__ __device__ constexpr bool one_pb(int L, int mode) {
    return ONE_PBULK != 0 && L == 1 && (mode & M_PROD) && !(mode & M_SOLO);
}

__host__ __device__ constexpr int one_ns(int L, int mode) {
    return (mode & M_PROD) && L == 8 ? 4 : ((mode & M_PROD) && L == 1 ? ONE_NS1 : STAGES);
}

__host__ __device__ constexpr int one_threads(int L, int mode) {
    return (L == 8 ? 256 : 128) + ((mode & M_PROD) ? 128 : 0);
}

__host__ __device__ constexpr int one_minb(int L, int mode) {
    return (mode & M_SOLO) ? 1 : (L == 8 || (mode & M_PROD) ? 2 : 4);
}

 
 
 
__host__ __device__ constexpr int one_prod_regs(int L) {
    return L == 8 ? 32 : 56;
}

__host__ __device__ constexpr int one_cons_regs(int L) {
    return L == 8 ? (ONE_XPIPE == 1 ? 112 : 104) : 200;
}

 
 
constexpr int CNT_COOP = 4096;
constexpr int CNT_EPOCH = 8192;
constexpr int CNT_FLAT = 16384;
 
constexpr int CNT_SMR = CNT_FLAT + 4096;
constexpr int CNT_INTS = 32768;

struct Params {
    const __nv_bfloat16* qkv;
    const int* page_table;
    const int* seq_lens;
    const int64_t* cache_loc;
    const float* inv_freq;
    const float* k_scale;
    const float* v_scale;
    uint8_t* k_cache;
    uint8_t* v_cache;
    __nv_bfloat16* out;
    float* ws_acc;
    float* ws_l;
    int* ws_cnt;
    int* dbg;
    int pt_stride;
    int page_size;
    int window;
    int rope;
    int n_splits;
    uint32_t magic;
    int nc;
    float sl2;
     
     
    int phase_limit;
     
    int lp;
     
    int off32;
     
    int wave_n;
};

constexpr int PB_SLOTS = 4;
constexpr int PB_SLOT_BYTES = 320;

template <int L, int NS, bool PB = false>
struct Smem {
    static constexpr int ROWS = HQ * L;
    static constexpr int KV = 0;
    static constexpr int Q = KV + NS * 2 * TILE_BYTES;
    static constexpr int Q_BYTES = L == 8 ? HKV * 4096 : HQ * 128;
    static constexpr int VT = Q + Q_BYTES;
    static constexpr int VT_BYTES = L == 8 ? 4 * VT_STRIDE : 0;
     
    static constexpr int QST = VT;
    static constexpr int QST_BYTES = ROWS * 128;
    static constexpr int KVST = QST + (QST_BYTES > VT_BYTES ? QST_BYTES : VT_BYTES);
    static constexpr int KN = KVST + L * 4 * 128;
    static constexpr int VN = KN + L * ROWB;
    static constexpr int IDX = VN + L * ROWB;
    static constexpr int ROPE = IDX + NIDX * BN * 4;
    static constexpr int CONST = ROPE + L * 2 * 32 * 4;
    static constexpr int FLAG = CONST + 256;
     
    static constexpr int OFF = FLAG + 32;
     
    static constexpr int BAR = OFF + 2304;
     
     
    static constexpr int PSL = (BAR + 2 * NS * 8 + 127) / 128 * 128;
    static constexpr int PBAR = PSL + PB_SLOTS * PB_SLOT_BYTES;
     
    static constexpr int PFREE = PBAR + PB_SLOTS * 8;
    static constexpr int BYTES = PB ? PFREE + PB_SLOTS * 8 : BAR + 2 * NS * 8;
    static_assert(Q % 1024 == 0 && VT % 1024 == 0, "swizzled tiles need 1024-byte bases");
};

 
 
constexpr int C_INVF = 0;
constexpr int C_KS = 128;
constexpr int C_VS = 132;
constexpr int C_EPOCH = 136;
constexpr int C_LOC = 160;

__device__ __forceinline__ uint32_t smem_u32(const void* p) {
    return static_cast<uint32_t>(__cvta_generic_to_shared(p));
}

__device__ __forceinline__ void cp_async16(uint32_t dst, const void* src, uint32_t bytes) {
    asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;\n"
                 :: "r"(dst), "l"(src), "r"(bytes) : "memory");
}

 
__device__ __forceinline__ void cp_async16_if(uint32_t dst, const void* src, uint32_t bytes,
                                              bool doit) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, %3, 0;\n"
                 "@p cp.async.cg.shared.global [%0], [%1], 16, %2;\n}\n"
                 :: "r"(dst), "l"(src), "r"(bytes), "r"(static_cast<int>(doit)) : "memory");
}

__device__ __forceinline__ void cp_async4(uint32_t dst, const void* src, uint32_t bytes) {
    asm volatile("cp.async.ca.shared.global [%0], [%1], 4, %2;\n"
                 :: "r"(dst), "l"(src), "r"(bytes) : "memory");
}

__device__ __forceinline__ void cp_async8(uint32_t dst, const void* src, uint32_t bytes) {
    asm volatile("cp.async.ca.shared.global [%0], [%1], 8, %2;\n"
                 :: "r"(dst), "l"(src), "r"(bytes) : "memory");
}

__device__ __forceinline__ void cp_commit() {
    asm volatile("cp.async.commit_group;\n" ::: "memory");
}

template <int N>
__device__ __forceinline__ void cp_wait() {
    asm volatile("cp.async.wait_group %0;\n" :: "n"(N) : "memory");
}

__device__ __forceinline__ void fence_proxy_async() {
    asm volatile("fence.proxy.async.shared::cta;\n" ::: "memory");
}

__device__ __forceinline__ void named_sync(int id, int count) {
    asm volatile("bar.sync %0, %1;\n" :: "r"(id), "r"(count) : "memory");
}

 
__device__ __forceinline__ bool named_sync_or(int id, int count, bool v) {
    uint32_t r;
    asm volatile("{\n.reg .pred pi, po;\nsetp.ne.u32 pi, %3, 0;\n"
                 "bar.red.or.pred po, %1, %2, pi;\nselp.u32 %0, 1, 0, po;\n}\n"
                 : "=r"(r) : "r"(id), "r"(count), "r"(static_cast<uint32_t>(v)) : "memory");
    return r != 0;
}

__device__ __forceinline__ void mbar_init(uint32_t bar, int count) {
    asm volatile("mbarrier.init.shared::cta.b64 [%0], %1;\n" :: "r"(bar), "r"(count) : "memory");
}

__device__ __forceinline__ void mbar_arrive(uint32_t bar) {
    asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0];\n" :: "r"(bar) : "memory");
}

__device__ __forceinline__ void mbar_expect_tx(uint32_t bar, int bytes) {
    asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;\n"
                 :: "r"(bar), "r"(bytes) : "memory");
}

 
 
__device__ __forceinline__ void bulk_g2s(uint32_t dst, const void* src, int bytes, uint32_t bar) {
    asm volatile("cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes "
                 "[%0], [%1], %2, [%3];\n"
                 :: "r"(dst), "l"(src), "r"(bytes), "r"(bar) : "memory");
}

 
 
__device__ __forceinline__ void cp_async_mbar_arrive_noinc(uint32_t bar) {
    asm volatile("cp.async.mbarrier.arrive.noinc.shared::cta.b64 [%0];\n" :: "r"(bar) : "memory");
}

__device__ __forceinline__ bool mbar_try(uint32_t bar, uint32_t parity) {
    uint32_t ok;
    asm volatile("{\n.reg .pred p;\n"
                 "mbarrier.try_wait.parity.shared::cta.b64 p, [%1], %2;\n"
                 "selp.u32 %0, 1, 0, p;\n}\n"
                 : "=r"(ok) : "r"(bar), "r"(parity) : "memory");
    return ok != 0;
}

 
 
__device__ __forceinline__ void mbar_wait(uint32_t bar, uint32_t parity) {
    if (mbar_try(bar, parity)) {
        return;
    }
    int polls = 0;
    while (!mbar_try(bar, parity)) {
        if (++polls > (1 << 26)) {
            __trap();
        }
    }
}

template <int N>
__device__ __forceinline__ void setmaxnreg_inc() {
    asm volatile("setmaxnreg.inc.sync.aligned.u32 %0;\n" :: "n"(N));
}

template <int N>
__device__ __forceinline__ void setmaxnreg_dec() {
    asm volatile("setmaxnreg.dec.sync.aligned.u32 %0;\n" :: "n"(N));
}

__device__ __forceinline__ void prefetch_l2(const void* p) {
    asm volatile("prefetch.global.L2 [%0];\n" :: "l"(p));
}

__device__ __forceinline__ int ld_nc_s32(const int* p) {
    int v;
    asm volatile("ld.global.nc.s32 %0, [%1];\n" : "=r"(v) : "l"(p));
    return v;
}

__device__ __forceinline__ void red_add_v4(float* p, float a, float b, float c, float d) {
    asm volatile("red.global.add.v4.f32 [%0], {%1, %2, %3, %4};\n"
                 :: "l"(p), "f"(a), "f"(b), "f"(c), "f"(d) : "memory");
}

__device__ __forceinline__ void red_add_f32(float* p, float a) {
    asm volatile("red.global.add.f32 [%0], %1;\n" :: "l"(p), "f"(a) : "memory");
}

__device__ __forceinline__ int atom_add_acq_rel(int* p, int v) {
    int old;
    asm volatile("atom.acq_rel.gpu.global.add.s32 %0, [%1], %2;\n"
                 : "=r"(old) : "l"(p), "r"(v) : "memory");
    return old;
}

__device__ __forceinline__ int ld_acquire(const int* p) {
    int v;
    asm volatile("ld.acquire.gpu.global.s32 %0, [%1];\n" : "=r"(v) : "l"(p) : "memory");
    return v;
}

__device__ __forceinline__ float4 ld_cg_f4(const float* p) {
    return __ldcg(reinterpret_cast<const float4*>(p));
}

__device__ __forceinline__ void st_cg_f4(float* p, float4 v) {
    __stcg(reinterpret_cast<float4*>(p), v);
}

__device__ __forceinline__ float ex2(float x) {
    float y;
    asm("ex2.approx.ftz.f32 %0, %1;\n" : "=f"(y) : "f"(x));
    return y;
}

 
__device__ __forceinline__ uint32_t e4m3x4(float a, float b, float c, float d) {
    uint16_t lo, hi;
    asm("cvt.rn.satfinite.e4m3x2.f32 %0, %1, %2;\n" : "=h"(lo) : "f"(b), "f"(a));
    asm("cvt.rn.satfinite.e4m3x2.f32 %0, %1, %2;\n" : "=h"(hi) : "f"(d), "f"(c));
#if ONE_PK16
    return static_cast<uint32_t>(lo) | (static_cast<uint32_t>(hi) << 16);
#else
    return __byte_perm(static_cast<uint32_t>(lo), static_cast<uint32_t>(hi), 0x5410);
#endif
}

__device__ __forceinline__ uint16_t e4m3x2(float a, float b) {
    uint16_t v;
    asm("cvt.rn.satfinite.e4m3x2.f32 %0, %1, %2;\n" : "=h"(v) : "f"(b), "f"(a));
    return v;
}

__device__ __forceinline__ uint32_t f16x2_from_e4m3x2(uint32_t two) {
    uint32_t r;
    asm("cvt.rn.f16x2.e4m3x2 %0, %1;\n" : "=r"(r) : "h"(static_cast<uint16_t>(two)));
    return r;
}

__device__ __forceinline__ uint32_t pack_f16(float a, float b) {
    __half2 h = __floats2half2_rn(a, b);
    return *reinterpret_cast<uint32_t*>(&h);
}

__device__ __forceinline__ float warp_sum(float v) {
    for (int o = 16; o; o >>= 1) {
        v += __shfl_xor_sync(0xffffffffu, v, o);
    }
    return v;
}

 
__device__ __forceinline__ float oct_sum(float v) {
    v += __shfl_xor_sync(0xffffffffu, v, 1);
    v += __shfl_xor_sync(0xffffffffu, v, 2);
    v += __shfl_xor_sync(0xffffffffu, v, 4);
    return v;
}

__device__ __forceinline__ float quad_sum(float v) {
    v += __shfl_xor_sync(0xffffffffu, v, 1);
    v += __shfl_xor_sync(0xffffffffu, v, 2);
    return v;
}

__device__ __forceinline__ float quad_max(float v) {
    v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 1));
    v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 2));
    return v;
}

 
 
 
__device__ __forceinline__ float2 fast_sincos(float x) {
    const float k = rintf(x * 0.15915494309189535f);
    float r = fmaf(-k, 6.2831854820251465f, x);
    r = fmaf(-k, -1.7484555314695172e-7f, r);
    return make_float2(__sinf(r), __cosf(r));
}

__device__ __forceinline__ uint64_t globaltimer_ns() {
    uint64_t t;
    asm volatile("mov.u64 %0, %%globaltimer;\n" : "=l"(t));
    return t;
}

__device__ __forceinline__ float sigmoid(float x) {
    return __fdividef(1.f, 1.f + __expf(-x));
}

 
 
__device__ __forceinline__ void mma_f16(float (&c)[4], uint32_t a0, uint32_t a1, uint32_t a2,
                                        uint32_t a3, uint32_t b0, uint32_t b1) {
    asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 "
                 "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
                 : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3])
                 : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}

__device__ __forceinline__ void ldsm_x4_trans(uint32_t addr, uint32_t& r0, uint32_t& r1,
                                              uint32_t& r2, uint32_t& r3) {
    asm volatile("ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 {%0,%1,%2,%3}, [%4];\n"
                 : "=r"(r0), "=r"(r1), "=r"(r2), "=r"(r3) : "r"(addr) : "memory");
}

__device__ __forceinline__ void stsm_x4(uint32_t addr, uint32_t r0, uint32_t r1, uint32_t r2,
                                        uint32_t r3) {
    asm volatile("stmatrix.sync.aligned.m8n8.x4.shared.b16 [%0], {%1,%2,%3,%4};\n"
                 :: "r"(addr), "r"(r0), "r"(r1), "r"(r2), "r"(r3) : "memory");
}

 
 
 
 
__device__ __forceinline__ uint64_t desc_kmaj(uint32_t addr, int lbo, int sbo) {
    return ((addr & 0x3ffffu) >> 4) | (static_cast<uint64_t>(lbo >> 4) << 16)
           | (static_cast<uint64_t>(sbo >> 4) << 32);
}

__device__ __forceinline__ uint64_t desc_sw128(uint32_t addr) {
    return ((addr & 0x3ffffu) >> 4) | (static_cast<uint64_t>(1) << 16)
           | (static_cast<uint64_t>(1024 >> 4) << 32) | (static_cast<uint64_t>(1) << 62);
}

__device__ __forceinline__ uint64_t desc_sw64(uint32_t addr) {
    return ((addr & 0x3ffffu) >> 4) | (static_cast<uint64_t>(1) << 16)
           | (static_cast<uint64_t>(512 >> 4) << 32) | (static_cast<uint64_t>(2) << 62);
}

__device__ __forceinline__ void wg_fence() {
    asm volatile("wgmma.fence.sync.aligned;\n" ::: "memory");
}

__device__ __forceinline__ void wg_commit() {
    asm volatile("wgmma.commit_group.sync.aligned;\n" ::: "memory");
}

template <int N>
__device__ __forceinline__ void wg_wait() {
    asm volatile("wgmma.wait_group.sync.aligned %0;\n" :: "n"(N) : "memory");
}

template <int N>
__device__ __forceinline__ void reg_fence(float (&d)[N]) {
#pragma unroll
    for (int i = 0; i < N; ++i) {
        asm volatile("" : "+f"(d[i]) :: "memory");
    }
}

#define WG_D32 "{%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15, " \
    "%16, %17, %18, %19, %20, %21, %22, %23, %24, %25, %26, %27, %28, %29, %30, %31}"
#define WG_OUT32(d) "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]), "+f"(d[4]), "+f"(d[5]), \
    "+f"(d[6]), "+f"(d[7]), "+f"(d[8]), "+f"(d[9]), "+f"(d[10]), "+f"(d[11]), "+f"(d[12]), \
    "+f"(d[13]), "+f"(d[14]), "+f"(d[15]), "+f"(d[16]), "+f"(d[17]), "+f"(d[18]), "+f"(d[19]), \
    "+f"(d[20]), "+f"(d[21]), "+f"(d[22]), "+f"(d[23]), "+f"(d[24]), "+f"(d[25]), "+f"(d[26]), \
    "+f"(d[27]), "+f"(d[28]), "+f"(d[29]), "+f"(d[30]), "+f"(d[31])

 
 
template <int ACC>
__device__ __forceinline__ void wgmma_qk(float (&d)[32], uint64_t da, uint64_t db) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, %34, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n64k32.f32.e4m3.e4m3 " WG_D32
                 ", %32, %33, p, 1, 1;\n}\n"
                 : WG_OUT32(d) : "l"(da), "l"(db), "n"(ACC));
}

 
 
__device__ __forceinline__ void wgmma_pv(float (&d)[36], const uint32_t (&a)[4], uint64_t db) {
    asm volatile("{\n.reg .pred p;\nsetp.ne.b32 p, 1, 0;\n"
                 "wgmma.mma_async.sync.aligned.m64n72k32.f32.e4m3.e4m3 "
                 "{%0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10, %11, %12, %13, %14, %15, "
                 "%16, %17, %18, %19, %20, %21, %22, %23, %24, %25, %26, %27, %28, %29, %30, "
                 "%31, %32, %33, %34, %35}, {%36, %37, %38, %39}, %40, p, 1, 1;\n}\n"
                 : WG_OUT32(d), "+f"(d[32]), "+f"(d[33]), "+f"(d[34]), "+f"(d[35])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "l"(db));
}

 
 
 
 
template <int L>
__device__ __forceinline__ int k_swz(int chunk, int row) {
    return L == 8 ? chunk ^ (row & 7) : chunk ^ ((row & 1) << 2);
}

template <int L>
__device__ __forceinline__ int v_swz(int chunk, int row) {
    return L == 8 ? chunk ^ (row & 7) : chunk ^ (((row >> 1) & 3) << 1);
}

 
__device__ __forceinline__ int kmaj(int r, int kc) {
    return ((r >> 3) * 4 + kc) * 128 + (r & 7) * 16;
}

#if ONE_DETM
 
constexpr int DET_ROW = 68;

__device__ __forceinline__ size_t det_slot(int b, int G, int s, int w, int head) {
    return ((((static_cast<size_t>(b) * G + s) * 2 + w) * HQ) + head) * DET_ROW;
}
#endif

 
__device__ __forceinline__ int ws_row(int b, int nc, int copy, int L, int j, int head) {
    return ((b * nc + copy) * L + j) * HQ + head;
}


 
 
template <int L, int NT, bool NC8 = false>
__device__ __forceinline__ void finalize_rows(const Params& p, int r_lo, int r_hi, float v_scale,
                                              int tid) {
    constexpr int RPP = NT / 8;
    constexpr int ROWS = HQ * L;
    const int t8 = tid & 7;
    for (int base = r_lo; base < r_hi; base += RPP) {
        const int r = base + (tid >> 3);
        const bool act = r < r_hi;
        const int b = r / ROWS;
        const int lr = r - b * ROWS;
        const int j = lr >> 4;
        const int head = lr & 15;
        const size_t tok = static_cast<size_t>(b) * L + j;
        uint4 graw = make_uint4(0, 0, 0, 0);
        if (act) {
            graw = __ldg(reinterpret_cast<const uint4*>(p.qkv + tok * QKV_STRIDE + GATE_OFF
                                                        + head * D + t8 * 8));
        }
        float acc[8] = {0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f};
        float lsum = 0.f;
        if (NC8 && p.nc == 8) {
             
             
            float4 a[8], a2[8];
            float lv[8];
#pragma unroll
            for (int copy = 0; copy < 8; ++copy) {
                const int wr = ws_row(b, 8, copy, L, j, head);
                const float* row = p.ws_acc + static_cast<size_t>(wr) * D + t8 * 8;
                a[copy] = act ? ld_cg_f4(row) : make_float4(0.f, 0.f, 0.f, 0.f);
                a2[copy] = act ? ld_cg_f4(row + 4) : make_float4(0.f, 0.f, 0.f, 0.f);
                lv[copy] = act && t8 == 0 ? __ldcg(p.ws_l + wr) : 0.f;
            }
            float lsum8 = 0.f;
#pragma unroll
            for (int copy = 0; copy < 8; ++copy) {
                acc[0] += a[copy].x;
                acc[1] += a[copy].y;
                acc[2] += a[copy].z;
                acc[3] += a[copy].w;
                acc[4] += a2[copy].x;
                acc[5] += a2[copy].y;
                acc[6] += a2[copy].z;
                acc[7] += a2[copy].w;
                lsum8 += lv[copy];
            }
            lsum = __shfl_sync(0xffffffffu, lsum8, (tid & 31) & ~7);
            if (act) {
#pragma unroll
                for (int copy = 0; copy < 8; ++copy) {
                    const int wr = ws_row(b, 8, copy, L, j, head);
                    float* row = p.ws_acc + static_cast<size_t>(wr) * D + t8 * 8;
                    st_cg_f4(row, make_float4(0.f, 0.f, 0.f, 0.f));
                    st_cg_f4(row + 4, make_float4(0.f, 0.f, 0.f, 0.f));
                    if (t8 == 0) {
                        __stcg(p.ws_l + wr, 0.f);
                    }
                }
            }
        }
         
         
        for (int copy = 0; copy < (NC8 && p.nc == 8 ? 0 : p.nc); ++copy) {
            const int wr = ws_row(b, p.nc, copy, L, j, head);
            float* row = p.ws_acc + static_cast<size_t>(wr) * D + t8 * 8;
            float* lp = p.ws_l + wr;
            float lv = 0.f;
            if (act) {
                const float4 a = ld_cg_f4(row);
                const float4 a2 = ld_cg_f4(row + 4);
                acc[0] += a.x;
                acc[1] += a.y;
                acc[2] += a.z;
                acc[3] += a.w;
                acc[4] += a2.x;
                acc[5] += a2.y;
                acc[6] += a2.z;
                acc[7] += a2.w;
                if (t8 == 0) {
                    lv = __ldcg(lp);
                }
            }
            lsum += __shfl_sync(0xffffffffu, lv, (tid & 31) & ~7);
            if (act) {
                st_cg_f4(row, make_float4(0.f, 0.f, 0.f, 0.f));
                st_cg_f4(row + 4, make_float4(0.f, 0.f, 0.f, 0.f));
                if (t8 == 0) {
                    __stcg(lp, 0.f);
                }
            }
        }
        const float inv = lsum > 0.f ? __fdividef(v_scale, lsum) : 0.f;
        float ss = 0.f;
#pragma unroll
        for (int e = 0; e < 8; ++e) {
            acc[e] = __bfloat162float(__float2bfloat16_rn(acc[e] * inv));
            ss += acc[e] * acc[e];
        }
        ss = oct_sum(ss);
        const float rn = rsqrtf(ss * (1.f / D) + EPS);
        if (act) {
            const uint32_t gw[4] = {graw.x, graw.y, graw.z, graw.w};
            uint32_t ow[4];
#pragma unroll
            for (int e = 0; e < 4; ++e) {
                const float2 gt =
                    __bfloat1622float2(*reinterpret_cast<const __nv_bfloat162*>(&gw[e]));
                const __nv_bfloat162 o2 = __float22bfloat162_rn(
                    make_float2(acc[2 * e] * rn * sigmoid(gt.x), acc[2 * e + 1] * rn * sigmoid(gt.y)));
                ow[e] = *reinterpret_cast<const uint32_t*>(&o2);
            }
            *reinterpret_cast<uint4*>(p.out + tok * HQ * D + head * D + t8 * 8) =
                make_uint4(ow[0], ow[1], ow[2], ow[3]);
        }
    }
}

 
 
 
 
template <int NC>
__device__ __forceinline__ void coop_barrier(int* cnt, int* epoch, int ep, int mine, int total,
                                             int tid, int* dbg) {
    if (tid == 0) {
        const int old = atom_add_acq_rel(cnt + (ep & 1), mine);
        if (mine > 0 && old + mine == total) {
            __stcg(cnt + ((ep + 1) & 1), 0);
            __stcg(epoch, ep + 1);
        }
        int polls = 0;
        while (ld_acquire(cnt + (ep & 1)) < total) {
            __nanosleep(64);
            if (++polls > COOP_POLL_LIMIT) {
                __trap();
            }
        }
        if (dbg != nullptr) {
            atomicMax(dbg, polls);
        }
    }
    named_sync(1, NC);
}

#if ONE_DETM
 
 
 
template <int SEGK>
__device__ void finalize_det(const Params& p, const int* offs, int B, int G, int b,
                             float v_scale, int tid) {
    const float* part = reinterpret_cast<const float*>(p.dbg);
    const int head = tid >> 3;
    const int t8 = tid & 7;
    const long long total_v = offs[B] - SEGK;
    const int a = offs[b];
    const int n_b = offs[b + 1] - a - SEGK;
    float acc[8] = {0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f};
    float lsum = 0.f;
    for (int s = 0; s < G; ++s) {
        const int v0 = static_cast<int>(total_v * s / G);
        const int v1 = static_cast<int>(total_v * (s + 1) / G);
        if (!(a + n_b > v0 && a < v1)) {
            continue;
        }
        const int s0 = max(v0, a) - a;
        const int s1 = min(v1, a + n_b) - a;
        const int lo_k = s0 > 0 ? (s0 & ~(BN - 1)) : 0;
        const int hi_k = s1 < n_b ? (s1 & ~(BN - 1)) : n_b;
        if (lo_k >= hi_k) {
            continue;
        }
        for (int w = 0; w < 2; ++w) {
            const float* row = part + det_slot(b, G, s, w, head);
            const float4 x = ld_cg_f4(row + t8 * 8);
            const float4 y = ld_cg_f4(row + t8 * 8 + 4);
            acc[0] += x.x;
            acc[1] += x.y;
            acc[2] += x.z;
            acc[3] += x.w;
            acc[4] += y.x;
            acc[5] += y.y;
            acc[6] += y.z;
            acc[7] += y.w;
            lsum += __ldcg(row + 64);
        }
    }
    const float inv = lsum > 0.f ? __fdividef(v_scale, lsum) : 0.f;
    float ss = 0.f;
#pragma unroll
    for (int e = 0; e < 8; ++e) {
        acc[e] = __bfloat162float(__float2bfloat16_rn(acc[e] * inv));
        ss += acc[e] * acc[e];
    }
    ss = oct_sum(ss);
    const float rn = rsqrtf(ss * (1.f / D) + EPS);
    const uint4 graw = __ldg(reinterpret_cast<const uint4*>(
        p.qkv + static_cast<size_t>(b) * QKV_STRIDE + GATE_OFF + head * D + t8 * 8));
    const uint32_t gw[4] = {graw.x, graw.y, graw.z, graw.w};
    uint32_t ow[4];
#pragma unroll
    for (int e = 0; e < 4; ++e) {
        const float2 gt = __bfloat1622float2(*reinterpret_cast<const __nv_bfloat162*>(&gw[e]));
        const __nv_bfloat162 o2 = __float22bfloat162_rn(
            make_float2(acc[2 * e] * rn * sigmoid(gt.x), acc[2 * e + 1] * rn * sigmoid(gt.y)));
        ow[e] = *reinterpret_cast<const uint32_t*>(&o2);
    }
    *reinterpret_cast<uint4*>(p.out + static_cast<size_t>(b) * HQ * D + head * D + t8 * 8) =
        make_uint4(ow[0], ow[1], ow[2], ow[3]);
}
#endif

template <int L, int MODE>
__global__ void __launch_bounds__(one_threads(L, MODE), one_minb(L, MODE))
attn_one_kernel(const Params p) {
    constexpr bool COOP = (MODE & M_COOP) != 0;
    constexpr bool ONE = (MODE & M_ONE) != 0;
    constexpr bool SPEC = (MODE & M_SPEC) != 0;
    constexpr bool FLAT = (MODE & M_FLAT) != 0;
    constexpr bool PROD = (MODE & M_PROD) != 0;
    constexpr bool SOLO = (MODE & M_SOLO) != 0;
    static_assert(!FLAT || !(ONE || SPEC), "flat mode partitions its own ranges");
    static_assert(!PROD || FLAT, "the producer warpgroup belongs to the flat kernel");
    static_assert(!SOLO || PROD, "SOLO is a producer-mode variant");
     
     
     
    constexpr bool DIET = ONE_DIET && !(PROD && L == 8);
     
     
     
    constexpr bool FIN8 = ONE_FIN8 && SPEC && !ONE;
    constexpr bool HMRG = (ONE_HMRG && !FLAT && L == 1) || (ONE_HMRGF && FLAT && L == 1);
    constexpr bool QKOV = ONE_QKOV && PROD && L == 8;
    constexpr bool EREL = ONE_EREL && PROD && L == 8;
    constexpr bool PCHK = ONE_PCHK && PROD && L == 8;
    constexpr int UNR8 = ONE_UNR2 && PROD && L == 8 ? 2 : 1;
    constexpr bool DCARRY = ONE_DCARRY && PROD && L == 8;
    constexpr bool VHOIST = ONE_VHOIST && QKOV;
    constexpr int XPIPE = PROD && L == 8 ? ONE_XPIPE : 0;
    static_assert(XPIPE == 0 || (QKOV && EREL && PCHK && DCARRY && VHOIST),
                  "ONE_XPIPE is written on top of the promoted mode 51 tile loop");
    constexpr bool WAVE = ONE_WAVE > 0 && PROD && !SOLO && L == 8;
    constexpr bool DETM = ONE_DETM && FLAT && !COOP && L == 1;
    constexpr int PRQ = !FLAT && L == 8 ? ONE_PRQ : 0;
    constexpr bool QK2 = (ONE_F1 & 1) && FLAT && L == 1;
    constexpr bool PE16 = (ONE_F1 & 2) && PROD && L == 1;
     
     
    constexpr int NC = L == 8 ? 256 : 128;
    constexpr int NS = one_ns(L, MODE);
    constexpr int ROWS = HQ * L;
    constexpr int SEGK = L == 8 ? SEGK8 : SEGK1;
    constexpr int PF = 3;
    constexpr bool PBULK = one_pb(L, MODE);
    using S = Smem<L, NS, PBULK>;
    extern __shared__ __align__(1024) uint8_t smem[];
    const int split = blockIdx.x;
    const int tid = threadIdx.x;
    const int warp = tid >> 5;
    const int lane = tid & 31;
    const int g = lane >> 2;
    const int c = lane & 3;
    const int psize = p.page_size;
    const uint32_t smem_base = smem_u32(smem);
    int* idx_ring = reinterpret_cast<int*>(smem + S::IDX);
    int* flag = reinterpret_cast<int*>(smem + S::FLAG);
    const uint32_t full0 = smem_base + S::BAR;
    const uint32_t empty0 = full0 + NS * 8;
     
     
    if constexpr (ONE_TRIG != 0 && (L == 1 || SPEC)) {
        asm volatile("griddepcontrol.launch_dependents;");
    }

     
     
#define PHASE_EXIT(k) \
    if (ONE_DIAG && p.phase_limit == (k)) { cp_wait<0>(); return false; }
     
     
    auto stamp = [&](int k) {
        if constexpr (ONE_DIAG) {
            if (p.dbg != nullptr && split == 0 && blockIdx.y == 0 && tid == 0) {
                p.dbg[1 + k] = static_cast<int>(globaltimer_ns() / 1000u);
            }
        }
    };
     
     
     
    constexpr bool STAMPS = ONE_STAMP && PROD;
    int* const srow = STAMPS && p.dbg != nullptr ? p.dbg + STAMP_BASE + split * STAMP_W : nullptr;
    auto srec = [&](int k, long long v) {
        if constexpr (STAMPS) {
            if (srow != nullptr) {
                srow[k] = static_cast<int>(v);
            }
        }
    };
    auto snow = [&]() -> long long {
        if constexpr (STAMPS) {
            return static_cast<long long>(globaltimer_ns() & 0xffffffffull);
        }
        return 0;
    };
    long long s_fullw = 0, s_pro = 0, s_loop = 0, s_seg0 = 0, s_l0 = 0;
    const long long s_k0 = STAMPS ? clock64() : 0;
    int s_tiles = 0, s_nseg = 0;
    if constexpr (STAMPS) {
        if (tid == 0) {
            srec(0, snow());
            uint32_t smid;
            asm volatile("mov.u32 %0, %%smid;\n" : "=r"(smid));
            srec(15, smid);
        }
    }
     
    auto csync = [&]() {
        if constexpr (PROD) {
            named_sync(1, NC);
        } else {
            __syncthreads();
        }
    };

     
    int b = FLAT ? 0 : blockIdx.y;
    const int* pt = p.page_table + static_cast<size_t>(b) * p.pt_stride;
    int seq = 0, start = 0, end = 0, n_keys = 0, lo = 0, hi = 0, ntiles = 0, nact = 0;
    int chunk_keys = 0;
     
     
    const int seq_real = FLAT ? 0 : ld_nc_s32(p.seq_lens + b);
    auto derive = [&]() {
        start = p.window ? max(0, seq - p.window + 1) : 0;
        end = seq + L;
        n_keys = end - start;
        const int ntl = (n_keys + BN - 1) >> 6;
        const int chunk = ONE ? 1 : (p.magic ? static_cast<int>(__umulhi(
                                        static_cast<uint32_t>(ntl + p.n_splits - 1), p.magic))
                                              : ntl);
        chunk_keys = chunk << 6;
        lo = start + split * chunk_keys;
        hi = min(end, lo + chunk_keys);
        ntiles = ONE ? 1 : max(0, (hi - lo + BN - 1) >> 6);
        nact = COOP ? min(p.n_splits, (ntl + chunk - 1) / chunk) : 0;
    };

     
     
     
     
    int* offs = reinterpret_cast<int*>(smem + S::OFF);
    int v0 = 0, v1 = 0, b_first = 0, b_last = -1, keys_all = 0;
    const int B = FLAT ? p.n_splits : 1;
    const int G = gridDim.x;
     
     
     
    auto seg_bounds = [&](int bb) -> bool {
        const int a = offs[bb];
        const int n_b = offs[bb + 1] - a - SEGK;
        const int s0 = max(v0, a) - a;
        const int s1 = min(v1, a + n_b) - a;
        const int lo_k = s0 > 0 ? (s0 & ~(BN - 1)) : 0;
        const int hi_k = s1 < n_b ? (s1 & ~(BN - 1)) : n_b;
        if (lo_k >= hi_k) {
            return false;
        }
        pt = p.page_table + static_cast<size_t>(bb) * p.pt_stride;
        seq = n_b - L;
        start = 0;
        end = n_b;
        n_keys = n_b;
        lo = lo_k;
        hi = hi_k;
        ntiles = (hi - lo + BN - 1) >> 6;
        return true;
    };
    const bool wave_on = WAVE && G == 2 * p.wave_n;
    if constexpr (FLAT) {
        if (wave_on && tid == 32) {
             
             
             
             
             
             
            uint32_t smid;
            asm volatile("mov.u32 %0, %%smid;\n" : "=r"(smid));
            const int old = atomicAdd(p.ws_cnt + CNT_SMR + smid, 1);
            if (old & 1) {
                atomicExch(p.ws_cnt + CNT_SMR + smid, 0);
            }
            flag[3] = 2 * static_cast<int>(smid) + (old & 1);
        }
        if (warp == 0) {
            int carry = 0;
            for (int base = 0; base < B; base += 32) {
                const int bb = base + lane;
                const int n = bb < B ? __ldg(p.seq_lens + bb) + L + SEGK : 0;
                int inc = n;
#pragma unroll
                for (int o = 1; o < 32; o <<= 1) {
                    const int t = __shfl_up_sync(0xffffffffu, inc, o);
                    if (lane >= o) {
                        inc += t;
                    }
                }
                if (bb < B) {
                    offs[bb] = carry + inc - n;
                }
                carry += __shfl_sync(0xffffffffu, inc, 31);
            }
            if (lane == 0) {
                offs[B] = carry;
            }
        }
        if (tid == 0) {
            flag[1] = B;
            flag[2] = -1;
            if constexpr (PROD) {
#pragma unroll
                for (int s = 0; s < NS; ++s) {
                    mbar_init(full0 + 8 * s, 128);
                    mbar_init(empty0 + 8 * s, NC);
                }
                if constexpr (PBULK) {
#pragma unroll
                    for (int s = 0; s < PB_SLOTS; ++s) {
                        mbar_init(smem_base + S::PBAR + 8 * s, 1);
                        mbar_init(smem_base + S::PFREE + 8 * s, 128);
                    }
                }
                asm volatile("fence.mbarrier_init.release.cluster;\n" ::: "memory");
            }
        }
        __syncthreads();
        const long long total_v = offs[B] - SEGK;
        if (wave_on) {
            const int slot = flag[3];
            auto wsum = [&](int k) -> long long {
                return static_cast<long long>(k >> 1) * (ONE_WAVE + 1024)
                       + static_cast<long long>(k & 1) * ONE_WAVE;
            };
            const long long wg = wsum(G);
            v0 = static_cast<int>(total_v * wsum(slot) / wg);
            v1 = static_cast<int>(total_v * wsum(slot + 1) / wg);
        } else {
            v0 = static_cast<int>(total_v * split / G);
            v1 = static_cast<int>(total_v * (split + 1) / G);
        }
        keys_all = offs[B] - B * SEGK;
         
        {
            int first = B;
            int last = -1;
            for (int bb = tid; bb < B; bb += blockDim.x) {
                const int a = offs[bb];
                const int e = offs[bb + 1] - SEGK;
                if (e > v0 && a < v1) {
                    first = min(first, bb);
                    last = max(last, bb);
                }
            }
            first = __reduce_min_sync(0xffffffffu, first);
            last = __reduce_max_sync(0xffffffffu, last);
            if (lane == 0) {
                atomicMin(flag + 1, first);
                atomicMax(flag + 2, last);
            }
        }
        __syncthreads();
        b_first = flag[1];
        b_last = flag[2];
        if constexpr (STAMPS) {
            if (tid == 0) {
                srec(1, snow());
            }
        }
    }

     
    if constexpr (PROD) {
        if (tid >= NC) {
            if constexpr (!SOLO) {
                setmaxnreg_dec<one_prod_regs(L)>();
            }
             
             
             
             
            const int ptid = tid - NC;
            const int ch = ptid & 7;
            const int r0 = ptid >> 3;
            int pst = 0;
            uint32_t pph = 0;
            auto entry = [&](int tile, int r) -> int {
                const int pos = lo + tile * BN + r;
                if (tile >= ntiles || pos >= seq) {
                    return 0;
                }
                if constexpr (DIET) {
                    return __ldg(pt + (pos >> p.lp));
                }
                return __ldg(pt + (psize == 1 ? pos : pos / psize));
            };
            constexpr uint32_t CPB = ONE_PROBE == 1 || ONE_PROBE == 3 ? 0u : 16u;
            const bool fast32 = ONE_PFAST && p.off32 != 0;
            long long s_emw = 0;
            const long long s_p0 = STAMPS ? clock64() : 0;
            if constexpr (PBULK) {
                 
                 
                 
                 
                 
                 
                constexpr int PBD = 3;
                static_assert(PBD < PB_SLOTS, "a window is refilled after its last read");
                const long long pt_total = static_cast<long long>(p.n_splits) * p.pt_stride;
                const bool pt_al = (reinterpret_cast<uintptr_t>(p.page_table) & 15u) == 0;
                uint32_t pbits = 0;
                uint32_t fbits = 0;
                int g = 0;
                for (int bb = b_first; bb <= b_last; ++bb) {
                    if (!seg_bounds(bb)) {
                        continue;
                    }
                    const long long rowbase = static_cast<long long>(bb) * p.pt_stride;
                     
                    auto win = [&](int t, long long& w0, int& bytes) -> bool {
                        const int pos0 = lo + t * BN;
                        const int pend = min(pos0 + BN, seq);
                        if (!pt_al || t >= ntiles || pend <= pos0) {
                            return false;
                        }
                        const long long e0 = rowbase + (pos0 >> p.lp);
                        const long long e1 = rowbase + ((pend - 1) >> p.lp) + 1;
                        w0 = e0 & ~3ll;
                        const long long w1 = (e1 + 3) & ~3ll;
                        bytes = static_cast<int>(w1 - w0) * 4;
                        return w1 <= pt_total;
                    };
                    auto fill = [&](int t, int gt) {
                        long long w0 = 0;
                        int bytes = 0;
                        if (ONE_PBDBG != 2 && ptid == 0 && win(t, w0, bytes)) {
                            const int s = gt % PB_SLOTS;
                            const uint32_t bar = smem_base + S::PBAR + 8 * s;
                            if constexpr (ONE_PBULK == 2) {
                                 
                                 
                                mbar_wait(smem_base + S::PFREE + 8 * s, ((fbits >> s) & 1u) ^ 1u);
                                fbits ^= 1u << s;
                            }
                             
                             
                            fence_proxy_async();
                            mbar_expect_tx(bar, bytes);
                            bulk_g2s(smem_base + S::PSL + s * PB_SLOT_BYTES, p.page_table + w0,
                                     bytes, bar);
                        }
                    };
#pragma unroll 1
                    for (int t = 0; t < PBD; ++t) {
                        fill(t, g + t);
                    }
#pragma unroll 1
                    for (int t = 0; t < ntiles; ++t) {
                        fill(t + PBD, g + t + PBD);
                        const int pos0 = lo + t * BN;
                        int pe[4];
                        long long w0 = 0;
                        int bytes = 0;
                        if (ONE_PBDBG != 2 && win(t, w0, bytes)) {
                            const int s = (g + t) % PB_SLOTS;
                            mbar_wait(smem_base + S::PBAR + 8 * s, (pbits >> s) & 1u);
                            pbits ^= 1u << s;
                            const int* sl =
                                reinterpret_cast<const int*>(smem + S::PSL + s * PB_SLOT_BYTES);
                             
                            const int d = static_cast<int>(rowbase - w0);
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                const int pos = pos0 + r0 + 16 * i;
                                pe[i] = pos < seq ? sl[(pos >> p.lp) + d] : 0;
                            }
                            if constexpr (ONE_PBULK == 2) {
                                mbar_arrive(smem_base + S::PFREE + 8 * s);
                            }
                            if constexpr (ONE_PBDBG == 1) {
#pragma unroll
                                for (int i = 0; i < 4; ++i) {
                                    pe[i] = entry(t, r0 + 16 * i);
                                }
                            }
                        } else {
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                pe[i] = entry(t, r0 + 16 * i);
                            }
                        }
                        const long long s_w0 = STAMPS ? clock64() : 0;
                        mbar_wait(empty0 + 8 * pst, pph ^ 1u);
                        if constexpr (STAMPS) {
                            s_emw += clock64() - s_w0;
                        }
                        const uint32_t kdst = smem_base + S::KV + pst * 2 * TILE_BYTES;
                        const uint32_t vdst = kdst + TILE_BYTES;
                        if (fast32 && pos0 + BN <= seq) {
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                const int r = r0 + 16 * i;
                                const uint32_t row = (static_cast<uint32_t>(pe[i]) << p.lp)
                                                     + (static_cast<uint32_t>(pos0 + r) & (psize - 1));
                                const uint32_t off = (row << 7) + ch * 16;
                                cp_async16(kdst + r * ROWB + k_swz<L>(ch, r) * 16, p.k_cache + off,
                                           CPB);
                                cp_async16(vdst + r * ROWB + v_swz<L>(ch, r) * 16, p.v_cache + off,
                                           CPB);
                            }
                        } else {
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                const int r = r0 + 16 * i;
                                const int pos = pos0 + r;
                                const uint32_t kd = kdst + r * ROWB + k_swz<L>(ch, r) * 16;
                                const uint32_t vd = vdst + r * ROWB + v_swz<L>(ch, r) * 16;
                                if (pos < seq) {
                                    int64_t row = pe[i];
                                    if constexpr (DIET) {
                                        row = (row << p.lp) + (pos & (psize - 1));
                                    } else if (psize != 1) {
                                        row = row * psize + pos % psize;
                                    }
                                    const int64_t off = row * ROWB + ch * 16;
                                    cp_async16(kd, p.k_cache + off, CPB);
                                    cp_async16(vd, p.v_cache + off, CPB);
                                } else if (pos >= hi) {
                                    cp_async16(kd, p.k_cache, 0);
                                    cp_async16(vd, p.v_cache, 0);
                                }
                            }
                        }
                        cp_async_mbar_arrive_noinc(full0 + 8 * pst);
                        if (++pst == NS) {
                            pst = 0;
                            pph ^= 1u;
                        }
                        if constexpr (ONE_PBULK != 2) {
                             
                            named_sync(4, 128);
                        }
                    }
                    g += ntiles;
                }
            } else {
             
             
             
            for (int bb = b_first; bb <= b_last; ++bb) {
                if (!seg_bounds(bb)) {
                    continue;
                }
                int pe[PF][4];
#pragma unroll
                for (int u = 0; u < PF; ++u) {
#pragma unroll
                    for (int i = 0; i < 4; ++i) {
                        pe[u][i] = entry(u, r0 + 16 * i);
                    }
                }
                for (int base = 0; base < ntiles; base += PF) {
#pragma unroll
                    for (int u = 0; u < PF; ++u) {
                        const int t = base + u;
                        if (t >= ntiles) {
                            break;
                        }
                        const long long s_w0 = STAMPS ? clock64() : 0;
                        mbar_wait(empty0 + 8 * pst, pph ^ 1u);
                        if constexpr (STAMPS) {
                            s_emw += clock64() - s_w0;
                        }
                        const int pos0 = lo + t * BN;
                        const uint32_t kdst = smem_base + S::KV + pst * 2 * TILE_BYTES;
                        const uint32_t vdst = kdst + TILE_BYTES;
                        if (fast32 && pos0 + BN <= seq) {
                             
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                const int r = r0 + 16 * i;
                                const uint32_t row = (static_cast<uint32_t>(pe[u][i]) << p.lp)
                                                     + (static_cast<uint32_t>(pos0 + r) & (psize - 1));
                                const uint32_t off = (row << 7) + ch * 16;
                                cp_async16(kdst + r * ROWB + k_swz<L>(ch, r) * 16, p.k_cache + off,
                                           CPB);
                                cp_async16(vdst + r * ROWB + v_swz<L>(ch, r) * 16, p.v_cache + off,
                                           CPB);
                            }
                        } else {
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                const int r = r0 + 16 * i;
                                const int pos = pos0 + r;
                                const uint32_t kd = kdst + r * ROWB + k_swz<L>(ch, r) * 16;
                                const uint32_t vd = vdst + r * ROWB + v_swz<L>(ch, r) * 16;
                                if (pos < seq) {
                                    int64_t row = pe[u][i];
                                    if constexpr (DIET) {
                                        row = (row << p.lp) + (pos & (psize - 1));
                                    } else if (psize != 1) {
                                        row = row * psize + pos % psize;
                                    }
                                    const int64_t off = row * ROWB + ch * 16;
                                    cp_async16(kd, p.k_cache + off, CPB);
                                    cp_async16(vd, p.v_cache + off, CPB);
                                } else if (pos >= hi) {
                                    cp_async16(kd, p.k_cache, 0);
                                    cp_async16(vd, p.v_cache, 0);
                                }
                            }
                        }
                        cp_async_mbar_arrive_noinc(full0 + 8 * pst);
                        const int tn = t + PF;
                        if (PE16 && fast32 && p.lp == 0 && tn < ntiles
                            && lo + tn * BN + BN <= seq) {
                            const int* q = pt + static_cast<uint32_t>(lo + tn * BN + r0);
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                pe[u][i] = __ldg(q + 16 * i);
                            }
                        } else if (fast32 && tn < ntiles && lo + tn * BN + BN <= seq) {
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                pe[u][i] = __ldg(pt + ((lo + tn * BN + r0 + 16 * i) >> p.lp));
                            }
                        } else {
#pragma unroll
                            for (int i = 0; i < 4; ++i) {
                                pe[u][i] = entry(tn, r0 + 16 * i);
                            }
                        }
                        if (++pst == NS) {
                            pst = 0;
                            pph ^= 1u;
                        }
                    }
                }
            }
            }
             
             
#pragma unroll
            for (int s = 0; s < NS; ++s) {
                mbar_wait(empty0 + 8 * pst, pph ^ 1u);
                if (++pst == NS) {
                    pst = 0;
                    pph ^= 1u;
                }
            }
            if constexpr (STAMPS) {
                if (ptid == 0) {
                    srec(11, s_emw);
                    srec(12, clock64() - s_p0);
                }
            }
             
             
             
             
             
             
             
            asm volatile("exit;\n" ::: "memory");
        }
        if constexpr (!SOLO) {
            setmaxnreg_inc<one_cons_regs(L)>();
        }
    }

     
    auto issue_idx = [&](int tile) {
        if constexpr (DIET) {
             
             
            if (tid < BN && tile < ntiles) {
                const int pos = lo + tile * BN + tid;
                const bool ok = pos < seq;
                cp_async4(smem_base + S::IDX + (tile & (NIDX - 1)) * 256 + tid * 4,
                          pt + (ok ? pos >> p.lp : 0), ok ? 4 : 0);
            }
            return;
        }
        if (tid < BN) {
            const int pos = lo + tile * BN + tid;
            const bool ok = tile < ntiles && pos < seq;
            int e = pos;
            if (psize != 1) {
                e = pos / psize;
            }
            cp_async4(smem_base + S::IDX + (tile & (NIDX - 1)) * 256 + tid * 4, pt + (ok ? e : 0),
                      ok ? 4 : 0);
        }
    };
     
     
     
     
    const int ch = tid & 7;
    const int r0 = tid >> 3;
    constexpr int RSTEP = NC / 8;
    auto issue_kv = [&](int tile, int st, bool patch) {
        const int* idx = idx_ring + (tile & (NIDX - 1)) * BN;
        const int pos0 = lo + tile * BN;
        const uint32_t kdst = smem_base + S::KV + st * 2 * TILE_BYTES;
        const uint32_t vdst = kdst + TILE_BYTES;
        if constexpr (DIET) {
            if (!patch) {
                 
                 
#pragma unroll
                for (int i = 0; i < BN / RSTEP; ++i) {
                    const int r = r0 + i * RSTEP;
                    const int pos = pos0 + r;
                    const bool cached = pos < seq;
                    const int64_t row = cached ? (static_cast<int64_t>(idx[r]) << p.lp)
                                                     + (pos & (psize - 1))
                                               : 0;
                    const int64_t off = row * ROWB + ch * 16;
                    const bool doit = cached || pos >= hi;
                    const uint32_t bytes = cached ? 16u : 0u;
                    cp_async16_if(kdst + r * ROWB + k_swz<L>(ch, r) * 16, p.k_cache + off, bytes,
                                  doit);
                    cp_async16_if(vdst + r * ROWB + v_swz<L>(ch, r) * 16, p.v_cache + off, bytes,
                                  doit);
                }
                return;
            }
            if constexpr ((PRQ & 4) != 0) {
                if (p.off32 && pos0 + BN <= seq) {
#pragma unroll
                    for (int i = 0; i < BN / RSTEP; ++i) {
                        const int r = r0 + i * RSTEP;
                        const uint32_t row = (static_cast<uint32_t>(idx[r]) << p.lp)
                                             + (static_cast<uint32_t>(pos0 + r) & (psize - 1));
                        const uint32_t off = (row << 7) + ch * 16;
                        cp_async16(kdst + r * ROWB + k_swz<L>(ch, r) * 16, p.k_cache + off, 16);
                        cp_async16(vdst + r * ROWB + v_swz<L>(ch, r) * 16, p.v_cache + off, 16);
                    }
                    return;
                }
            }
            if (ONE_KVFAST && pos0 + BN <= seq) {
#pragma unroll
                for (int i = 0; i < BN / RSTEP; ++i) {
                    const int r = r0 + i * RSTEP;
                    const int64_t row = (static_cast<int64_t>(idx[r]) << p.lp)
                                        + ((pos0 + r) & (psize - 1));
                    const int64_t off = row * ROWB + ch * 16;
                    cp_async16(kdst + r * ROWB + k_swz<L>(ch, r) * 16, p.k_cache + off, 16);
                    cp_async16(vdst + r * ROWB + v_swz<L>(ch, r) * 16, p.v_cache + off, 16);
                }
                return;
            }
        }
#pragma unroll
        for (int i = 0; i < BN / RSTEP; ++i) {
            const int r = r0 + i * RSTEP;
            const int pos = pos0 + r;
            const uint32_t kd = kdst + r * ROWB + k_swz<L>(ch, r) * 16;
            const uint32_t vd = vdst + r * ROWB + v_swz<L>(ch, r) * 16;
            if (pos < seq) {
                int64_t row = idx[r];
                if constexpr (DIET) {
                    row = (row << p.lp) + (pos & (psize - 1));
                } else if (psize != 1) {
                    row = row * psize + pos % psize;
                }
                const int64_t off = row * ROWB + ch * 16;
                cp_async16(kd, p.k_cache + off, 16);
                cp_async16(vd, p.v_cache + off, 16);
            } else if (pos < hi) {
                if (patch) {
                    const int j = pos - seq;
                    *reinterpret_cast<uint4*>(smem + (kd - smem_base)) =
                        *reinterpret_cast<const uint4*>(smem + S::KN + j * ROWB + ch * 16);
                    *reinterpret_cast<uint4*>(smem + (vd - smem_base)) =
                        *reinterpret_cast<const uint4*>(smem + S::VN + j * ROWB + ch * 16);
                }
            } else {
                cp_async16(kd, p.k_cache, 0);
                cp_async16(vd, p.v_cache, 0);
            }
        }
    };
     
     
    auto patch_tile = [&](int st, int pos0) {
        if (tid < L * 16) {
            const int j = tid >> 4;
            const int cc = tid & 15;
            const int pos = seq + j;
            if (pos >= max(lo, pos0) && pos < min(hi, pos0 + BN)) {
                const int r = pos - pos0;
                const bool is_v = cc >= 8;
                const int c8 = cc & 7;
                const int sw = is_v ? v_swz<L>(c8, r) : k_swz<L>(c8, r);
                *reinterpret_cast<uint4*>(smem + S::KV + st * 2 * TILE_BYTES
                                          + (is_v ? TILE_BYTES : 0) + r * ROWB + sw * 16) =
                    *reinterpret_cast<const uint4*>(smem + (is_v ? S::VN : S::KN) + j * ROWB
                                                    + c8 * 16);
            }
        }
    };
    auto load8 = [&](const uint8_t* src, float (&x)[8]) {
        const uint4 w = *reinterpret_cast<const uint4*>(src);
        const uint32_t ws[4] = {w.x, w.y, w.z, w.w};
#pragma unroll
        for (int e = 0; e < 4; ++e) {
            const float2 f = __bfloat1622float2(*reinterpret_cast<const __nv_bfloat162*>(&ws[e]));
            x[2 * e] = f.x;
            x[2 * e + 1] = f.y;
        }
    };
    float* rope_cos = reinterpret_cast<float*>(smem + S::ROPE);
    float* rope_sin = rope_cos + L * 32;
    auto rope8 = [&](float (&x)[8], int j, int t8) {
#pragma unroll
        for (int i = 0; i < 4; ++i) {
            const float cs = rope_cos[j * 32 + 4 * t8 + i];
            const float sn = rope_sin[j * 32 + 4 * t8 + i];
            const float a = x[2 * i];
            const float bb = x[2 * i + 1];
            x[2 * i] = a * cs - bb * sn;
            x[2 * i + 1] = a * sn + bb * cs;
        }
    };

    float k_scale = 0.f;
    float v_scale = 0.f;
     
    int cst = 0;
    uint32_t cph = 0;

     
     
    auto run_segment = [&]() -> bool {
        if constexpr (STAMPS) {
            s_seg0 = clock64();
        }
        if constexpr (FLAT) {
             
            cp_wait<0>();
            csync();
        }
        if constexpr (!PROD) {
             
#pragma unroll
            for (int t = 0; t < STAGES - 1; ++t) {
                issue_idx(t);
            }
            cp_commit();
        }
        stamp(1);
        PHASE_EXIT(1)
         
         
         
        asm volatile("griddepcontrol.wait;" ::: "memory");
         
         
        {
            const __nv_bfloat16* qbase = p.qkv + static_cast<size_t>(b) * L * QKV_STRIDE;
            if constexpr (DIET) {
                static_assert(ROWS * 8 % NC == 0, "whole passes of the consumer threads");
#pragma unroll
                for (int k = 0; k < ROWS * 8 / NC; ++k) {
                    const int i = tid + k * NC;
                    const int row = i >> 3;
                    const int cc = i & 7;
                    cp_async16(smem_base + S::QST + row * 128 + cc * 16,
                               qbase + (row >> 4) * QKV_STRIDE + (row & 15) * D + cc * 8, 16);
                }
            } else {
                for (int i = tid; i < ROWS * 8; i += NC) {
                    const int row = i >> 3;
                    const int cc = i & 7;
                    cp_async16(smem_base + S::QST + row * 128 + cc * 16,
                               qbase + (row >> 4) * QKV_STRIDE + (row & 15) * D + cc * 8, 16);
                }
            }
            const bool has_new = hi > seq || SPEC;
            if (has_new && tid < L * 32) {
                const int rr = tid >> 3;
                const int cc = tid & 7;
                cp_async16(smem_base + S::KVST + rr * 128 + cc * 16,
                           qbase + (rr >> 2) * QKV_STRIDE + (HQ + (rr & 3)) * D + cc * 8, 16);
            }
            if (tid < 8) {
                cp_async16(smem_base + S::CONST + C_INVF + tid * 16, p.inv_freq + tid * 4, 16);
            } else if (tid == 8) {
                cp_async4(smem_base + S::CONST + C_KS, p.k_scale, 4);
            } else if (tid == 9) {
                cp_async4(smem_base + S::CONST + C_VS, p.v_scale, 4);
            } else if (tid == 10) {
                cp_async4(smem_base + S::CONST + C_EPOCH, p.ws_cnt + CNT_EPOCH + b,
                          COOP && !FLAT ? 4 : 0);
            } else if (tid >= 16 && tid < 16 + L) {
                cp_async8(smem_base + S::CONST + C_LOC + (tid - 16) * 8,
                          p.cache_loc + static_cast<size_t>(b) * L + (tid - 16), 8);
            }
            if ((FLAT ? lo == 0 : split == 0) && tid < ROWS) {
                prefetch_l2(qbase + (tid >> 4) * QKV_STRIDE + GATE_OFF + (tid & 15) * D);
            }
        }
        cp_commit();
        stamp(2);
        PHASE_EXIT(2)

        if constexpr (!PROD) {
            cp_wait<1>();
            stamp(3);
            csync();
            stamp(4);
            PHASE_EXIT(3)
            if constexpr (SPEC) {
                if (seq_real != seq) {
                    cp_wait<0>();
                    __syncthreads();
                    seq = seq_real;
                    derive();
#pragma unroll
                    for (int t = 0; t < STAGES - 1; ++t) {
                        issue_idx(t);
                    }
                    cp_commit();
                    cp_wait<0>();
                    __syncthreads();
                }
                if (lo >= end) {
                    cp_wait<0>();
                    return false;
                }
            }
            stamp(5);
            PHASE_EXIT(4)
             
             
#pragma unroll
            for (int t = 0; t < STAGES - 1; ++t) {
                if (t < ntiles) {
                    issue_kv(t, t, false);
                    issue_idx(t + STAGES - 1);
                }
                cp_commit();
            }
            stamp(6);
            cp_wait<STAGES - 1>();
        } else {
            cp_wait<0>();
        }
        stamp(7);
        csync();
        stamp(8);
        PHASE_EXIT(5)

        k_scale = *reinterpret_cast<const float*>(smem + S::CONST + C_KS);
        v_scale = *reinterpret_cast<const float*>(smem + S::CONST + C_VS);
        const float* invf = reinterpret_cast<const float*>(smem + S::CONST + C_INVF);
        if (p.rope) {
            if (tid < L * 32) {
                const float2 sc =
                    fast_sincos(static_cast<float>(seq + (tid >> 5)) * invf[tid & 31]);
                rope_sin[tid] = sc.x;
                rope_cos[tid] = sc.y;
            }
            csync();
        }
        stamp(9);
        PHASE_EXIT(6)

         
         
         
        auto q_piece = [&](int piece) {
            const int row = piece >> 3;
            const int t8 = piece & 7;
            const int j = row >> 4;
            const int head = row & 15;
            float x[8];
            load8(smem + S::QST + row * 128 + t8 * 16, x);
            float ss = 0.f;
#pragma unroll
            for (int e = 0; e < 8; ++e) {
                ss += x[e] * x[e];
            }
            const float r = rsqrtf(oct_sum(ss) * (1.f / D) + EPS);
#pragma unroll
            for (int e = 0; e < 8; ++e) {
                x[e] *= r;
            }
            if (p.rope) {
                rope8(x, j, t8);
            }
            if constexpr (L == 1) {
                uint32_t w[4];
#pragma unroll
                for (int e = 0; e < 4; ++e) {
                    w[e] = pack_f16(x[2 * e] * p.sl2, x[2 * e + 1] * p.sl2);
                }
                *reinterpret_cast<uint4*>(smem + S::Q + head * 128 + t8 * 16) =
                    make_uint4(w[0], w[1], w[2], w[3]);
            } else {
                const int r64 = j * 8 + (head & 7);
                *reinterpret_cast<uint2*>(smem + S::Q + (head >> 3) * 4096 + kmaj(r64, t8 >> 1)
                                          + (t8 & 1) * 8) =
                    make_uint2(e4m3x4(x[0], x[1], x[2], x[3]), e4m3x4(x[4], x[5], x[6], x[7]));
            }
        };
        if constexpr (DIET) {
#pragma unroll
            for (int k = 0; k < ROWS * 8 / NC; ++k) {
                q_piece(tid + k * NC);
            }
        } else {
            for (int piece = tid; piece < ROWS * 8; piece += NC) {
                q_piece(piece);
            }
        }

        stamp(10);
        PHASE_EXIT(7)
         
         
        if (hi > seq && tid < L * 32) {
            const int rr = tid >> 3;
            const int t8 = tid & 7;
            const int j = rr >> 2;
            const bool is_k = (rr & 3) < 2;
            const int hh = rr & 1;
            float x[8];
            load8(smem + S::KVST + rr * 128 + t8 * 16, x);
            float inv = __fdividef(1.f, v_scale);
             
             
             
            float ss = 0.f;
#pragma unroll
            for (int e = 0; e < 8; ++e) {
                ss += x[e] * x[e];
            }
            ss = oct_sum(ss);
            if (is_k) {
                const float r = rsqrtf(ss * (1.f / D) + EPS);
#pragma unroll
                for (int e = 0; e < 8; ++e) {
                    x[e] *= r;
                }
                if (p.rope) {
                    rope8(x, j, t8);
                }
                inv = __fdividef(1.f, k_scale);
            }
            const uint2 v8 = make_uint2(e4m3x4(x[0] * inv, x[1] * inv, x[2] * inv, x[3] * inv),
                                        e4m3x4(x[4] * inv, x[5] * inv, x[6] * inv, x[7] * inv));
            const int pos = seq + j;
            if (pos >= lo && pos < hi) {
                const int64_t loc =
                    *reinterpret_cast<const int64_t*>(smem + S::CONST + C_LOC + j * 8);
                uint8_t* dst = (is_k ? p.k_cache : p.v_cache) + loc * ROWB + hh * D + t8 * 8;
                *reinterpret_cast<uint2*>(dst) = v8;
            }
            *reinterpret_cast<uint2*>(smem + (is_k ? S::KN : S::VN) + j * ROWB + hh * D + t8 * 8) =
                v8;
        }
        stamp(11);
        csync();
        stamp(12);
        PHASE_EXIT(8)
        if constexpr (!PROD) {
             
            if (hi > seq) {
#pragma unroll
                for (int t = 0; t < STAGES - 1; ++t) {
                    if (t < ntiles) {
                        patch_tile(t, lo + t * BN);
                    }
                }
            }
        }
        if constexpr (L == 8) {
             
             
            if (tid < 128) {
                *reinterpret_cast<uint4*>(smem + S::VT + (tid >> 5) * VT_STRIDE + 64 * 64
                                          + (tid & 31) * 16) =
                    make_uint4(0x38383838u, 0x38383838u, 0x38383838u, 0x38383838u);
            }
        }

        stamp(13);
        PHASE_EXIT(9)
        const float sl2k = (L == 1 ? 1.f : p.sl2) * k_scale;
        const int copy = p.nc > 1 ? split % p.nc : 0;

         
         
         
         
        auto acquire = [&](int it, int st, bool common = false) {
            if constexpr (PROD) {
                const long long s_w0 = STAMPS ? clock64() : 0;
                mbar_wait(full0 + 8 * st, cph);
                if constexpr (STAMPS) {
                    const long long now = clock64();
                    s_fullw += now - s_w0;
                    if (it == 0) {
                        s_pro += now - s_seg0;
                        s_l0 = now;
                        if (s_nseg == 0 && tid == 0) {
                            srec(2, snow());
                        }
                    }
                }
                if constexpr (L == 8 && ONE_PROBE != 2) {
                    fence_proxy_async();
                }
                const int pos0 = lo + it * BN;
                if (common) {
                    if (it == 0) {
                        csync();
                    }
                } else if (hi > seq && pos0 + BN > seq) {
                    patch_tile(st, pos0);
                    if constexpr (L == 8) {
                        fence_proxy_async();
                    }
                    csync();
                } else if (it == 0) {
                    csync();
                }
            } else {
                cp_wait<STAGES - 2>();
                if constexpr (L == 8) {
                    fence_proxy_async();
                }
                if (it == 0) {
                    stamp(14);
                }
                __syncthreads();
                if (it == 0) {
                    stamp(15);
                }
                if constexpr (!ONE) {
                    if (it + STAGES - 1 < ntiles) {
                        issue_kv(it + STAGES - 1, (st + STAGES - 1) % STAGES, true);
                        issue_idx(it + 2 * STAGES - 2);
                    }
                    cp_commit();
                }
            }
        };
        auto release = [&](int st) {
            if constexpr (PROD) {
                mbar_arrive(empty0 + 8 * st);
                if (++cst == NS) {
                    cst = 0;
                    cph ^= 1u;
                }
            }
        };

        if constexpr (L == 1) {
             
             
            const int hk = warp & 1;
            const int wsub = warp >> 1;
            uint32_t qf[8];
            {
                const uint4* qp =
                    reinterpret_cast<const uint4*>(smem + S::Q + (hk * 8 + g) * 128 + c * 32);
                const uint4 a = qp[0];
                const uint4 bq = qp[1];
                qf[0] = a.x;
                qf[1] = a.y;
                qf[2] = a.z;
                qf[3] = a.w;
                qf[4] = bq.x;
                qf[5] = bq.y;
                qf[6] = bq.z;
                qf[7] = bq.w;
            }
            float o[8][4];
#pragma unroll
            for (int e = 0; e < 8; ++e) {
                o[e][0] = o[e][1] = o[e][2] = o[e][3] = 0.f;
            }
            float m = NEG_INF;
            float l = 0.f;
            int st = PROD ? cst : 0;
            for (int it = 0; it < ntiles; ++it) {
                acquire(it, st);
                if constexpr (ONE_PROBE == 3 && PROD) {
                    release(st);
                    st = cst;
                    continue;
                }
                const uint8_t* ks = smem + S::KV + st * 2 * TILE_BYTES;
                const uint8_t* vs = ks + TILE_BYTES;
                const int pos0 = lo + it * BN;
                const bool interior =
                    pos0 + BN - 1 <= seq && (!p.window || pos0 >= seq + L - p.window);
                float s[4][4];
#pragma unroll
                for (int kb = 0; kb < 4; ++kb) {
                    const int key = wsub * 32 + kb * 8 + g;
                    const uint4 kw = *reinterpret_cast<const uint4*>(
                        ks + key * ROWB + k_swz<1>(hk * 4 + c, key) * 16);
                    const uint32_t kwv[4] = {kw.x, kw.y, kw.z, kw.w};
                    uint32_t kf[8];
#pragma unroll
                    for (int e = 0; e < 4; ++e) {
                        kf[2 * e] = f16x2_from_e4m3x2(kwv[e] & 0xffffu);
                        kf[2 * e + 1] = f16x2_from_e4m3x2(kwv[e] >> 16);
                    }
                    s[kb][0] = s[kb][1] = s[kb][2] = s[kb][3] = 0.f;
                    if constexpr (QK2) {
                        float so[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
                        for (int j2 = 0; j2 < 4; j2 += 2) {
                            mma_f16(s[kb], qf[2 * j2], 0u, qf[2 * j2 + 1], 0u, kf[2 * j2],
                                    kf[2 * j2 + 1]);
                            mma_f16(so, qf[2 * j2 + 2], 0u, qf[2 * j2 + 3], 0u, kf[2 * j2 + 2],
                                    kf[2 * j2 + 3]);
                        }
                        s[kb][0] += so[0];
                        s[kb][1] += so[1];
                    } else {
#pragma unroll
                        for (int j2 = 0; j2 < 4; ++j2) {
                            mma_f16(s[kb], qf[2 * j2], 0u, qf[2 * j2 + 1], 0u, kf[2 * j2],
                                    kf[2 * j2 + 1]);
                        }
                    }
                }
                float mx = NEG_INF;
#pragma unroll
                for (int kb = 0; kb < 4; ++kb) {
#pragma unroll
                    for (int e = 0; e < 2; ++e) {
                        if (!interior) {
                            const int pos = pos0 + wsub * 32 + kb * 8 + 2 * c + e;
                            if (pos > seq || (p.window && pos < seq - p.window + 1)) {
                                s[kb][e] = NEG_INF;
                            }
                        }
                        mx = fmaxf(mx, s[kb][e]);
                    }
                }
                mx = quad_max(mx) * sl2k;
                const float mu = fmaxf(ONE ? mx : fmaxf(m, mx), OFF_FLOOR);
                float alpha = 1.f;
                if constexpr (!ONE) {
                    alpha = ex2(m - mu);
                }
                m = mu;
                float sum = 0.f;
#pragma unroll
                for (int kb = 0; kb < 4; ++kb) {
#pragma unroll
                    for (int e = 0; e < 2; ++e) {
                        s[kb][e] = ex2(fmaf(s[kb][e], sl2k, -mu));
                        sum += s[kb][e];
                    }
                }
                l = l * alpha + sum;
                if constexpr (!ONE) {
                    if (__any_sync(0xffffffffu, alpha != 1.f)) {
#pragma unroll
                        for (int e = 0; e < 8; ++e) {
                            o[e][0] *= alpha;
                            o[e][1] *= alpha;
                        }
                    }
                }
                 
                 
#pragma unroll
                for (int kk = 0; kk < 2; ++kk) {
                    const uint32_t a0 = pack_f16(s[2 * kk][0], s[2 * kk][1]);
                    const uint32_t a2 = pack_f16(s[2 * kk + 1][0], s[2 * kk + 1][1]);
                    uint2 vt[4];
#pragma unroll
                    for (int k = 0; k < 4; ++k) {
                        const int key = wsub * 32 + kk * 16 + 2 * c + (k & 1) + (k >> 1) * 8;
                        vt[k] = *reinterpret_cast<const uint2*>(
                            vs + key * ROWB + v_swz<1>(hk * 4 + (g >> 1), key) * 16 + (g & 1) * 8);
                    }
#pragma unroll
                    for (int hw = 0; hw < 2; ++hw) {
                        const uint32_t x0 = hw ? vt[0].y : vt[0].x;
                        const uint32_t x1 = hw ? vt[1].y : vt[1].x;
                        const uint32_t x2 = hw ? vt[2].y : vt[2].x;
                        const uint32_t x3 = hw ? vt[3].y : vt[3].x;
#pragma unroll
                        for (int pr = 0; pr < 2; ++pr) {
                            const uint32_t sel = pr ? 0x7362u : 0x5140u;
                            const uint32_t w01 = __byte_perm(x0, x1, sel);
                            const uint32_t w23 = __byte_perm(x2, x3, sel);
#pragma unroll
                            for (int q = 0; q < 2; ++q) {
                                const int e = hw * 4 + pr * 2 + q;
                                const uint32_t b0 =
                                    f16x2_from_e4m3x2(q ? w01 >> 16 : w01 & 0xffffu);
                                const uint32_t b1 =
                                    f16x2_from_e4m3x2(q ? w23 >> 16 : w23 & 0xffffu);
                                mma_f16(o[e], a0, 0u, a2, 0u, b0, b1);
                            }
                        }
                    }
                }
                release(st);
                st = PROD ? cst : (st == STAGES - 1 ? 0 : st + 1);
            }
            if constexpr (STAMPS) {
                s_loop += clock64() - s_l0;
                s_tiles += ntiles;
                ++s_nseg;
                if (tid == 0) {
                    srec(3, snow());
                    srec(13, clock64() - s_k0);
                }
            }
            stamp(16);
            PHASE_EXIT(10)
             
             
             
            const float f = ex2(fminf(m, 126.f));
#if ONE_DETM
            if constexpr (DETM) {
                float* slot = reinterpret_cast<float*>(p.dbg)
                              + det_slot(b, G, split, wsub, hk * 8 + g);
                st_cg_f4(slot + c * 16, make_float4(o[0][0] * f, o[1][0] * f, o[2][0] * f,
                                                    o[3][0] * f));
                st_cg_f4(slot + c * 16 + 4, make_float4(o[4][0] * f, o[5][0] * f, o[6][0] * f,
                                                        o[7][0] * f));
                st_cg_f4(slot + c * 16 + 8, make_float4(o[0][1] * f, o[1][1] * f, o[2][1] * f,
                                                        o[3][1] * f));
                st_cg_f4(slot + c * 16 + 12, make_float4(o[4][1] * f, o[5][1] * f, o[6][1] * f,
                                                         o[7][1] * f));
                const float lq = quad_sum(l);
                if (c == 0) {
                    __stcg(slot + 64, lq * f);
                }
            } else
#endif
            if constexpr (HMRG) {
                 
                 
                 
                 
                 
                const float lq = quad_sum(l) * f;
                cp_wait<0>();
                csync();
                static_assert(!FLAT || S::Q + 17 * 64 * 4 <= S::KN, "flat handoff bytes");
                float* xs = reinterpret_cast<float*>(smem + (FLAT ? S::Q : S::KV)) + hk * 32
                            + lane;
                if (wsub == 1) {
#pragma unroll
                    for (int e = 0; e < 8; ++e) {
                        xs[(2 * e) * 64] = o[e][0] * f;
                        xs[(2 * e + 1) * 64] = o[e][1] * f;
                    }
                    xs[16 * 64] = lq;
                }
                csync();
                if (wsub == 0) {
                    float a[16];
#pragma unroll
                    for (int e = 0; e < 8; ++e) {
                        a[2 * e] = o[e][0] * f + xs[(2 * e) * 64];
                        a[2 * e + 1] = o[e][1] * f + xs[(2 * e + 1) * 64];
                    }
                    const float la = lq + xs[16 * 64];
                    const int row = ws_row(b, p.nc, copy, 1, 0, hk * 8 + g);
                    float* dst = p.ws_acc + static_cast<size_t>(row) * D + c * 16;
                    red_add_v4(dst, a[0], a[2], a[4], a[6]);
                    red_add_v4(dst + 4, a[8], a[10], a[12], a[14]);
                    red_add_v4(dst + 8, a[1], a[3], a[5], a[7]);
                    red_add_v4(dst + 12, a[9], a[11], a[13], a[15]);
                    if (c == 0) {
                        red_add_f32(p.ws_l + row, la);
                    }
                }
            } else {
                const int row = ws_row(b, p.nc, copy, 1, 0, hk * 8 + g);
                float* dst = p.ws_acc + static_cast<size_t>(row) * D + c * 16;
                red_add_v4(dst, o[0][0] * f, o[1][0] * f, o[2][0] * f, o[3][0] * f);
                red_add_v4(dst + 4, o[4][0] * f, o[5][0] * f, o[6][0] * f, o[7][0] * f);
                red_add_v4(dst + 8, o[0][1] * f, o[1][1] * f, o[2][1] * f, o[3][1] * f);
                red_add_v4(dst + 12, o[4][1] * f, o[5][1] * f, o[6][1] * f, o[7][1] * f);
                const float lq = quad_sum(l);
                if (c == 0) {
                    red_add_f32(p.ws_l + row, lq * f);
                }
            }
        } else {
             
             
             
            const int hk = warp >> 2;
            const int wq = warp & 3;
            uint64_t qd0 = desc_kmaj(smem_base + S::Q + hk * 4096, 128, 512);
            uint64_t qd1 = desc_kmaj(smem_base + S::Q + hk * 4096 + 256, 128, 512);
            uint32_t klo0 = 0;
            int it_c = 0;
            if constexpr (DCARRY) {
                qd0 = (qd0 & ~0xffffffffull)
                      | __shfl_sync(0xffffffffu, static_cast<uint32_t>(qd0), 0);
                qd1 = (qd1 & ~0xffffffffull)
                      | __shfl_sync(0xffffffffu, static_cast<uint32_t>(qd1), 0);
                klo0 = __shfl_sync(0xffffffffu,
                                   static_cast<uint32_t>(desc_sw128(smem_base + S::KV + hk * 64)),
                                   0);
                 
                 
                it_c = __shfl_sync(0xffffffffu, !p.window && seq > lo ? (seq - lo) >> 6 : 0, 0);
            }
            uint32_t vt_cur = 0;
            uint32_t vt_x = 0;
            uint32_t vd_lo = 0;
            uint32_t vd_x = 0;
            uint32_t ld_off = 0;
            uint32_t st_off = 0;
            if constexpr (VHOIST) {
                const uint32_t vt0 = smem_base + S::VT + hk * VT_STRIDE;
                const uint32_t vt1 = smem_base + S::VT + (2 + hk) * VT_STRIDE;
                vt_cur = __shfl_sync(0xffffffffu, vt0, 0);
                vt_x = __shfl_sync(0xffffffffu, vt0 ^ vt1, 0);
                vd_lo = __shfl_sync(0xffffffffu, static_cast<uint32_t>(desc_sw64(vt0)), 0);
                vd_x = vd_lo ^ __shfl_sync(0xffffffffu, static_cast<uint32_t>(desc_sw64(vt1)), 0);
                const int h4 = lane >> 3;
                const int r8 = lane & 7;
                ld_off = smem_base + S::KV + TILE_BYTES + (h4 * 8 + r8) * ROWB
                         + (((hk * 4 + wq) ^ r8) << 4);
                const int n = 8 * (2 * wq + (h4 & 1)) + r8;
                st_off = n * 64 + (((h4 >> 1) ^ ((n >> 1) & 3)) << 4);
                 
                 
                asm volatile("" : "+r"(ld_off), "+r"(st_off));
            }
            float o[36];
#pragma unroll
            for (int i = 0; i < 36; ++i) {
                o[i] = 0.f;
            }
            float off[2] = {OFF_FLOOR, OFF_FLOOR};
            const int qp0 = seq + 2 * wq;
            if constexpr (XPIPE != 0) {
                 
                 
                 
                 
                 
                 
                float s[32];
                uint32_t pa[2][4];
                int st = cst;
                auto qk_issue = [&]() {
                    const uint64_t kd =
                        (desc_sw128(0) & ~0xffffffffull)
                        | (klo0 + static_cast<uint32_t>(st) * (2 * TILE_BYTES >> 4));
                    wg_fence();
                    wgmma_qk<0>(s, qd0, kd);
                    wgmma_qk<1>(s, qd1, kd + 2);
                    wg_commit();
                };
                 
                auto transpose_v = [&](uint32_t vt) {
#pragma unroll
                    for (int half = 0; half < 2; ++half) {
                        uint32_t t0, t1, t2, t3;
                        ldsm_x4_trans(ld_off + static_cast<uint32_t>(st) * (2 * TILE_BYTES)
                                          + half * 32 * ROWB,
                                      t0, t1, t2, t3);
                        stsm_x4(vt + (st_off ^ (half ? 32u : 0u)), __byte_perm(t0, t1, 0x6420),
                                __byte_perm(t0, t1, 0x7531), __byte_perm(t2, t3, 0x6420),
                                __byte_perm(t2, t3, 0x7531));
                    }
                };
                auto pv_issue = [&]() {
                    fence_proxy_async();
                    named_sync(2 + hk, 128);
                    const uint64_t vd = (desc_sw64(0) & ~0xffffffffull) | vd_lo;
                    wg_fence();
                    wgmma_pv(o, pa[0], vd);
                    wgmma_pv(o, pa[1], vd + 2);
                    wg_commit();
                };
                 
                 
                 
                auto offset_to_max = [&]() {
                    if constexpr (XPIPE == 1) {
                        wg_wait<0>();
                        reg_fence(o);
                    }
                    float tmax[2];
                    bool move[2];
#pragma unroll
                    for (int hh = 0; hh < 2; ++hh) {
                        float mx = fmaxf(s[2 * hh], s[2 * hh + 1]);
#pragma unroll
                        for (int i = 1; i < 8; ++i) {
                            mx = fmaxf(mx, fmaxf(s[4 * i + 2 * hh], s[4 * i + 2 * hh + 1]));
                        }
                        tmax[hh] = quad_max(mx) * sl2k;
                        move[hh] = tmax[hh] > off[hh] + 8.f;
                    }
                    if (__any_sync(0xffffffffu, move[0] || move[1])) {
#pragma unroll
                        for (int hh = 0; hh < 2; ++hh) {
                            const float nxt = move[hh] ? tmax[hh] : off[hh];
                            const float scale = ex2(off[hh] - nxt);
                            off[hh] = nxt;
#pragma unroll
                            for (int i = 0; i < 9; ++i) {
                                o[4 * i + 2 * hh] *= scale;
                                o[4 * i + 2 * hh + 1] *= scale;
                            }
                        }
                    }
                };
                auto pack = [&]() {
                    auto ex = [&](int j) { return ex2(fmaf(s[j], sl2k, -off[(j >> 1) & 1])); };
#pragma unroll
                    for (int kk = 0; kk < 2; ++kk) {
                        const int b0 = 16 * kk;
                        pa[kk][0] = e4m3x4(ex(b0), ex(b0 + 1), ex(b0 + 4), ex(b0 + 5));
                        pa[kk][1] = e4m3x4(ex(b0 + 2), ex(b0 + 3), ex(b0 + 6), ex(b0 + 7));
                        pa[kk][2] = e4m3x4(ex(b0 + 8), ex(b0 + 9), ex(b0 + 12), ex(b0 + 13));
                        pa[kk][3] = e4m3x4(ex(b0 + 10), ex(b0 + 11), ex(b0 + 14), ex(b0 + 15));
                    }
                };
                 
                 
                auto softmax_tile = [&](int it) {
                    const int pos0 = lo + it * BN;
                    const bool interior =
                        it < it_c
                        || (pos0 + BN - 1 <= seq && (!p.window || pos0 >= seq + L - p.window));
                    if (!interior) {
#pragma unroll
                        for (int i = 0; i < 8; ++i) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                                for (int e = 0; e < 2; ++e) {
                                    const int pos = pos0 + 8 * i + 2 * c + e;
                                    const int qp = qp0 + hh;
                                    if (pos > qp || (p.window && pos < qp - p.window + 1)) {
                                        s[4 * i + 2 * hh + e] = NEG_INF;
                                    }
                                }
                            }
                        }
                    }
                    if (it == 0) {
                        offset_to_max();
                    }
                    pack();
                    if (it != 0) {
                         
                        constexpr uint32_t PB = 0x07070707u;
                        const uint32_t ov =
                            ((pa[0][0] + PB) | (pa[0][1] + PB) | (pa[0][2] + PB) |
                             (pa[0][3] + PB) | (pa[1][0] + PB) | (pa[1][1] + PB) |
                             (pa[1][2] + PB) | (pa[1][3] + PB)) & 0x80808080u;
                        const bool any_ov = XPIPE == 1 ? named_sync_or(2 + hk, 128, ov != 0u)
                                                       : __any_sync(0xffffffffu, ov != 0u);
                        if (any_ov) {
                            offset_to_max();
                            pack();
                        }
                    }
                };
                 
                 
                auto next_qk = [&](int it) {
                    acquire(it, st, it < it_c);
                    qk_issue();
                };
                acquire(0, st, 0 < it_c);
                qk_issue();
                transpose_v(vt_cur);
                wg_wait<0>();
                reg_fence(s);
                release(st);
                st = cst;
#pragma unroll (UNR8)
                for (int it = 0; it < ntiles - 1; ++it) {
                    softmax_tile(it);
                    if constexpr (XPIPE == 1) {
                        next_qk(it + 1);
                         
                         
                        wg_wait<1>();
                        reg_fence(o);
                        pv_issue();
                        transpose_v(vt_cur ^ vt_x);
                        wg_wait<1>();
                    } else {
                        pv_issue();
                        next_qk(it + 1);
                        transpose_v(vt_cur ^ vt_x);
                        wg_wait<0>();
                        reg_fence(o);
                    }
                    reg_fence(s);
                    release(st);
                    st = cst;
                    vt_cur ^= vt_x;
                    vd_lo ^= vd_x;
                }
                softmax_tile(ntiles - 1);
                if constexpr (XPIPE == 1) {
                    wg_wait<0>();
                    reg_fence(o);
                }
                pv_issue();
                wg_wait<0>();
                reg_fence(o);
                vt_cur ^= vt_x;
                vd_lo ^= vd_x;
            } else if constexpr (QKOV || EREL || PCHK || UNR8 > 1) {
                int st = PROD ? cst : 0;
#pragma unroll (UNR8)
                for (int it = 0; it < ntiles; ++it) {
                    const bool common = DCARRY && it < it_c;
                    acquire(it, st, common);
                    const uint8_t* vs = smem + S::KV + st * 2 * TILE_BYTES + TILE_BYTES;
                    const int pos0 = lo + it * BN;
                    const bool interior =
                        common
                        || (pos0 + BN - 1 <= seq && (!p.window || pos0 >= seq + L - p.window));
                     
                     
                     
                     
                     
                    auto vt_of = [&]() { return smem + S::VT + (2 * (it & 1) + hk) * VT_STRIDE; };
                    auto transpose_v = [&]() {
                        if constexpr (VHOIST) {
                             
                             
#pragma unroll
                            for (int half = 0; half < 2; ++half) {
                                uint32_t t0, t1, t2, t3;
                                ldsm_x4_trans(ld_off + static_cast<uint32_t>(st) * (2 * TILE_BYTES)
                                                  + half * 32 * ROWB,
                                              t0, t1, t2, t3);
                                stsm_x4(vt_cur + (st_off ^ (half ? 32u : 0u)),
                                        __byte_perm(t0, t1, 0x6420), __byte_perm(t0, t1, 0x7531),
                                        __byte_perm(t2, t3, 0x6420), __byte_perm(t2, t3, 0x7531));
                            }
                            return;
                        }
                        uint8_t* vt = vt_of();
                        const int h4 = lane >> 3;
                        const int r8 = lane & 7;
#pragma unroll
                        for (int half = 0; half < 2; ++half) {
                            const int key = half * 32 + h4 * 8 + r8;
                            uint32_t t0, t1, t2, t3;
                            ldsm_x4_trans(smem_u32(vs + key * ROWB + ((hk * 4 + wq) ^ r8) * 16), t0,
                                          t1, t2, t3);
                            const uint32_t m0 = __byte_perm(t0, t1, 0x6420);
                            const uint32_t m1 = __byte_perm(t0, t1, 0x7531);
                            const uint32_t m2 = __byte_perm(t2, t3, 0x6420);
                            const uint32_t m3 = __byte_perm(t2, t3, 0x7531);
                            const int n = 8 * (2 * wq + (h4 & 1)) + r8;
                            const int chunk = 2 * half + (h4 >> 1);
                            stsm_x4(smem_u32(vt + n * 64 + ((chunk ^ ((n >> 1) & 3)) << 4)), m0, m1,
                                    m2, m3);
                        }
                    };
                    float s[32];
                    {
                        const uint64_t kd =
                            DCARRY ? (desc_sw128(0) & ~0xffffffffull)
                                         | (klo0 + static_cast<uint32_t>(st) * (2 * TILE_BYTES >> 4))
                                   : desc_sw128(smem_base + S::KV + st * 2 * TILE_BYTES + hk * 64);
                        wg_fence();
                        wgmma_qk<0>(s, qd0, kd);
                        wgmma_qk<1>(s, qd1, kd + 2);
                        wg_commit();
                        if constexpr (QKOV) {
                             
                             
                             
                            transpose_v();
                        }
                        wg_wait<0>();
                        reg_fence(s);
                    }
                    if constexpr (EREL) {
                         
                         
                        release(st);
                    }
                    if (!interior) {
#pragma unroll
                        for (int i = 0; i < 8; ++i) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                                for (int e = 0; e < 2; ++e) {
                                    const int pos = pos0 + 8 * i + 2 * c + e;
                                    const int qp = qp0 + hh;
                                    if (pos > qp || (p.window && pos < qp - p.window + 1)) {
                                        s[4 * i + 2 * hh + e] = NEG_INF;
                                    }
                                }
                            }
                        }
                    }
                     
                     
                    auto offset_to_max = [&]() {
                        float tmax[2];
                        bool move[2];
#pragma unroll
                        for (int hh = 0; hh < 2; ++hh) {
                            float mx = fmaxf(s[2 * hh], s[2 * hh + 1]);
#pragma unroll
                            for (int i = 1; i < 8; ++i) {
                                mx = fmaxf(mx, fmaxf(s[4 * i + 2 * hh], s[4 * i + 2 * hh + 1]));
                            }
                            tmax[hh] = quad_max(mx) * sl2k;
                            move[hh] = tmax[hh] > off[hh] + 8.f;
                        }
                        if (__any_sync(0xffffffffu, move[0] || move[1])) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
                                const float nxt = move[hh] ? tmax[hh] : off[hh];
                                const float scale = ex2(off[hh] - nxt);
                                off[hh] = nxt;
#pragma unroll
                                for (int i = 0; i < 9; ++i) {
                                    o[4 * i + 2 * hh] *= scale;
                                    o[4 * i + 2 * hh + 1] *= scale;
                                }
                            }
                        }
                    };
                     
                     
                     
                     
                    uint32_t pa[2][4];
                    auto pack_exps = [&]() {
#pragma unroll
                        for (int kk = 0; kk < 2; ++kk) {
                            const float* q0 = s + 16 * kk;
                            pa[kk][0] = e4m3x4(q0[0], q0[1], q0[4], q0[5]);
                            pa[kk][1] = e4m3x4(q0[2], q0[3], q0[6], q0[7]);
                            pa[kk][2] = e4m3x4(q0[8], q0[9], q0[12], q0[13]);
                            pa[kk][3] = e4m3x4(q0[10], q0[11], q0[14], q0[15]);
                        }
                    };
                    auto pack = [&]() {
                        auto ex = [&](int j) { return ex2(fmaf(s[j], sl2k, -off[(j >> 1) & 1])); };
#pragma unroll
                        for (int kk = 0; kk < 2; ++kk) {
                            const int b0 = 16 * kk;
                            pa[kk][0] = e4m3x4(ex(b0), ex(b0 + 1), ex(b0 + 4), ex(b0 + 5));
                            pa[kk][1] = e4m3x4(ex(b0 + 2), ex(b0 + 3), ex(b0 + 6), ex(b0 + 7));
                            pa[kk][2] = e4m3x4(ex(b0 + 8), ex(b0 + 9), ex(b0 + 12), ex(b0 + 13));
                            pa[kk][3] = e4m3x4(ex(b0 + 10), ex(b0 + 11), ex(b0 + 14), ex(b0 + 15));
                        }
                    };
                    if constexpr (!PCHK) {
                        offset_to_max();
#pragma unroll
                        for (int i = 0; i < 8; ++i) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                                for (int e = 0; e < 2; ++e) {
                                    s[4 * i + 2 * hh + e] =
                                        ex2(fmaf(s[4 * i + 2 * hh + e], sl2k, -off[hh]));
                                }
                            }
                        }
                        pack_exps();
                    } else {
                        if (it == 0) {
                            offset_to_max();
                        }
                        pack();
                        if (it != 0) {
                             
                             
                             
                            constexpr uint32_t PB = 0x07070707u;
                            const uint32_t ov =
                                ((pa[0][0] + PB) | (pa[0][1] + PB) | (pa[0][2] + PB) |
                                 (pa[0][3] + PB) | (pa[1][0] + PB) | (pa[1][1] + PB) |
                                 (pa[1][2] + PB) | (pa[1][3] + PB)) & 0x80808080u;
                            if (__any_sync(0xffffffffu, ov != 0u)) {
                                offset_to_max();
                                pack();
                            }
                        }
                    }
                    if constexpr (!QKOV) {
                        transpose_v();
                    }
                    fence_proxy_async();
                    named_sync(2 + hk, 128);
                    {
                        const uint64_t vd = VHOIST ? (desc_sw64(0) & ~0xffffffffull) | vd_lo
                                                   : desc_sw64(smem_u32(vt_of()));
                        wg_fence();
                        wgmma_pv(o, pa[0], vd);
                        wgmma_pv(o, pa[1], vd + 2);
                        wg_commit();
                        wg_wait<0>();
                        reg_fence(o);
                    }
                    if constexpr (!EREL) {
                        release(st);
                    }
                    if constexpr (VHOIST) {
                        vt_cur ^= vt_x;
                        vd_lo ^= vd_x;
                    }
                    st = PROD ? cst : (st == STAGES - 1 ? 0 : st + 1);
                }
            } else if constexpr (PRQ != 0) {
                constexpr bool TOV = (PRQ & 1) != 0;
                constexpr bool QKF = (PRQ & 2) != 0;
                constexpr bool SPV = (PRQ & 8) != 0;
                constexpr bool TCHK = (PRQ & 16) != 0;
                int st = 0;
                for (int it = 0; it < ntiles; ++it) {
                     
                     
                    cp_wait<STAGES - 2>();
                    fence_proxy_async();
                    if (it == 0) {
                        stamp(14);
                    }
                    __syncthreads();
                    if (it == 0) {
                        stamp(15);
                    }
                    auto issue_next = [&]() {
                        if constexpr (!ONE) {
                            if (it + STAGES - 1 < ntiles) {
                                issue_kv(it + STAGES - 1, (st + STAGES - 1) % STAGES, true);
                                issue_idx(it + 2 * STAGES - 2);
                            }
                            cp_commit();
                        }
                    };
                    if constexpr (!QKF) {
                        issue_next();
                    }
                    const uint8_t* vs = smem + S::KV + st * 2 * TILE_BYTES + TILE_BYTES;
                    const int pos0 = lo + it * BN;
                    const bool interior =
                        pos0 + BN - 1 <= seq && (!p.window || pos0 >= seq + L - p.window);
                    float s[32];
                    {
                        const uint64_t kd =
                            desc_sw128(smem_base + S::KV + st * 2 * TILE_BYTES + hk * 64);
                        wg_fence();
                        wgmma_qk<0>(s, qd0, kd);
                        wgmma_qk<1>(s, qd1, kd + 2);
                        wg_commit();
                    }
                    if constexpr (QKF) {
                        issue_next();
                    }
                    uint8_t* vt = smem + S::VT + (2 * (it & 1) + hk) * VT_STRIDE;
                    auto transpose = [&]() {
                        const int h4 = lane >> 3;
                        const int r8 = lane & 7;
#pragma unroll
                        for (int half = 0; half < 2; ++half) {
                            const int key = half * 32 + h4 * 8 + r8;
                            uint32_t t0, t1, t2, t3;
                            ldsm_x4_trans(smem_u32(vs + key * ROWB + ((hk * 4 + wq) ^ r8) * 16), t0,
                                          t1, t2, t3);
                            const uint32_t m0 = __byte_perm(t0, t1, 0x6420);
                            const uint32_t m1 = __byte_perm(t0, t1, 0x7531);
                            const uint32_t m2 = __byte_perm(t2, t3, 0x6420);
                            const uint32_t m3 = __byte_perm(t2, t3, 0x7531);
                            const int n = 8 * (2 * wq + (h4 & 1)) + r8;
                            const int chunk = 2 * half + (h4 >> 1);
                            stsm_x4(smem_u32(vt + n * 64 + ((chunk ^ ((n >> 1) & 3)) << 4)), m0, m1,
                                    m2, m3);
                        }
                    };
                    if constexpr (TOV) {
                        transpose();
                    }
                    wg_wait<0>();
                    reg_fence(s);
                    if (!interior) {
#pragma unroll
                        for (int i = 0; i < 8; ++i) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                                for (int e = 0; e < 2; ++e) {
                                    const int pos = pos0 + 8 * i + 2 * c + e;
                                    const int qp = qp0 + hh;
                                    if (pos > qp || (p.window && pos < qp - p.window + 1)) {
                                        s[4 * i + 2 * hh + e] = NEG_INF;
                                    }
                                }
                            }
                        }
                    }
                    float mxr[2];
#pragma unroll
                    for (int hh = 0; hh < 2; ++hh) {
                        float mx = fmaxf(s[2 * hh], s[2 * hh + 1]);
#pragma unroll
                        for (int i = 1; i < 8; ++i) {
                            mx = fmaxf(mx, fmaxf(s[4 * i + 2 * hh], s[4 * i + 2 * hh + 1]));
                        }
                        mxr[hh] = mx;
                    }
                     
                     
                     
                    bool any_move = false;
                    if constexpr (TCHK) {
                        any_move = __any_sync(0xffffffffu, mxr[0] * sl2k > off[0] + 8.f
                                                               || mxr[1] * sl2k > off[1] + 8.f);
                    }
                    float tmax[2];
                    bool move[2];
                    auto row_moves = [&]() {
#pragma unroll
                        for (int hh = 0; hh < 2; ++hh) {
                            tmax[hh] = quad_max(mxr[hh]) * sl2k;
                            move[hh] = tmax[hh] > off[hh] + 8.f;
                        }
                    };
                    if constexpr (!TCHK) {
                        row_moves();
                        any_move = __any_sync(0xffffffffu, move[0] || move[1]);
                    }
                    if (any_move) {
                        if constexpr (TCHK) {
                            row_moves();
                        }
#pragma unroll
                        for (int hh = 0; hh < 2; ++hh) {
                            const float nxt = move[hh] ? tmax[hh] : off[hh];
                            const float scale = ex2(off[hh] - nxt);
                            off[hh] = nxt;
#pragma unroll
                            for (int i = 0; i < 9; ++i) {
                                o[4 * i + 2 * hh] *= scale;
                                o[4 * i + 2 * hh + 1] *= scale;
                            }
                        }
                    }
                    uint32_t pa[2][4];
                    auto pack_half = [&](int kk) {
#pragma unroll
                        for (int i = 4 * kk; i < 4 * kk + 4; ++i) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                                for (int e = 0; e < 2; ++e) {
                                    s[4 * i + 2 * hh + e] =
                                        ex2(fmaf(s[4 * i + 2 * hh + e], sl2k, -off[hh]));
                                }
                            }
                        }
                        const float* q0 = s + 16 * kk;
                        pa[kk][0] = e4m3x4(q0[0], q0[1], q0[4], q0[5]);
                        pa[kk][1] = e4m3x4(q0[2], q0[3], q0[6], q0[7]);
                        pa[kk][2] = e4m3x4(q0[8], q0[9], q0[12], q0[13]);
                        pa[kk][3] = e4m3x4(q0[10], q0[11], q0[14], q0[15]);
                    };
                    const uint64_t vd = desc_sw64(smem_u32(vt));
                    if constexpr (SPV) {
                        pack_half(0);
                        if constexpr (!TOV) {
                            transpose();
                        }
                        fence_proxy_async();
                        named_sync(2 + hk, 128);
                        wg_fence();
                        wgmma_pv(o, pa[0], vd);
                        wg_commit();
                        pack_half(1);
                        wg_fence();
                        wgmma_pv(o, pa[1], vd + 2);
                        wg_commit();
                    } else {
                        pack_half(0);
                        pack_half(1);
                        if constexpr (!TOV) {
                            transpose();
                        }
                        fence_proxy_async();
                        named_sync(2 + hk, 128);
                        wg_fence();
                        wgmma_pv(o, pa[0], vd);
                        wgmma_pv(o, pa[1], vd + 2);
                        wg_commit();
                    }
                    wg_wait<0>();
                    reg_fence(o);
                    st = st == STAGES - 1 ? 0 : st + 1;
                }
            } else {
                int st = PROD ? cst : 0;
                for (int it = 0; it < ntiles; ++it) {
                    acquire(it, st);
                    const uint8_t* vs = smem + S::KV + st * 2 * TILE_BYTES + TILE_BYTES;
                    const int pos0 = lo + it * BN;
                    const bool interior =
                        pos0 + BN - 1 <= seq && (!p.window || pos0 >= seq + L - p.window);
                    float s[32];
                    {
                        const uint64_t kd =
                            desc_sw128(smem_base + S::KV + st * 2 * TILE_BYTES + hk * 64);
                        wg_fence();
                        wgmma_qk<0>(s, qd0, kd);
                        wgmma_qk<1>(s, qd1, kd + 2);
                        wg_commit();
                        wg_wait<0>();
                        reg_fence(s);
                    }
                    if (!interior) {
#pragma unroll
                        for (int i = 0; i < 8; ++i) {
#pragma unroll
                            for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                                for (int e = 0; e < 2; ++e) {
                                    const int pos = pos0 + 8 * i + 2 * c + e;
                                    const int qp = qp0 + hh;
                                    if (pos > qp || (p.window && pos < qp - p.window + 1)) {
                                        s[4 * i + 2 * hh + e] = NEG_INF;
                                    }
                                }
                            }
                        }
                    }
                     
                     
                    float tmax[2];
                    bool move[2];
#pragma unroll
                    for (int hh = 0; hh < 2; ++hh) {
                        float mx = fmaxf(s[2 * hh], s[2 * hh + 1]);
#pragma unroll
                        for (int i = 1; i < 8; ++i) {
                            mx = fmaxf(mx, fmaxf(s[4 * i + 2 * hh], s[4 * i + 2 * hh + 1]));
                        }
                        tmax[hh] = quad_max(mx) * sl2k;
                        move[hh] = tmax[hh] > off[hh] + 8.f;
                    }
                    if (__any_sync(0xffffffffu, move[0] || move[1])) {
#pragma unroll
                        for (int hh = 0; hh < 2; ++hh) {
                            const float nxt = move[hh] ? tmax[hh] : off[hh];
                            const float scale = ex2(off[hh] - nxt);
                            off[hh] = nxt;
#pragma unroll
                            for (int i = 0; i < 9; ++i) {
                                o[4 * i + 2 * hh] *= scale;
                                o[4 * i + 2 * hh + 1] *= scale;
                            }
                        }
                    }
#pragma unroll
                    for (int i = 0; i < 8; ++i) {
#pragma unroll
                        for (int hh = 0; hh < 2; ++hh) {
#pragma unroll
                            for (int e = 0; e < 2; ++e) {
                                s[4 * i + 2 * hh + e] =
                                    ex2(fmaf(s[4 * i + 2 * hh + e], sl2k, -off[hh]));
                            }
                        }
                    }
                     
                     
                     
                     
                    uint32_t pa[2][4];
#pragma unroll
                    for (int kk = 0; kk < 2; ++kk) {
                        const float* q0 = s + 16 * kk;
                        pa[kk][0] = e4m3x4(q0[0], q0[1], q0[4], q0[5]);
                        pa[kk][1] = e4m3x4(q0[2], q0[3], q0[6], q0[7]);
                        pa[kk][2] = e4m3x4(q0[8], q0[9], q0[12], q0[13]);
                        pa[kk][3] = e4m3x4(q0[10], q0[11], q0[14], q0[15]);
                    }
                     
                     
                     
                     
                     
                    uint8_t* vt = smem + S::VT + (2 * (it & 1) + hk) * VT_STRIDE;
                    {
                        const int h4 = lane >> 3;
                        const int r8 = lane & 7;
#pragma unroll
                        for (int half = 0; half < 2; ++half) {
                            const int key = half * 32 + h4 * 8 + r8;
                            uint32_t t0, t1, t2, t3;
                            ldsm_x4_trans(smem_u32(vs + key * ROWB + ((hk * 4 + wq) ^ r8) * 16), t0,
                                          t1, t2, t3);
                            const uint32_t m0 = __byte_perm(t0, t1, 0x6420);
                            const uint32_t m1 = __byte_perm(t0, t1, 0x7531);
                            const uint32_t m2 = __byte_perm(t2, t3, 0x6420);
                            const uint32_t m3 = __byte_perm(t2, t3, 0x7531);
                            const int n = 8 * (2 * wq + (h4 & 1)) + r8;
                            const int chunk = 2 * half + (h4 >> 1);
                            stsm_x4(smem_u32(vt + n * 64 + ((chunk ^ ((n >> 1) & 3)) << 4)), m0, m1,
                                    m2, m3);
                        }
                    }
                    fence_proxy_async();
                    named_sync(2 + hk, 128);
                    {
                        const uint64_t vd = desc_sw64(smem_u32(vt));
                        wg_fence();
                        wgmma_pv(o, pa[0], vd);
                        wgmma_pv(o, pa[1], vd + 2);
                        wg_commit();
                        wg_wait<0>();
                        reg_fence(o);
                    }
                    release(st);
                    st = PROD ? cst : (st == STAGES - 1 ? 0 : st + 1);
                }
            }
            if constexpr (STAMPS) {
                s_loop += clock64() - s_l0;
                s_tiles += ntiles;
                ++s_nseg;
            }
            stamp(16);
            PHASE_EXIT(10)
             
             
             
             
#pragma unroll
            for (int hh = 0; hh < 2; ++hh) {
                const float f = ex2(fminf(off[hh], 126.f));
                const int row = ws_row(b, p.nc, copy, L, 2 * wq + hh, hk * 8 + g);
                float* dst = p.ws_acc + static_cast<size_t>(row) * D + c * 4;
#pragma unroll
                for (int pp = 0; pp < 4; ++pp) {
                    red_add_v4(dst + 16 * pp, o[8 * pp + 2 * hh] * f, o[8 * pp + 4 + 2 * hh] * f,
                               o[8 * pp + 1 + 2 * hh] * f, o[8 * pp + 5 + 2 * hh] * f);
                }
                if (c == 0) {
                    red_add_f32(p.ws_l + row, o[32 + 2 * hh] * f);
                }
            }
        }
        stamp(17);
        return true;
    };
#undef PHASE_EXIT

     
     
     
    auto ticket = [&]() {
        csync();
        stamp(18);
        const int mine = hi - lo;
        if (tid == 0) {
             
             
            const int old = atom_add_acq_rel(p.ws_cnt + b, mine);
            *flag = old + mine >= n_keys;
        }
        stamp(19);
        csync();
        if (ONE_DIAG && p.phase_limit == 12) {
            return;
        }
        if (*flag) {
#if ONE_DETM
            if constexpr (DETM) {
                finalize_det<SEGK>(p, offs, B, G, b, v_scale, tid);
            } else
#endif
            {
                finalize_rows<L, NC, FIN8>(p, b * ROWS, (b + 1) * ROWS, v_scale, tid);
            }
            if (tid == 0) {
                p.ws_cnt[b] = 0;
            }
        }
        stamp(20);
    };

    if constexpr (!FLAT) {
        seq = SPEC ? p.pt_stride - L : seq_real;
        derive();
        if (!SPEC && lo >= end) {
            return;
        }
        if (!run_segment()) {
            return;
        }
         
        if (ONE_DIAG && p.phase_limit == 11) {
            return;
        }
        if constexpr (!COOP) {
            ticket();
        } else {
             
             
            __syncthreads();
            const int ep = *reinterpret_cast<const int*>(smem + S::CONST + C_EPOCH);
            const int rows_per = (ROWS + nact - 1) / nact;
            coop_barrier<NC>(p.ws_cnt + CNT_COOP + 2 * b, p.ws_cnt + CNT_EPOCH + b, ep, hi - lo,
                             n_keys, tid, p.dbg);
            if (ONE_DIAG && p.phase_limit == 12) {
                return;
            }
            const int r_lo = split * rows_per;
            const int r_hi = min(ROWS, r_lo + rows_per);
            if (r_lo < r_hi) {
                finalize_rows<L, NC, FIN8>(p, b * ROWS + r_lo, b * ROWS + r_hi, v_scale, tid);
            }
        }
    } else {
         
         
        asm volatile("griddepcontrol.wait;" ::: "memory");
         
         
        const int ep = COOP ? __ldcg(p.ws_cnt + CNT_FLAT + 2) : 0;
        const float v_scale_g = __ldg(p.v_scale);
        int mine_total = 0;
        for (b = b_first; b <= b_last; ++b) {
            if (!seg_bounds(b)) {
                continue;
            }
            run_segment();
            if constexpr (!COOP) {
                if constexpr (STAMPS) {
                    if (tid == 0) {
                        srec(4, snow());
                    }
                }
                ticket();
            } else {
                mine_total += hi - lo;
            }
        }
        if constexpr (STAMPS && !COOP) {
            if (tid == 0) {
                srec(5, snow());
                srec(6, s_tiles);
                srec(7, s_nseg);
                srec(8, s_fullw);
                srec(9, s_pro);
                srec(10, s_loop);
                srec(14, clock64() - s_k0);
            }
        }
        if constexpr (COOP) {
            if constexpr (STAMPS) {
                if (tid == 0) {
                    srec(3, snow());
                    srec(6, s_tiles);
                    srec(7, s_nseg);
                    srec(8, s_fullw);
                    srec(9, s_pro);
                    srec(10, s_loop);
                    srec(13, clock64() - s_k0);
                }
            }
            csync();
            coop_barrier<NC>(p.ws_cnt + CNT_FLAT, p.ws_cnt + CNT_FLAT + 2, ep, mine_total,
                             keys_all, tid, p.dbg);
            if constexpr (STAMPS) {
                if (tid == 0) {
                    srec(4, snow());
                }
            }
            const int rows_all = B * ROWS;
            const int rows_per = (rows_all + G - 1) / G;
            const int r_lo = split * rows_per;
            const int r_hi = min(rows_all, r_lo + rows_per);
            if (r_lo < r_hi) {
                finalize_rows<L, NC>(p, r_lo, r_hi, v_scale_g, tid);
            }
            if constexpr (STAMPS) {
                if (tid == 0) {
                    srec(5, snow());
                    srec(14, clock64() - s_k0);
                }
            }
        }
    }
}

 
 
 
 
 
 

} // native inner namespace
} // anonymous namespace
