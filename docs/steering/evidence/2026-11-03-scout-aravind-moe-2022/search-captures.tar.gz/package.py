from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, tarfile, shutil

out=Path('.build/scout-2026-11-03-2022')
evidence=Path('docs/steering/evidence/2026-11-03-scout-aravind-moe-2022');evidence.mkdir(parents=True,exist_ok=True)
check=json.loads((out/'aravind-static-check.json').read_text());check['duplicate_prepare_or_kernel_fn_definitions']=check.pop('duplicate_top_level_definitions',False);(out/'aravind-static-check.json').write_text(json.dumps(check,indent=2)+'\n')
analysis=json.loads((out/'analysis.json').read_text());coverage=json.loads((out/'query-coverage.json').read_text());code=json.loads((out/'code.json').read_text());requests=json.loads((out/'requests.json').read_text());sources=json.loads((out/'aravind-source-manifest.json').read_text())
assert not analysis['new_code_files'] and not analysis['changed_watched_heads']
assert all(not r.get('error') for r in coverage)
assert all(not p.get('error') for q in code['searches'] for p in q['pages'])
summary=dict(triggered_at='2026-11-03T20:22:25.752Z',packaged_at=datetime.now(timezone.utc).isoformat(),instructions_ref='7812d75c550e00398ce8729fa27cdfb3eb123e81',decision='NOTIFY',finding='New public H200 MoE source at dcf3ee7c; author score and unselected-WGMMA caveat remain unverified performance claims.',source_pin='dcf3ee7c7c0b42e0f534648b88a06c138b7dfc40',publication_date='2026-11-03T19:25:32Z',source_files=len(sources),source_check=check,code_unique_in_sample=analysis['code_unique'],new_code_blobs=0,code_queries=code['searches'],code_limits='First and previous terminal pages only. Interior code pages were not re-read. Prior full capture covered 8/5/5/4/2 pages. Totals may change between pages and misses do not prove absence.',other_queries=coverage,other_limits='Timestamp-bound from18:28:21UTC, with overlap before the previous full capture. Backdated or newly indexed older activity may be omitted. Default/nondefault source pins checked separately.',changed_watched_default_heads=[],new_relevant_repository='Aravind-11/muse-moe-w4a16-kernels',nondefault_heads=json.loads((out/'watched-branches.json').read_text()),source_credit_counts=[15,16,21],guild_pages=18,guild_unique_fragments=66,guild_new_fragments=0,indexed_web_queries=12,blog_hashes=json.loads((out/'blogs-http.json').read_text()),watch_comparisons=json.loads((out/'watch-comparisons.json').read_text()),api_errors=[{k:r.get(k) for k in ['path','retrieved_at','error']} for r in requests if r.get('error')],final_search_errors=[],foreign_execution=False,gpu_jobs=False,prior_report=dict(commit='4e1a0edc17efbbb18d663988a0716496ca4600f0',scope='Preceding Guild timing/B200 data-control report remotely verified; separate capture from this refresh.'),limits=['Source correctness, publication/progress proof, numerical tests, compiled SASS and timing were not independently checked.','Prepared final variant choices and raw judge receipt are absent from the published tree.','No authenticated Slack/Discord, restricted Guild bodies or encrypted messages accessed.','Independent reviewer unavailable under the no-new-agents repository rule.'])
(evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['aravind-source-manifest.json','aravind-static-check.json','query-coverage.json','guild-body-diff.json','watch-comparisons.json','web-coverage.json','social-access.json']:
 shutil.copyfile(out/name,evidence/name)
with tarfile.open(evidence/'aravind-source.tar.gz','w:gz',compresslevel=9) as archive:
 for row in sources:
  data=Path(row['local']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob'];archive.add(row['local'],arcname=row['path'])
with tarfile.open(evidence/'search-captures.tar.gz','w:gz',compresslevel=9) as archive:
 for path in sorted(out.iterdir()):
  if path.is_file() and path.suffix in ['.py','.json','.diff'] and path.name not in ['requests.json','state-before.json']:
   archive.add(path,arcname=path.name)
rows=[]
for path in sorted(evidence.iterdir()):
 if path.name=='manifest.json':continue
 data=path.read_bytes();rows.append(dict(path=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()))
(evidence/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(evidence_files=len(rows),evidence_bytes=sum(r['bytes'] for r in rows)),indent=2))
