import json,hashlib
from html.parser import HTMLParser
from pathlib import Path
class Bodies(HTMLParser):
 def __init__(self):super().__init__();self.depth=0;self.parts=[];self.rows=[]
 def handle_starttag(self,tag,attrs):
  if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:return
  if self.depth:self.depth+=1
  elif 'body' in dict(attrs).get('class','').split():self.depth=1;self.parts=[]
 def handle_endtag(self,tag):
  if self.depth:
   self.depth-=1
   if not self.depth:
    text=' '.join(' '.join(self.parts).split())
    if text:self.rows.append(text)
 def handle_data(self,data):
  if self.depth:self.parts.append(data)
def bodies(folder):
 out={}
 for p in list(folder.glob('guild-*.html'))+list(folder.glob('all-comment-*.html')):
  parser=Bodies();parser.feed(p.read_text())
  for t in parser.rows:out[hashlib.sha256(t.encode()).hexdigest()]=t
 return out
now=Path('.build/scout-2026-11-03-2022');old=Path('.build/scout-2026-11-03-1823');n=bodies(now);o=bodies(old)
d={'new_bodies':[n[k] for k in n.keys()-o.keys()],'removed_bodies':[o[k] for k in o.keys()-n.keys()],'unique_before':len(o),'unique_now':len(n),'body_hashes':sorted(n)}
(now/'guild-body-diff.json').write_text(json.dumps(d,indent=2)+'\n')
print({k:len(v) if isinstance(v,list) else v for k,v in d.items()})
